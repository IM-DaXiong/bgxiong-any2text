export declare const COLOR_TOKENS: readonly ["c1", "c2", "c3", "c4", "c5", "c6"];
export type ColorToken = (typeof COLOR_TOKENS)[number];
export type RichInterval = {
    start: number;
    end: number;
    bold?: boolean;
    color?: ColorToken | null;
};
export type RichDoc = {
    plain: string;
    intervals: RichInterval[];
};
