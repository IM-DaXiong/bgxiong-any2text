import type { MainModuleTab } from "../settings/lastMainModuleTab";
export interface ShortcutChord {
    code: string;
    ctrl?: boolean;
    alt?: boolean;
    shift?: boolean;
    meta?: boolean;
}
export interface ShortcutActionDefinition {
    id: string;
    /** global | 单 Tab | 多 Tab（如 F11 场次 peek：storyboard + segments） */
    scope: "global" | "director" | "any2text" | {
        mainTab: MainModuleTab;
    } | {
        mainTabs: readonly MainModuleTab[];
    };
    defaultChord: ShortcutChord | null;
    allowInEditableTarget?: boolean;
    /** 按住键时允许 OS key-repeat 连续触发（如笔刷粗细/透明度步进） */
    allowKeyRepeat?: boolean;
    /**
     * 弹层（公共 modalDepth>0）打开时是否派发。缺省沿用旧策略：仅 scope=global 且 allowInEditableTarget 的动作可派发；
     * 显式 false：弹层期间一律不派发（F1 语音 startMic/cancelMic，由弹层自己处理 Esc）；显式 true：弹层期间也派发。
     */
    allowWhenModalOpen?: boolean;
    labelKey: string;
    categoryKey: string;
    aliases?: readonly ShortcutChord[];
    settingsHidden?: boolean;
}
export type ShortcutBindings = Record<string, ShortcutChord | null>;
export interface ShortcutConflict {
    actionId: string;
    conflictingActionId: string;
}
export interface WarningChord {
    chord: ShortcutChord;
    risk: "high" | "medium" | "low";
    descriptionZh: string;
    descriptionEn: string;
}
