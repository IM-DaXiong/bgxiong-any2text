import type { ShortcutChord } from "./shortcutTypes";
export declare function normalizeMainModifier(event: KeyboardEvent, isMacOS?: boolean): boolean;
export declare function chordFromKeyboardEvent(event: KeyboardEvent, isMacOS?: boolean): ShortcutChord | null;
export declare function isComposingEvent(event: KeyboardEvent): boolean;
/** INV-SEG-DEL-SEL-06 / INV-TVH-EDIT-HIST-16: same predicate for key skip and marquee blur. */
export declare function isEditableHtmlElement(el: EventTarget | null | undefined): boolean;
export declare function isEditableTarget(event: KeyboardEvent): boolean;
/** INV-TVH-EDIT-HIST-04: workbench chrome (not prompt hosts). */
export declare function isInsideTextareaWorkbench(event: KeyboardEvent): boolean;
export declare function isModifierOnlyCode(code: string): boolean;
