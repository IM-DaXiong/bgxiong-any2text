import type { MainModuleTab } from "../settings/lastMainModuleTab";
import type { ShortcutActionDefinition, ShortcutBindings, ShortcutChord } from "./shortcutTypes";
export declare function chordEquals(a: ShortcutChord, b: ShortcutChord): boolean;
/**
 * US `+` = Shift+=. Aliases apply only while the effective chord is still the registry default
 * (user remap must not keep stealing Equal / Numpad).
 */
export declare function chordMatchesAction(chord: ShortcutChord, eff: ShortcutChord, actionId: string): boolean;
export declare function effectiveChord(actionId: string, bindings: ShortcutBindings | undefined, definitions?: ShortcutActionDefinition[]): ShortcutChord | null;
/**
 * 弹层打开（modalDepth>0）时该动作能否派发：显式 allowWhenModalOpen 优先；
 * 缺省保持旧策略（global 且 allowInEditableTarget）。
 */
export declare function isActionAllowedWhileModalOpen(def: ShortcutActionDefinition): boolean;
export declare function listMatchingActions(chord: ShortcutChord, bindings: ShortcutBindings | undefined, currentTab: MainModuleTab, modalDepth: number, definitions?: ShortcutActionDefinition[]): ShortcutActionDefinition[];
export declare function findMatchingAction(chord: ShortcutChord, bindings: ShortcutBindings | undefined, currentTab: MainModuleTab, modalDepth: number, definitions?: ShortcutActionDefinition[]): ShortcutActionDefinition | null;
export type ShortcutDispatchDecision = {
    kind: "none";
} | {
    kind: "preventDefaultOnly";
    actionId: string;
} | {
    kind: "invoke";
    action: ShortcutActionDefinition;
};
/** INV-SCENE-TAB-NAV-06 / INV-SHORTCUT-SAVE-02: 无 handler 则下一项；app.save 无 handler 只拦截不 fallthrough。 */
export declare function resolveShortcutDispatch(args: {
    matches: ShortcutActionDefinition[];
    hasHandler: (actionId: string) => boolean;
    isRepeat: boolean;
    editableBlocked: boolean;
    skipTvhCanvasEdit: boolean;
}): ShortcutDispatchDecision;
