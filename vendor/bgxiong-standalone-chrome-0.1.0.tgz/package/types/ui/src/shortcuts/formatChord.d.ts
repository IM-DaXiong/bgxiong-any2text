import type { ShortcutChord } from "./shortcutTypes";
export declare function formatChordForDisplay(chord: ShortcutChord | null, locale: "zh-CN" | "en", isMacOS: boolean): string;
