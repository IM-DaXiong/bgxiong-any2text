/**
 * 模块：快捷键动作注册表与危险组合提示。
 * 职责：`ACTION_DEFINITIONS` 供设置页与 `ShortcutContext` 解析默认键、标签路径；`WARNING_CHORDS` 供录入警告。
 * 依赖：`shortcutTypes`；画布全屏动作为单一 `canvas.toggleFullscreen`（默认 F11）。
 */
import type { ShortcutActionDefinition, ShortcutChord, WarningChord } from "./shortcutTypes";
export declare const ANY2TEXT_LABELS: Map<string, {
    "zh-CN": string;
    en: string;
}>;
export declare function isAllowedAny2TextChord(chord: ShortcutChord): boolean;
export declare const ACTION_DEFINITIONS: ShortcutActionDefinition[];
/** Settings UI section order. Runtime matching still uses `scope`, not this list. */
export declare const SHORTCUT_SETTINGS_CATEGORY_ORDER: readonly string[];
export declare const WARNING_CHORDS: WarningChord[];
export declare const ACTION_DEFINITION_BY_ID: Map<string, ShortcutActionDefinition>;
export declare const DIRECTOR_LABELS: Map<string, {
    "zh-CN": string;
    en: string;
}>;
export declare function isAllowedDirectorChord(chord: ShortcutChord): boolean;
