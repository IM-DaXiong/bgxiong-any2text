export declare function createOsFullscreenController(getWindow: () => {
    isFullscreen(): Promise<boolean>;
    isMaximized(): Promise<boolean>;
    toggleMaximize(): Promise<void>;
    maximize(): Promise<void>;
    setFullscreen(want: boolean): Promise<void>;
}, isWindows: () => boolean): (mode: "toggle" | "enter" | "exit") => Promise<void>;
