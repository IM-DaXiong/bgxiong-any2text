declare const VALID_TABS: readonly ["stories", "sceneAssets", "propAssets", "storyProps", "characters", "roles", "chapters", "scenes", "storyboard", "segments", "clips", "voice", "music", "sfx", "freeCanvas", "tasks", "help", "settings"];
export type MainModuleTab = (typeof VALID_TABS)[number];
export declare function isMainModuleTab(v: string): v is MainModuleTab;
export declare function readLastMainModuleTab(): MainModuleTab | null;
export declare function writeLastMainModuleTab(tab: MainModuleTab): void;
export {};
