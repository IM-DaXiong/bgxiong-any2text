export type MediaReferenceInventoryItem = {
    /** Stable identity used in @{ref:<id>} — must survive rename/reorder. */
    referenceId: string;
    label: string;
    mediaKind: "image" | "audio" | "video" | "text";
    /** Optional thumbnail URL for inline chip + hover preview. */
    previewUrl?: string | null;
};
export type MediaRefDisplaySpan = {
    start: number;
    end: number;
    referenceId: string;
};
