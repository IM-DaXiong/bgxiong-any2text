export type EditorTypographySurface = "chrome" | "workbench";
export declare const WORKBENCH_TYPOGRAPHY_STORAGE_KEY = "bgx.versionHistoryWorkbench.typography.v1";
export declare const CHROME_TYPOGRAPHY_STORAGE_KEY = "bgx.richPlainEditor.typography.v1";
/** @deprecated workbench key; keep for existing imports */
export declare const EDITOR_TYPOGRAPHY_STORAGE_KEY = "bgx.versionHistoryWorkbench.typography.v1";
export declare const EDITOR_FONT_SIZE_MIN = 12;
export declare const EDITOR_FONT_SIZE_MAX = 88;
export declare const EDITOR_LINE_HEIGHT_MIN = 1.4;
export declare const EDITOR_LINE_HEIGHT_MAX = 2.4;
export declare const EDITOR_FONT_SIZE_DEFAULT = 14;
/** Workbench seed (toolbar). Host CSS uses --leading-normal 1.5 until chrome override exists. */
export declare const EDITOR_LINE_HEIGHT_DEFAULT = 1.8;
export declare const CHROME_LINE_HEIGHT_SEED = 1.5;
export type EditorTypographyPrefs = {
    fontSizePx: number;
    lineHeight: number;
};
export declare function clampEditorTypographyPrefs(prefs: Partial<EditorTypographyPrefs>): EditorTypographyPrefs;
export declare function loadEditorTypographyPrefs(): EditorTypographyPrefs;
export declare function saveEditorTypographyPrefs(prefs: EditorTypographyPrefs): void;
export declare function getEditorTypographyPrefs(surface?: EditorTypographySurface): EditorTypographyPrefs | null;
export declare function subscribeEditorTypographyPrefs(surface: EditorTypographySurface, fn: (prefs: EditorTypographyPrefs | null) => void): () => void;
export declare function bumpEditorFontSize(delta: number, surface?: EditorTypographySurface): void;
export declare function bumpEditorLineHeight(delta: number, surface?: EditorTypographySurface): void;
export declare function __resetEditorTypographyPrefsForTest(prefs?: EditorTypographyPrefs, surface?: EditorTypographySurface): void;
export declare function useEditorTypographyPrefs(surface?: EditorTypographySurface): EditorTypographyPrefs | null;
