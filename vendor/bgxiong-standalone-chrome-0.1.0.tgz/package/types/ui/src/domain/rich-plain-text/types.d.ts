/**
 * RichPlain closed-set marks. Source is bgx tags; HTML is display-only.
 */
export declare const COLOR_TOKENS: readonly ["c1", "c2", "c3", "c4", "c5", "c6"];
export type ColorToken = (typeof COLOR_TOKENS)[number];
export declare const TEXT_RICH_OWNER_KINDS: readonly ["node", "story", "visualAsset", "dialogueTrack", "nodeHistory", "storyHistory", "visualAssetHistory", "fcNode", "fcNodeHistory", "clipNode", "clipNodeHistory", "actor", "music", "voice"];
export type TextRichOwnerKind = (typeof TEXT_RICH_OWNER_KINDS)[number];
export type RichInterval = {
    start: number;
    end: number;
    bold?: boolean;
    color?: ColorToken | null;
};
export type RichDoc = {
    plain: string;
    intervals: RichInterval[];
};
export type RichRun = {
    text: string;
    bold: boolean;
    color: ColorToken | null;
};
export type RichPlainOwner = {
    ownerKind: TextRichOwnerKind;
    ownerId: string;
    fieldKey: string;
    storyId?: string | null;
};
export declare const RICH_PLAIN_PARSE_FAIL = "RICH_PLAIN_PARSE_FAIL";
export declare const RICH_PLAIN_FP_MISMATCH = "RICH_PLAIN_FP_MISMATCH";
/** Peek-only miss (inbound join). Must never DELETE. */
export declare const RICH_PLAIN_PEEK_MISS = "RICH_PLAIN_PEEK_MISS";
export declare const RICH_PLAIN_STYLE_SAVE_FAILED = "\u6B63\u6587\u5DF2\u4FDD\u5B58\uFF0C\u6837\u5F0F\u672A\u5199\u5165";
export declare function isColorToken(value: string): value is ColorToken;
export declare function isTextRichOwnerKind(value: string): value is TextRichOwnerKind;
export declare function emptyRichDoc(plain?: string): RichDoc;
