export declare function themeForDocument(id: string): void;
