/**
 * Pure chrome export for standalone apps (no main-window API, no story.db,
 * no settings writes). Import this entry instead of the default
 * rich-plain-editor or button barrels, which still expose hosted wiring.
 *
 * True sources: UiChromeTextarea (Core + resize shell), UiChromeSelect, Btn
 * display, and themeEarlyHydrate.
 */
export { UiChromeTextarea } from "./UiChromeTextarea";
export type { UiChromeTextareaProps, UiChromeTextareaAttrs } from "./UiChromeTextarea";
export type { RichPlainEditorHandle } from "../rich-plain-editor/richPlainEditorTypes";
export { UiChromeSelect } from "../ui-chrome-select/UiChromeSelect";
export type { UiChromeSelectLabelLayout, UiChromeSelectProps, } from "../ui-chrome-select/UiChromeSelect";
export { Btn } from "../common/button/Btn";
export { earlyHydrateTheme } from "../../theme/themeEarlyHydrate";
export { standaloneRichPlainHost } from "../rich-plain-editor/hostPorts";
export type { RichPlainHostPorts } from "../rich-plain-editor/hostPorts";
export { claimInlineEditCommit } from "../common/inline-edit/claimInlineEditCommit";
export { themeForDocument } from "./standaloneTheme";
export { WindowControls } from "../common/WindowControls";
export { NativeDialog } from "../common/NativeDialog";
