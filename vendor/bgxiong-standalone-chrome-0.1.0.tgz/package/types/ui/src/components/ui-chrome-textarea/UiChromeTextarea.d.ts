/**
 * UiChromeTextarea — 统一「拖边壳 + 多行编辑框 + 可选版本历史角标」布局
 *
 * 【职责】
 *   组合 `UiEdgeResizeShell` + 内层 `RichPlainEditor`（class `ui-edit-textarea`）；
 *   封装条件修饰符 `ui-edge-resize-shell--with-history`（与 CSS 变量对齐），
 *   避免业务散落 padding 魔法数；角标仍以 slot 传入以保持各适配器类型独立。
 *   左下角提供历史和字号操作，右下角显示字数。
 *
 * 【依赖】
 *   - ui-edge-resize-shell/UiEdgeResizeShell（壳层组件）
 *   - ui-edge-resize-shell.css（壳层专用样式，main.tsx import）
 *   - 全局 CSS 变量（--textarea-history-pad-left 等，index.css）
 */
import { type CSSProperties, type ReactNode, type RefObject, type KeyboardEvent as ReactKeyboardEvent, type MouseEvent as ReactMouseEvent } from "react";
import type { EdgeResizeConstraints } from "../ui-edge-resize-shell/edgeResizeTypes";
import { type RichPlainEditorHandle } from "../rich-plain-editor/RichPlainEditorCore";
import { type RichPlainHostPorts } from "../rich-plain-editor/hostPorts";
import type { RichPlainOwner } from "../../domain/rich-plain-text/types";
export type UiChromeTextareaAttrs = {
    value: string;
    placeholder?: string;
    disabled?: boolean;
    readOnly?: boolean;
    spellCheck?: boolean;
    style?: CSSProperties;
    className?: string;
    "aria-label"?: string;
    "aria-describedby"?: string;
    "aria-invalid"?: boolean;
    id?: string;
    onFocus?: () => void;
    onBlur?: () => void;
    onKeyDown?: (e: ReactKeyboardEvent<HTMLDivElement>) => void;
    onClick?: (e: ReactMouseEvent<HTMLDivElement>) => void;
    onCompositionStart?: () => void;
    onCompositionEnd?: () => void;
    /** Mechanical hosts: (plain) => void. Do not pass a textarea ChangeEvent. */
    onChange?: (plain: string) => void;
    /** Ignored: height is owned by the resize shell. */
    rows?: number;
    maxLength?: number;
    onSelect?: () => void;
    onKeyUp?: () => void;
};
export type UiChromeTextareaProps = {
    /** 尺寸约束（可选；不提供时使用 DEFAULT_EDGE_CONSTRAINTS） */
    edgeConstraints?: EdgeResizeConstraints;
    /** 初始宽度（px；默认 0 → 占满父级宽，壳层测宽后锁定为 px） */
    defaultWidthPx?: number;
    /** 初始高度（px；默认 120）。与 fillAvailableHeight 同时为 true 时忽略，改为铺满父级高。 */
    defaultHeightPx?: number;
    /**
     * When true, the shell fills the parent column height (defaultHeightPx treated as 0)
     * until the user drags the bottom edge. Parent must be a flex column with a bounded height.
     */
    fillAvailableHeight?: boolean;
    contentHeight?: boolean;
    /** 追加在 `ui-edge-resize-shell` 上，如 `ui-edge-resize-shell--chapter` */
    shellClassName?: string;
    /** 与 `historyCorner` 同时存在时必须为 true，由 CSS 写入 `--textarea-history-pad-left` */
    withVersionHistory?: boolean;
    shellStyle?: CSSProperties;
    /** 追加在 `ui-edit-textarea` 之后，如 `ui-textarea-chapter scene-beat-textarea` */
    textareaExtraClassName?: string;
    textareaProps: UiChromeTextareaAttrs;
    onValueChange?: (plain: string) => void;
    onSourceChange?: (source: string) => void;
    richOwner?: RichPlainOwner;
    hydrateSource?: string | null;
    /** 版本历史时钟 slot；与字数浮层共用 relative 外包 */
    historyCorner?: ReactNode;
    /** 与角标同级的 relative 容器样式（如 flex 子项 `minWidth:0`） */
    relativeWrapStyle?: CSSProperties;
    /** 尺寸提交回调（pointerup 时触发，可选） */
    onSizeCommit?: (w: number, h: number) => void;
    /** 转发外壳 DOM ref */
    shellRef?: RefObject<HTMLDivElement | null>;
    /** 画布 Dock 内：resize 命中层加 data-canvas-ui，避免触发 IC 拖拽 */
    canvasResizeHandles?: boolean;
    syntaxProfileId?: string;
    pauseSyntaxRefresh?: boolean;
    citeImagePreviewByOrdinal?: Record<number, string>;
    /** Stable @{ref:id} thumbnail map; always-on media-ref chips. */
    mediaRefPreviewById?: Record<string, string>;
    mediaRefLabelById?: Record<string, string>;
    /** Optional editor host ports; omit to use the registered or standalone host. */
    richHost?: RichPlainHostPorts;
};
/**
 * 拖边壳 + RichPlainEditor；可选挂载版本历史角标（slot）。
 * 内部使用 `UiEdgeResizeShell`，默认仅允许底部拖拽调整高度（禁用水平拖拽）。
 */
export declare const UiChromeTextarea: import("react").ForwardRefExoticComponent<UiChromeTextareaProps & import("react").RefAttributes<RichPlainEditorHandle>>;
