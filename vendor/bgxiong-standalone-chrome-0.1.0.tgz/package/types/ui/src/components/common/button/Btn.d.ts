/**
 * 模块：公共组件 - 按钮（common/button/Btn）
 * 作用：全仓唯一 Btn 实现（INV-UI-BTN-01~07），支持 6 种 variant 及快捷别名。
 *
 * 主要导出：
 * - Btn: 核心按钮组件，支持 variant、disabled、ariaBusy、type、aria-label、shortcutActionId。
 * - PrimaryBtn / SecondaryBtn / DangerBtn: Btn 的快捷别名组件。
 *
 * 【色调语义 · 强制】
 * - variant="ai"（紫）：点击后直接 invoke AI / 创建 AI 任务（如 AI 提示词、批量 AI 提交）。
 * - variant="primary"（蓝）：保存、打开弹层/工作台、弹层内确认/取消、仅收集参数不立即发 AI 的入口。
 *
 * 【INV-UI-BTN-07】shortcutActionId 悬停只显示 chord（fade）；无 id 的 Btn 不挂 settings。
 *
 * 依赖：React, CSSProperties
 */
import { type ReactNode, type CSSProperties, type MouseEventHandler, type PointerEventHandler } from "react";
type BtnPropsBase = {
    children: ReactNode;
    variant?: "primary" | "secondary" | "danger" | "ghost" | "accent" | "ai";
    size?: "compact";
    disabled?: boolean;
    style?: CSSProperties;
    /** 原生 title，用于禁用态说明。有有效 shortcut chord 时不设置（INV-UI-BTN-07）。 */
    title?: string;
    ariaBusy?: boolean;
    onPointerDown?: PointerEventHandler<HTMLButtonElement>;
    "aria-label"?: string;
    "aria-pressed"?: boolean;
    "aria-expanded"?: boolean;
    "aria-haspopup"?: "listbox";
    "aria-selected"?: boolean;
    "data-testid"?: string;
    role?: "tab";
    /** shortcutRegistry action id；悬停只显示 chord */
    shortcutActionId?: string;
    shortcutLabel?: string;
    "aria-keyshortcuts"?: string;
    tabIndex?: number;
};
type BtnProps = (BtnPropsBase & {
    type: "submit" | "reset";
    onClick?: MouseEventHandler<HTMLButtonElement>;
}) | (BtnPropsBase & {
    type?: "button";
    onClick: MouseEventHandler<HTMLButtonElement>;
});
export declare const Btn: import("react").ForwardRefExoticComponent<BtnProps & import("react").RefAttributes<HTMLButtonElement>>;
export declare const PrimaryBtn: ({ onClick, children, disabled, title, style, type, }: {
    onClick: MouseEventHandler<HTMLButtonElement>;
    children: ReactNode;
    disabled?: boolean;
    title?: string;
    style?: CSSProperties;
    type?: "button" | "submit" | "reset";
}) => import("react/jsx-runtime").JSX.Element;
export declare const SecondaryBtn: ({ onClick, children, disabled, title, style, type, }: {
    onClick: MouseEventHandler<HTMLButtonElement>;
    children: ReactNode;
    disabled?: boolean;
    title?: string;
    style?: CSSProperties;
    type?: "button" | "submit" | "reset";
}) => import("react/jsx-runtime").JSX.Element;
export declare const DangerBtn: ({ onClick, children, style, type, }: {
    onClick: MouseEventHandler<HTMLButtonElement>;
    children: ReactNode;
    style?: CSSProperties;
    type?: "button" | "submit" | "reset";
}) => import("react/jsx-runtime").JSX.Element;
export {};
