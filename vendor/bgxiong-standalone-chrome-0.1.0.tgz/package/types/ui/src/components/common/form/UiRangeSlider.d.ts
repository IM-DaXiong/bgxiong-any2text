/**
 * Parameter slider: custom track + thumb at true 0%/100% (no native range inset).
 * Pointer seek on the track; hidden native range for keyboard / a11y only.
 */
import { type CSSProperties } from "react";
export interface UiRangeSliderProps {
    min: number;
    max: number;
    step?: number;
    value: number;
    onChange: (value: number) => void;
    disabled?: boolean;
    "aria-label"?: string;
    style?: CSSProperties;
}
export declare function UiRangeSlider({ min, max, step, value, onChange, disabled, "aria-label": ariaLabel, style, }: UiRangeSliderProps): import("react/jsx-runtime").JSX.Element;
