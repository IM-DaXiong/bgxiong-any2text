export declare function WindowControls({ max, onMinimize, onMaximize, onClose, }: {
    max: boolean;
    onMinimize: () => void;
    onMaximize: () => void;
    onClose: () => void;
}): import("react/jsx-runtime").JSX.Element;
