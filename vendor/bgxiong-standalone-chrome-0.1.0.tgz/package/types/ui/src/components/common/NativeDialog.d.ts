import { type ReactNode } from "react";
export declare function NativeDialog({ title, onClose, children, className, }: {
    title: string;
    onClose: () => void;
    children: ReactNode;
    className: string;
}): import("react/jsx-runtime").JSX.Element;
