import type { CSSProperties, HTMLAttributes } from "react";
type Props = {
    label: string;
    type?: "text" | "search";
    value: string;
    onValue: (value: string) => void;
    disabled?: boolean;
    /** Toolbar rows: no visible label, `label` stays the accessible name. */
    hideLabel?: boolean;
    placeholder?: string;
    maxLength?: number;
    onBlur?: () => void;
    inputMode?: HTMLAttributes<HTMLInputElement>["inputMode"];
    fieldStyle?: CSSProperties;
    /** `stack`: single-column form field, height follows content (`flex: 0 0 auto`). `inline`
     * (default): keeps the shared `1 1 120px` field column used by horizontal rows. */
    layout?: "stack" | "inline";
};
export declare const SINGLE_LINE_TEXT_FIELD_STACK_STYLE: CSSProperties;
export declare function SingleLineTextField({ label, type, value, onValue, disabled, hideLabel, placeholder, maxLength, onBlur, inputMode, fieldStyle, layout }: Props): import("react/jsx-runtime").JSX.Element;
export {};
