/** One inline edit session may commit once. Enter and the blur that follows
 * unmount both call the same function; React state has not flushed, so a
 * setState guard lets both through. This ref flips synchronously. */
export type InlineEditCommitGuard = {
    committed: boolean;
};
export declare function beginInlineEditCommit(guard: InlineEditCommitGuard): void;
/** First call in the session returns true and closes it. Later calls return false. */
export declare function claimInlineEditCommit(guard: InlineEditCommitGuard): boolean;
