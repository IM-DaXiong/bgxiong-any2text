/**
 * 模块：四边拖拽壳 — 类型定义（ui-edge-resize-shell/edgeResizeTypes）
 *
 * 职责：定义 EdgeKind、约束、壳状态等核心类型。
 *
 * 主要导出：
 * - EdgeKind: 8 个拖拽区域（四边 + 四角）
 * - EdgeResizeConstraints: minW/maxW/minH/maxH（必填）
 * - EdgeResizeBoxState: 壳层宽高数字状态
 *
 * 依赖：无运行时依赖。
 */
/** 拖拽方向：四边 + 四角 */
export type EdgeKind = "n" | "s" | "e" | "w" | "ne" | "nw" | "se" | "sw";
/** 尺寸约束（必填，禁止魔法默认值） */
export interface EdgeResizeConstraints {
    minW: number;
    maxW: number;
    minH: number;
    maxH: number;
}
/** 壳层宽高数字状态（px） */
export interface EdgeResizeBoxState {
    widthPx: number;
    heightPx: number;
}
