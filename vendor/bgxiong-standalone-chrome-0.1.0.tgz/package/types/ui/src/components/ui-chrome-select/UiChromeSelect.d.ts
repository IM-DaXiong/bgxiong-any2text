/**
 * UiChromeSelect — 统一原生 select 外观（与 UiChromeTextarea 同命名族）。
 *
 * 业务层只组装 option/optgroup children；禁止再写内联 select style。
 */
import { type CSSProperties, type ReactNode, type SelectHTMLAttributes } from "react";
export type UiChromeSelectLabelLayout = "stacked" | "inline";
export type UiChromeSelectProps = Omit<SelectHTMLAttributes<HTMLSelectElement>, "children"> & {
    /** 字段标题；hideLabel 时用作 aria-label */
    label: string;
    /** 工作台同排等场景：不渲染可见 label */
    hideLabel?: boolean;
    /** stacked = label above control (default); inline = label left of control */
    labelLayout?: UiChromeSelectLabelLayout;
    /** Use the full-height form control geometry in settings and dialogs. */
    controlSize?: "compact" | "form";
    /** 列壳样式；默认随 labelLayout */
    fieldColStyle?: CSSProperties;
    /** 悬停提示挂在列壳上（disabled select 仍可显示） */
    fieldTitle?: string;
    children: ReactNode;
};
export declare function UiChromeSelect({ label, hideLabel, labelLayout, controlSize, fieldColStyle, fieldTitle, disabled, id, style, children, ...selectProps }: UiChromeSelectProps): import("react/jsx-runtime").JSX.Element;
