/**
 * Optional host ports for RichPlainEditorCore.
 *
 * Standalone apps use `standaloneRichPlainHost` (no main-window API, no story.db,
 * no settings writes). The main program registers `mainRichPlainHost` at boot
 * (`installMainRichPlainHost`) so existing call sites keep persist, shortcuts,
 * clipboard, and toast behavior.
 */
import { type RichDoc, type RichPlainOwner } from "../../domain/rich-plain-text/types";
export type RichPlainToastFn = (message: string, opts?: {
    variant?: "success" | "error" | "info" | "warning";
    durationMs?: number;
}) => void;
export type RichPlainClipboardSpeech = {
    copied: string;
    cutDone: string;
    pasted: string;
    copyFailed: string;
    cutFailed: string;
    pasteFailed: string;
    selectFirst: string;
};
export type RichPlainClipboardOpts = {
    speech: RichPlainClipboardSpeech;
    rangeOverride?: {
        start: number;
        end: number;
    };
    requireNonCollapsed?: boolean;
};
export type RichPlainLocaleLike = {
    shortcuts?: {
        textareaWorkbench: {
            fontSizeIncrease: string;
            fontSizeDecrease: string;
        };
    };
    common: {
        clipboardCopied: string;
        clipboardCut: string;
        clipboardPasted: string;
        clipboardCopyFailed: string;
        clipboardCutFailed: string;
        clipboardPasteFailed: string;
        clipboardSelectFirst: string;
    };
};
export type RichPlainShortcutHandlers = {
    registerHandler: (actionId: string, handler: () => void) => unknown;
    unregisterHandler: (actionId: string, token: unknown) => void;
};
export type RichPlainHostPorts = {
    loadRichDocForPlain: (owner: RichPlainOwner, plain: string) => Promise<RichDoc>;
    writeRichSource: (owner: RichPlainOwner, plain: string, source: string) => Promise<void>;
    reportRichStyleSaveFailed: () => void;
    notifyToast: RichPlainToastFn;
    copyFormControl: (el: HTMLElement, toast: RichPlainToastFn, opts: RichPlainClipboardOpts) => Promise<boolean>;
    cutFormControl: (el: HTMLElement, toast: RichPlainToastFn, opts: RichPlainClipboardOpts) => Promise<boolean>;
    formClipboardSpeechFromLocale: (locale: RichPlainLocaleLike) => RichPlainClipboardSpeech;
    useI18n: () => RichPlainLocaleLike;
    useShortcutHandlers: () => RichPlainShortcutHandlers;
    log: (category: string, message: string, data?: unknown) => void;
    logError: (category: string, message: string, data?: unknown) => void;
};
export declare function useStandaloneI18n(): RichPlainLocaleLike;
export declare function useStandaloneShortcutHandlers(): RichPlainShortcutHandlers;
export declare const standaloneRichPlainHost: RichPlainHostPorts;
export declare function registerRichPlainHost(host: RichPlainHostPorts): void;
export declare function getRegisteredRichPlainHost(): RichPlainHostPorts | null;
/** Core / chrome default: registered main host, otherwise the standalone no-IPC host. */
export declare function resolveRichPlainHost(override?: RichPlainHostPorts): RichPlainHostPorts;
