import type { CSSProperties, KeyboardEvent as ReactKeyboardEvent, MouseEvent as ReactMouseEvent } from "react";
import type { ColorToken, RichPlainOwner } from "../../domain/rich-plain-text/types";
import type { EditorTypographySurface } from "../../domain/rich-plain-text/editorTypographyPrefs";
import type { RichPlainHostPorts } from "./hostPorts";
export type RichPlainEditorHandle = {
    focus: () => void;
    getSelection: () => {
        start: number;
        end: number;
    };
    setSelection: (start: number, end: number) => void;
    getPlain: () => string;
    getSource: () => string;
    hydrateFromSource: (source: string, expectedPlain: string) => void;
    getRootElement: () => HTMLDivElement | null;
    applyBold: () => void;
    applyColor: (token: ColorToken) => void;
    clearMarks: () => void;
    /** `opts.programmatic`: host-driven write (e.g. dictation under an operation lease); bypasses the user-input `disabled` lock. */
    replaceSelection: (text: string, range?: {
        start: number;
        end: number;
    }, opts?: {
        programmatic?: boolean;
    }) => void;
    /**
     * Pointer → UTF-16 plain offset for drag-drop insertion (§4.4).
     * null = outside editor (caller must not insert).
     */
    offsetFromPoint: (clientX: number, clientY: number) => number | null;
    undo: () => void;
    redo: () => void;
    selectAll: () => void;
};
export type RichPlainSourceOrigin = "edit" | "hydrate";
export type RichPlainEditorProps = {
    value: string;
    onValueChange: (plain: string) => void;
    onSourceChange?: (source: string, origin: RichPlainSourceOrigin) => void;
    richOwner?: RichPlainOwner;
    /** When set (including ""), skip IPC and hydrate from this bgx source. */
    hydrateSource?: string | null;
    placeholder?: string;
    disabled?: boolean;
    className?: string;
    style?: CSSProperties;
    spellCheck?: boolean;
    showBubble?: boolean;
    id?: string;
    "aria-label"?: string;
    "aria-describedby"?: string;
    "aria-invalid"?: boolean;
    onFocus?: () => void;
    onBlur?: () => void;
    onKeyDown?: (e: ReactKeyboardEvent<HTMLDivElement>) => void;
    onClick?: (e: ReactMouseEvent<HTMLDivElement>) => void;
    onCompositionStart?: () => void;
    onCompositionEnd?: () => void;
    /** Registered syntax profile id. Omit = no highlight work. */
    syntaxProfileId?: string;
    /** Pause idle deco refresh (mention menu open). */
    pauseSyntaxRefresh?: boolean;
    /** Pad thumbnail URLs keyed by image cite ordinal (INV-PROMPT-SYN-19). */
    citeImagePreviewByOrdinal?: Record<number, string>;
    /**
     * Stable media-ref preview URLs keyed by referenceId (@{ref:<id>}).
     * Always rendered; not gated by syntax-highlight enable or 65536 skip.
     */
    mediaRefPreviewById?: Record<string, string>;
    mediaRefLabelById?: Record<string, string>;
    /** Host chrome default; workbench keeps the version-history store. */
    typographySurface?: EditorTypographySurface;
    /**
     * Optional host ports. Omit to use the registered main host, or the
     * standalone no-IPC host when none is registered.
     */
    host?: RichPlainHostPorts;
};
export type { RichPlainHostPorts };
