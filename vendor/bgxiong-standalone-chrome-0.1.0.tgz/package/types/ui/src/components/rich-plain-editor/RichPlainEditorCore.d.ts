import type { RichPlainEditorHandle, RichPlainEditorProps } from "./richPlainEditorTypes";
export type { RichPlainEditorHandle, RichPlainEditorProps, RichPlainSourceOrigin } from "./richPlainEditorTypes";
export declare const RichPlainEditorCore: import("react").ForwardRefExoticComponent<RichPlainEditorProps & import("react").RefAttributes<RichPlainEditorHandle>>;
