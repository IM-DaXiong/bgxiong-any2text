/**
 * 主题早期水合逻辑（ui/src/theme/themeEarlyHydrate.ts）
 *
 * 职责：在 React bundle 加载前（HTML 内联脚本），读取 localStorage 设置 dataset.theme。
 * 上游：localStorage app_theme。
 * 下游：index.html / assistant.html 的 <head> 内联脚本（同源复制）。
 *
 * 此文件导出函数仅供 ThemeProvider 复用；HTML 内联脚本须手动复制同逻辑。
 */
/** 在 document.documentElement 上设置 dataset.theme（仅非 dark 主题触发） */
export declare function earlyHydrateTheme(): void;
