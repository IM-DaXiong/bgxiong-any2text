import { forwardRef as e, memo as t, useCallback as n, useEffect as r, useId as i, useImperativeHandle as a, useLayoutEffect as o, useMemo as s, useRef as c, useState as l } from "react";
import { Fragment as u, jsx as d, jsxs as f } from "react/jsx-runtime";
import { createPortal as p } from "react-dom";
//#region src/components/ui-edge-resize-shell/edgeResizeGeometry.ts
var m = ["s"], h = [
	"n",
	"s",
	"e",
	"w",
	"ne",
	"nw",
	"se",
	"sw"
];
function g(e, t, n) {
	switch (e) {
		case "n": return {
			left: t,
			top: -t,
			right: t,
			height: n
		};
		case "s": return {
			left: t,
			bottom: -t,
			right: t,
			height: n
		};
		case "e": return {
			top: t,
			right: -t,
			bottom: t,
			width: n
		};
		case "w": return {
			top: t,
			left: -t,
			bottom: t,
			width: n
		};
		case "ne": return {
			top: -t,
			right: -t,
			width: n,
			height: n
		};
		case "nw": return {
			top: -t,
			left: -t,
			width: n,
			height: n
		};
		case "se": return {
			bottom: -t,
			right: -t,
			width: n,
			height: n
		};
		case "sw": return {
			bottom: -t,
			left: -t,
			width: n,
			height: n
		};
	}
}
function _(e, t, n, r, i, a) {
	let { minW: o, maxW: s, minH: c, maxH: l } = a, u = e, d = t;
	return n.includes("e") ? u = e + r : n.includes("w") && (u = e - r), n.includes("s") ? d = t + i : n.includes("n") && (d = t - i), u = Math.max(o, Math.min(s, u)), d = Math.max(c, Math.min(l, d)), {
		nextW: u,
		nextH: d
	};
}
//#endregion
//#region src/components/ui-edge-resize-shell/useEdgeResizeBox.ts
function v({ defaultWidthPx: e, defaultHeightPx: t, constraints: r, onSizeCommit: i }) {
	let [a, s] = l(e), [u, d] = l(t), f = c({
		w: e,
		h: t
	}), p = c(i);
	p.current = i;
	let m = c(!1);
	o(() => {
		m.current || (t !== 0 && (d((e) => e === t ? e : t), f.current.h = t), e !== 0 && (s((t) => t === e ? t : e), f.current.w = e));
	}, [e, t]);
	let h = n((e, t) => {
		s(e), d(t);
	}, []), g = n((e, t, n) => {
		let i = f.current, { nextW: a, nextH: o } = _(i.w, i.h, e, t, n, r);
		s(a), d(o);
	}, [r]), v = c({
		w: a,
		h: u
	});
	v.current = {
		w: a,
		h: u
	};
	let y = n(() => {
		m.current = !1;
		let e = p.current;
		if (e) {
			let { w: t, h: n } = v.current;
			e(t, n);
		}
	}, []);
	return {
		widthPx: a,
		heightPx: u,
		setSize: h,
		startResize: n((e, t) => (m.current = !0, f.current = {
			w: t?.w ?? a,
			h: t?.h ?? u
		}, t?.w != null && s(t.w), t?.h != null && d(t.h), e), [a, u]),
		handleMove: g,
		handleEnd: y
	};
}
//#endregion
//#region src/components/common/layout/pointerDragBodyLock.ts
var y = "", b = "";
function ee(e) {
	y = document.body.style.userSelect, b = document.body.style.cursor, document.body.style.userSelect = "none", document.body.style.cursor = e;
}
function te() {
	document.body.style.userSelect = y, document.body.style.cursor = b, y = "", b = "";
}
//#endregion
//#region src/components/ui-edge-resize-shell/usePointerEdgeSession.ts
function ne({ onMove: e, onEnd: t, cursor: i }) {
	let a = c(null), o = c(e), s = c(t);
	o.current = e, s.current = t;
	let l = n((e) => {
		let t = a.current;
		if (!t || e.pointerId !== t.pointerId) return;
		let n = e.clientX - t.startX, r = e.clientY - t.startY;
		o.current(t.edge, n, r);
	}, []), u = n(function e(t) {
		let n = a.current;
		if (!n || t && t.pointerId !== n.pointerId) return;
		a.current = null;
		let r = n.target;
		r?.removeEventListener("pointermove", l), r?.removeEventListener("pointerup", e), r?.removeEventListener("pointercancel", e), r?.removeEventListener("lostpointercapture", e), r?.hasPointerCapture?.(n.pointerId) && r.releasePointerCapture(n.pointerId), te(), t && s.current();
	}, [l]);
	return r(() => () => u(), [u]), {
		onPointerDown: n((e) => (t) => {
			if (t.button !== 0 || a.current) return;
			t.preventDefault();
			let n = t.currentTarget;
			n.setPointerCapture(t.pointerId), ee(i), a.current = {
				edge: e,
				pointerId: t.pointerId,
				startX: t.clientX,
				startY: t.clientY,
				target: n
			}, n.addEventListener("pointermove", l), n.addEventListener("pointerup", u), n.addEventListener("pointercancel", u), n.addEventListener("lostpointercapture", u);
		}, [
			i,
			l,
			u
		]),
		finishSession: u
	};
}
//#endregion
//#region src/components/ui-edge-resize-shell/UiEdgeResizeShell.tsx
var re = {
	n: "ns-resize",
	s: "ns-resize",
	e: "ew-resize",
	w: "ew-resize",
	ne: "nesw-resize",
	nw: "nwse-resize",
	se: "nwse-resize",
	sw: "nesw-resize"
};
function ie(e) {
	if (!e) return {};
	let { width: t, height: n, ...r } = e;
	return r;
}
var ae = e(function({ edgeConstraints: e, defaultWidthPx: t, defaultHeightPx: r, contentHeight: i, onSizeCommit: a, shellClassName: l = "", shellStyle: u, children: p, shellRef: _, disableHorizontalResize: y = !1, canvasResizeHandles: b = !1, showBottomGrip: ee = !1, bottomOverlay: te }, ae) {
	let { widthPx: oe, heightPx: se, startResize: ce, handleMove: le, handleEnd: ue } = v({
		defaultWidthPx: t,
		defaultHeightPx: r,
		constraints: e,
		onSizeCommit: s(() => {
			if (a) return y ? (e, t) => {
				a(0, t);
			} : a;
		}, [a, y])
	}), de = c(null), x = c(!1), fe = c(!1);
	o(() => {
		if (t !== 0) return;
		let e = de.current;
		if (!e) return;
		let n = e.parentElement ?? e, r = (e) => {
			e <= 0 || x.current;
		}, i = new ResizeObserver((e) => {
			let t = e[0]?.contentRect;
			t && r(Math.round(t.width));
		});
		return i.observe(n), r(Math.round(n.getBoundingClientRect().width)), () => {
			i.disconnect();
		};
	}, [t]);
	let pe = n((e) => {
		de.current = e, typeof ae == "function" ? ae(e) : ae && (ae.current = e), typeof _ == "function" ? _(e) : _ && (_.current = e);
	}, [ae, _]), { onPointerDown: S } = ne({
		onMove: le,
		onEnd: ue,
		cursor: "default"
	}), C = y ? m : h, me = t === 0 && !x.current, he = r === 0 && !fe.current, ge = s(() => {
		let e = {};
		for (let n of C) e[n] = (e) => {
			b && e.stopPropagation();
			let i = !y || n !== "s" && n !== "n", a = n === "n" || n === "s" || n === "ne" || n === "nw" || n === "se" || n === "sw";
			i && (x.current = !0), a && (fe.current = !0);
			let o = de.current?.getBoundingClientRect(), s = {};
			t === 0 && o && o.width > 0 && (s.w = Math.round(o.width)), r === 0 && o && o.height > 0 && (s.h = Math.round(o.height)), ce(n, Object.keys(s).length > 0 ? s : void 0), S(n)(e);
		};
		return e;
	}, [
		ce,
		S,
		C,
		y,
		b,
		t,
		r
	]), w = 5 / 2, _e = b ? {
		"data-canvas-ui": !0,
		"data-canvas-resize-handle": "true"
	} : {}, ve = ["ui-edge-resize-shell", l].filter(Boolean).join(" "), T = ie(u), E = y || ee ? /* @__PURE__ */ d("div", { className: "ui-edge-resize-shell__bottom-grip" }) : null;
	return /* @__PURE__ */ f("div", {
		ref: pe,
		className: ve,
		style: {
			...me ? {
				width: "100%",
				maxWidth: "100%",
				minWidth: 0
			} : { width: oe },
			...he ? {
				flex: "1 1 0%",
				minHeight: 0,
				height: "auto",
				alignSelf: "stretch"
			} : i ? {
				height: "auto",
				minHeight: se
			} : { height: se },
			...T
		},
		"data-ui-input": "true",
		children: [
			/* @__PURE__ */ d("div", {
				className: "ui-edge-resize-shell__hits",
				children: C.map((e) => /* @__PURE__ */ d("div", {
					className: "ui-edge-resize-shell__hit",
					"data-edge": e,
					..._e,
					style: {
						...g(e, w, 5),
						...e === "s" && te ? {
							height: `calc(var(--ui-edge-resize-bottom-overlay-height) + ${w}px)`,
							...y ? {
								left: 0,
								right: 0
							} : null
						} : null,
						cursor: re[e]
					},
					onPointerDown: ge[e]
				}, e))
			}),
			/* @__PURE__ */ d("div", {
				className: "ui-edge-resize-shell__body",
				children: p
			}),
			te ? /* @__PURE__ */ f("div", {
				className: "ui-edge-resize-shell__bottom-overlay",
				children: [E, te]
			}) : E
		]
	});
});
//#endregion
//#region ../packages/dictation/ui/src/operation/applyMarks.ts
function oe(e, t, n) {
	return {
		start: Math.max(0, Math.min(t, n, e.length)),
		end: Math.max(0, Math.min(Math.max(t, n), e.length))
	};
}
function se(e, t, n) {
	let r = oe(e.plain, t, n);
	if (r.start === r.end) return !1;
	let i = Array(e.plain.length).fill(!1);
	for (let t of e.intervals) {
		if (t.bold === void 0) continue;
		let n = Math.max(0, t.start), r = Math.min(e.plain.length, t.end);
		for (let e = n; e < r; e++) i[e] = t.bold;
	}
	for (let e = r.start; e < r.end; e++) if (!i[e]) return !1;
	return !0;
}
function ce(e, t, n) {
	let r = oe(e.plain, t, n);
	if (r.start === r.end) return e;
	let i = !se(e, r.start, r.end);
	return {
		plain: e.plain,
		intervals: [...e.intervals, {
			start: r.start,
			end: r.end,
			bold: i
		}]
	};
}
function le(e, t, n, r) {
	let i = oe(e.plain, t, n);
	return i.start === i.end ? e : {
		plain: e.plain,
		intervals: [...e.intervals, {
			start: i.start,
			end: i.end,
			color: r
		}]
	};
}
function ue(e, t, n) {
	let r = oe(e.plain, t, n);
	return r.start === r.end ? e : {
		plain: e.plain,
		intervals: [...e.intervals, {
			start: r.start,
			end: r.end,
			bold: !1,
			color: null
		}]
	};
}
function de(e, t, n, r) {
	let i = oe(e.plain, t, n), a = i.end - i.start, o = r.length - a;
	return {
		plain: e.plain.slice(0, i.start) + r + e.plain.slice(i.end),
		intervals: e.intervals.map((e) => {
			let t = e.start, n = e.end;
			return n <= i.start ? e : t >= i.end ? {
				...e,
				start: t + o,
				end: n + o
			} : t >= i.start && n <= i.end ? null : t < i.start && n > i.end ? {
				...e,
				end: n + o
			} : t < i.start ? {
				...e,
				end: i.start
			} : {
				...e,
				start: i.start + r.length,
				end: n + o
			};
		}).filter((e) => e != null && e.end > e.start)
	};
}
//#endregion
//#region src/domain/rich-plain-text/escape.ts
function x(e) {
	return e.replace(/&/g, "&amp;").replace(/</g, "&lt;");
}
function fe(e, t) {
	return e.startsWith("&amp;", t) ? {
		char: "&",
		consumed: 5
	} : e.startsWith("&lt;", t) ? {
		char: "<",
		consumed: 4
	} : null;
}
//#endregion
//#region src/domain/rich-plain-text/flatten.ts
function pe(e) {
	let t = e.plain.length;
	if (t === 0) return [];
	if (e.intervals.length === 0) return [{
		text: e.plain,
		bold: !1,
		color: null
	}];
	let n = Array(t).fill(!1), r = Array(t).fill(null);
	for (let i of e.intervals) {
		let e = Math.max(0, Math.min(i.start, t)), a = Math.max(e, Math.min(i.end, t));
		for (let t = e; t < a; t++) i.bold !== void 0 && (n[t] = i.bold), i.color !== void 0 && (r[t] = i.color);
	}
	let i = [], a = 0;
	for (; a < t;) {
		let o = n[a] ?? !1, s = r[a] ?? null, c = a + 1;
		for (; c < t && (n[c] ?? !1) === o && (r[c] ?? null) === s;) c += 1;
		i.push({
			text: e.plain.slice(a, c),
			bold: o,
			color: s
		}), a = c;
	}
	return i;
}
function S(e) {
	return e.some((e) => e.bold || e.color != null);
}
function C(e) {
	let t = "", n = [];
	for (let r of e) {
		let e = t.length;
		t += r.text;
		let i = t.length;
		e !== i && (r.bold && n.push({
			start: e,
			end: i,
			bold: !0
		}), r.color && n.push({
			start: e,
			end: i,
			color: r.color
		}));
	}
	return {
		plain: t,
		intervals: n
	};
}
//#endregion
//#region src/domain/media-reference-editor/constants.ts
var me = /@\{ref:([A-Za-z0-9_-]+)\}/g;
//#endregion
//#region src/domain/media-reference-editor/token.ts
function he(e) {
	let t = [], n = new RegExp(me.source, "g"), r;
	for (; (r = n.exec(e)) !== null;) {
		let e = r[1] ?? "";
		t.push({
			referenceId: e,
			start: r.index,
			end: r.index + r[0].length
		});
	}
	return t;
}
//#endregion
//#region src/domain/media-reference-editor/mediaRefDisplay.ts
function ge(e) {
	let t = Object.create(null), n = Object.create(null);
	for (let { referenceId: r, label: i, previewUrl: a } of e) {
		t[r] = i;
		let e = (a ?? "").trim();
		e && (n[r] = e);
	}
	return {
		labels: t,
		previews: n
	};
}
function w(e, t) {
	return `@${(Object.hasOwn(t, e) ? t[e] : "") || "已移除图片"}`;
}
//#endregion
//#region src/domain/video-prompt-mention/projectMediaCite.ts
var _e = /(?<!@)@(图|音|视频)([1-9]\d*)(?![A-Za-z0-9_])/g;
function ve(e) {
	let t = [], n = new RegExp(_e.source, "g"), r;
	for (; (r = n.exec(e)) !== null;) {
		let e = Number(r[2]);
		Number.isSafeInteger(e) && (t.push({
			start: r.index,
			end: r.index + r[0].length,
			kind: r[1] === "图" ? "image" : r[1] === "音" ? "audio" : "video",
			ordinal: e
		}), r[0].length === 0 && (n.lastIndex += 1));
	}
	return t;
}
//#endregion
//#region src/domain/rich-plain-text/displayHtml.ts
function T(e) {
	return x(e).replace(/"/g, "&quot;");
}
function E(e = []) {
	let t = [...e].sort((e, t) => e.start - t.start), n = 0;
	return (e) => {
		for (; t[n]?.end <= e;) n += 1;
		let r = t[n];
		return r && r.start <= e ? {
			span: r,
			boundary: r.end
		} : {
			span: void 0,
			boundary: r?.start ?? Infinity
		};
	};
}
function D(e, t, n) {
	let r = E(t.decoSpans), i = E(t.mediaRefSpans), a = E(n), o = [], s = 0;
	for (let t of pe(e)) {
		let e = s + t.text.length, n = s;
		for (; n < e;) {
			let c = r(n), l = i(n), u = a(n), d = l.span || c.span?.kind === "dialogue" ? void 0 : u.span, f = Math.min(e, c.boundary, l.boundary, u.boundary);
			o.push({
				text: t.text.slice(n - s, f - s),
				bold: t.bold,
				color: t.color,
				deco: d ? "refTag" : c.span?.kind ?? null,
				cite: d ? {
					media: d.kind,
					ord: d.ordinal
				} : c.span?.cite ?? null,
				mediaRefId: l.span?.referenceId ?? null,
				projectCite: d ?? null
			}), n = f;
		}
		s = e;
	}
	return o;
}
function ye(e, t, n) {
	let r = x(e.text), i = e.bold ? `<strong>${r}</strong>` : r;
	if (e.mediaRefId) {
		let r = (t?.[e.mediaRefId] ?? "").trim(), a = r ? `<img data-media-ref-thumb="1" data-rich-display-only="1" draggable="false" alt="" src="${T(r)}" style="width:1.25em;height:1.25em;object-fit:cover;border-radius:2px;vertical-align:middle;margin-right:2px" />` : "";
		return n && e.text === `@{ref:${e.mediaRefId}}` ? `<span contenteditable="false" data-rich-source="${T(e.text)}" data-rich-deco="mediaRef" data-media-ref-id="${T(e.mediaRefId)}" style="display:inline-block;border-radius:4px;padding:0 3px;background:color-mix(in srgb, var(--accent) 14%, transparent)">${a}${x(w(e.mediaRefId, n))}</span>` : (i = `<span data-rich-deco="mediaRef" data-media-ref-id="${T(e.mediaRefId)}" data-media-ref-kind="image" style="display:inline;border-radius:4px;padding:0 2px;background:color-mix(in srgb, var(--accent) 14%, transparent)">${a}${i}</span>`, i);
	}
	e.color && (i = "<span data-rich-color=\"" + e.color + "\">" + i + "</span>");
	let a = e.cite ? " data-cite-kind=\"" + e.cite.media + "\" data-cite-ord=\"" + e.cite.ord + "\"" : "", o = e.projectCite && !e.color ? " data-project-media-cite=\"" + e.projectCite.kind + "\" data-project-media-ord=\"" + e.projectCite.ordinal + "\" style=\"display:inline;border-radius:4px;padding:0 2px;background:color-mix(in srgb, var(--accent) 14%, transparent)\"" : "";
	return e.deco && !e.color ? i = "<span data-rich-deco=\"" + e.deco + "\"" + a + o + ">" + i + "</span>" : a && (i = "<span" + a + ">" + i + "</span>"), i;
}
function be(e) {
	let t = 2048, n = [];
	for (let r = 0; r < e.length;) {
		let i = Math.min(r + t, e.length);
		if (i < e.length) {
			let n = Math.max(e.lastIndexOf(" ", i), e.lastIndexOf("\n", i));
			n > r + t / 2 ? i = n + 1 : e.charCodeAt(i) >= 56320 && e.charCodeAt(i) <= 57343 && (i += 1);
		}
		n.push("<span>" + x(e.slice(r, i)) + "</span>"), r = i;
	}
	return n.join("");
}
function xe(e, t) {
	let n = Array.isArray(t) ? { decoSpans: t } : t ?? {}, r = E(n.decoSpans?.filter((e) => e.kind === "dialogue"));
	return D(e, n, ve(e.plain).filter((e) => !r(e.start).span)).map((e) => n.chunkLongPlainRuns && e.text.length > 8192 && !e.bold && !e.color && !e.deco && !e.cite && !e.mediaRefId ? be(e.text) : ye(e, n.mediaRefPreviewById, n.mediaRefLabelById)).join("");
}
//#endregion
//#region src/domain/media-reference-editor/buildMediaRefDisplaySpans.ts
function Se(e) {
	return he(e).map((e) => ({
		start: e.start,
		end: e.end,
		referenceId: e.referenceId
	}));
}
function Ce(e) {
	return e ? Object.keys(e).sort().map((t) => `${t}=${e[t] ?? ""}`).join("\n") : "";
}
//#endregion
//#region ../packages/dictation/ui/src/operation/marks.ts
var we = [
	"c1",
	"c2",
	"c3",
	"c4",
	"c5",
	"c6"
], Te = "正文已保存，样式未写入";
function Ee(e) {
	return we.includes(e);
}
function De(e = "") {
	return {
		plain: e,
		intervals: []
	};
}
//#endregion
//#region src/components/rich-plain-editor/walkDom.ts
function Oe(e) {
	return e === "div" || e === "p" || e === "li" || e === "h1" || e === "h2";
}
function ke(e, t = !0) {
	let n = "", r = [], i = 0, a = !1, o = null, s = () => {
		let e = n.length;
		i !== e && (a && r.push({
			start: i,
			end: e,
			bold: !0
		}), o && r.push({
			start: i,
			end: e,
			color: o
		}));
	}, c = (e, t, r) => {
		e && ((t !== a || r !== o) && (s(), i = n.length, a = t, o = r), n += e);
	}, l = (t, r, i, a) => {
		if (t.nodeType === Node.TEXT_NODE) {
			c(t.textContent ?? "", r, i);
			return;
		}
		if (t.nodeType !== Node.ELEMENT_NODE) return;
		let o = t, s = o.tagName.toLowerCase(), u = o.getAttribute("data-rich-source");
		if (u !== null) {
			c(u, r, i);
			return;
		}
		if (s === "br") {
			c("\n", r, i);
			return;
		}
		let d = r, f = i;
		if ((s === "strong" || s === "b") && (d = !0), o.getAttribute("data-rich-display-only") === "1" || o.getAttribute("data-media-ref-thumb") === "1" || s === "img") return;
		if (s === "span") {
			let e = o.getAttribute("data-rich-color");
			e && Ee(e) && (f = e);
		}
		let p = Oe(s) && o !== e;
		p && n.length > 0 && !n.endsWith("\n") && c("\n", d, f);
		let m = Array.from(o.childNodes);
		for (let e of m) l(e, d, f, p ? o : a);
	};
	if (l(e, !1, null, null), t && n === "\n" && e.childNodes.length === 1) {
		let t = e.firstChild;
		if (t && t.nodeType === Node.ELEMENT_NODE && t.tagName.toLowerCase() === "br") return De("");
	}
	return s(), {
		plain: n,
		intervals: r
	};
}
function Ae(e, t, n) {
	let r = document.createRange();
	try {
		r.selectNodeContents(e), r.setEnd(t, n);
	} catch {
		return null;
	}
	let i = document.createElement("div");
	return i.appendChild(r.cloneContents()), ke(i, e.childNodes.length === 1 && e.firstChild?.nodeName === "BR").plain.length;
}
function je(e, t) {
	let n = e.querySelector("div,p,li,h1,h2,br,[data-rich-source],[data-rich-display-only],[data-media-ref-thumb]") !== null, r = (t, r) => {
		if (n) return Ae(e, t, r);
		let i = e.ownerDocument.createRange();
		i.selectNodeContents(e);
		try {
			i.setEnd(t, r);
		} catch {
			return null;
		}
		return i.toString().length;
	}, i = r(t.startContainer, t.startOffset);
	if (t.collapsed) return i === null ? null : {
		start: i,
		end: i
	};
	let a = r(t.endContainer, t.endOffset);
	return i == null || a == null ? null : {
		start: Math.min(i, a),
		end: Math.max(i, a)
	};
}
function Me(e, t, n) {
	let r = document.activeElement;
	if (!(r instanceof Node) || !e.contains(r)) return;
	let i = window.getSelection();
	if (!i) return;
	let a = k(e, t), o = k(e, n);
	if (!a || !o) return;
	let s = document.createRange();
	s.setStart(a.node, a.offset), s.setEnd(o.node, o.offset), i.removeAllRanges(), i.addRange(s);
}
function O(e, t, n) {
	let r = k(e, t), i = k(e, n);
	if (!r || !i) return null;
	let a = document.createRange();
	return a.setStart(r.node, r.offset), a.setEnd(i.node, i.offset), a;
}
function k(e, t) {
	if (t <= 0) return {
		node: e,
		offset: 0
	};
	let n = document.createTreeWalker(e, NodeFilter.SHOW_TEXT | NodeFilter.SHOW_ELEMENT, { acceptNode(e) {
		return e.parentElement?.closest("[data-rich-source], [data-rich-display-only=\"1\"]") || e instanceof HTMLElement && e.getAttribute("data-rich-display-only") === "1" ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT;
	} }), r = t, i = n.nextNode(), a = null;
	for (; i;) {
		let e = i instanceof HTMLElement ? i.getAttribute("data-rich-source") : null;
		if (e !== null) {
			let t = i.parentNode;
			if (!t) return a;
			let n = Array.from(t.childNodes).indexOf(i);
			if (r <= e.length) return {
				node: t,
				offset: n + (r > e.length / 2 ? 1 : 0)
			};
			r -= e.length, a = {
				node: t,
				offset: n + 1
			};
		} else if (i.nodeType === Node.ELEMENT_NODE && i.tagName.toLowerCase() === "br") {
			if (r <= 1) {
				let e = i.parentNode;
				return e ? {
					node: e,
					offset: Array.from(e.childNodes).indexOf(i) + 1
				} : a;
			}
			--r;
		} else if (i.nodeType === Node.TEXT_NODE) {
			let e = i.textContent ?? "";
			if (r <= e.length) return {
				node: i,
				offset: r
			};
			r -= e.length, a = {
				node: i,
				offset: e.length
			};
		}
		i = n.nextNode();
	}
	return a ?? {
		node: e,
		offset: e.childNodes.length
	};
}
//#endregion
//#region src/domain/media-reference-editor/offsetFromPoint.ts
function Ne(e, t, n, r) {
	let i = Pe(e, t, n, r);
	return i.kind === "outside" ? null : i.kind === "hit" ? i.offset : r;
}
function Pe(e, t, n, r) {
	let i = e.getBoundingClientRect();
	if (t < i.left || t > i.right || n < i.top || n > i.bottom) return { kind: "outside" };
	let a = e.ownerDocument, o = null;
	if (typeof a.caretRangeFromPoint == "function") o = a.caretRangeFromPoint(t, n);
	else if (typeof a.caretPositionFromPoint == "function") {
		let e = a.caretPositionFromPoint(t, n);
		if (e) {
			o = a.createRange();
			try {
				o.setStart(e.offsetNode, e.offset), o.collapse(!0);
			} catch {
				o = null;
			}
		}
	}
	if (!o || !e.contains(o.startContainer)) return { kind: "miss" };
	let s = je(e, o);
	return s ? {
		kind: "hit",
		offset: Math.max(0, Math.min(s.start, r)),
		range: o
	} : { kind: "miss" };
}
var Fe = "PROMPT_SYNTAX_PROFILE_MISSING", Ie = "PROMPT_SYNTAX_HIGHLIGHT_FAILED", Le = "PROMPT_SYNTAX", Re = /* @__PURE__ */ new Map();
function ze(e) {
	return Re.get(e);
}
//#endregion
//#region src/domain/prompt-syntax-highlight/bracketKeywords.ts
function Be(e) {
	return e.length > 65536 ? [] : A(e);
}
function A(e) {
	let t = [];
	for (let n of e.matchAll(/<[^<>\r\n]+>|〈[^〈〉\r\n]+〉/gu)) {
		let r = n[0], i = n.index, a = i + r.length;
		r.slice(1, -1).trim() && (r[0] === "<" && (e[i - 1] === "<" || e[a] === ">") || t.push({
			start: i,
			end: a,
			kind: "refTag"
		}));
	}
	return t;
}
//#endregion
//#region src/domain/prompt-syntax-highlight/profiles/citePush.ts
function j(e, t, n, r) {
	t.lastIndex = 0;
	let i;
	for (; (i = t.exec(e)) !== null;) r.push({
		start: i.index,
		end: i.index + i[0].length,
		kind: n
	}), i[0].length === 0 && (t.lastIndex += 1);
}
//#endregion
//#region src/domain/prompt-syntax-highlight/dialogue.ts
function Ve(e) {
	let t = [], n = -1;
	for (let r of e.matchAll(/<d>|<\/d>/g)) r[0] === "<d>" ? n = r.index : n >= 0 && (t.push({
		start: n,
		end: r.index + r[0].length,
		kind: "dialogue"
	}), n = -1);
	return t;
}
function He(e) {
	let t = [];
	return j(e, /\{[^{}]+\}/g, "dialogue", t), t;
}
var Ue = {
	schemaVersion: 1,
	baseKeys: [
		"integrated_multimodal_description",
		"overall_soundscape",
		"non_diegetic_music"
	],
	refKeys: [
		"subject_definitions",
		"summary",
		"retention_analysis",
		"detailed_description",
		"overall_soundscape",
		"non_diegetic_music"
	]
}, We = {
	schemaVersion: 1,
	purpose: "Reference-marker templates of the video prompt target adapters, one entry per projection profile (profileId@version). Single source for the Rust projectors (build.rs emits CITE_TPL_<rustConst>_<SLOT>). Each entry lists only the media slots its projector writes; which entry a target uses is decided by its projector, never by provider kind, model id or name.",
	profiles: {
		"h3@1": {
			rustConst: "H3",
			templates: {
				image: "<Picture {n}>",
				video: "<Video {n}>",
				audio: "<Audio {n}>"
			}
		},
		"seedance@1": {
			rustConst: "SEEDANCE",
			templates: {
				image: "图片{n}",
				video: "视频{n}",
				audio: "音频{n}"
			}
		},
		"kling.classic@1": {
			rustConst: "KLING_CLASSIC",
			templates: { image: "@image_{n}" }
		},
		"kling.omni@1": {
			rustConst: "KLING_OMNI",
			templates: {
				image: "<<<image_{n}>>>",
				video: "<<<video_{n}>>>"
			}
		},
		"kling.omni@2": {
			rustConst: "KLING_OMNI_V2",
			templates: {
				image: "@image_{n}",
				video: "@video_{n}"
			}
		},
		"wan@1": {
			rustConst: "WAN",
			templates: {
				image: "图{n}",
				video: "视频{n}",
				audio: "音频{n}"
			}
		}
	}
}, M = (e) => e.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), N = /* @__PURE__ */ new Map(), Ge = {
	"wan@1": [
		["image", "图片{n}"],
		["image", "Image {n}"],
		["video", "Video {n}"]
	],
	"kling.omni@1": [["subject", "<<<element_{n}>>>"]],
	"h3@1": [["subject", "<Subject {n}>"]]
};
function P(e) {
	let [t, n] = e.split("{n}"), r = /^\p{Script=Han}/u.test(t), i = t.startsWith("<") ? "(?<!<)" : r ? "@?" : "(?<![A-Za-z0-9_@])", a = n.endsWith(">") ? "(?!>)" : "(?![A-Za-z0-9_])", o = t.endsWith("_") || e === "<image{n}>" ? "" : t.endsWith(" ") ? "[ \\t]+" : "[ \\t]*";
	return RegExp(i + M(t.trimEnd()) + o + "([1-9][0-9]*)" + M(n) + a, "gu");
}
for (let e of Object.keys(We.profiles)) {
	let t = Object.entries(We.profiles[e].templates);
	N.set(e, [...t, ...Ge[e] ?? []].map(([e, t]) => ({
		media: e,
		pattern: P(t)
	})));
}
Array.from(new Set([...Ue.baseKeys, ...Ue.refKeys])).sort((e, t) => t.length - e.length);
//#endregion
//#region src/domain/prompt-syntax-highlight/resolveDecoSpans.ts
function Ke(e, t) {
	let n = Array(e).fill(!1);
	for (let r of t) {
		if (!r.color) continue;
		let t = Math.max(0, Math.min(r.start, e)), i = Math.max(t, Math.min(r.end, e));
		for (let e = t; e < i; e++) n[e] = !0;
	}
	return n;
}
function qe(e, t, n) {
	let r = e.length;
	if (r === 0 || r > 65536) return [];
	let i = Array(r).fill(!1), a = Ke(r, n), o = [];
	for (let e of t) {
		let t = Math.max(0, Math.min(e.start, r)), n = Math.max(t, Math.min(e.end, r)), s = t;
		for (; s < n;) {
			if (i[s] || a[s]) {
				s += 1;
				continue;
			}
			let t = s + 1;
			for (; t < n && !i[t] && !a[t];) t += 1;
			for (let e = s; e < t; e++) i[e] = !0;
			o.push({
				start: s,
				end: t,
				kind: e.kind,
				cite: e.cite
			}), s = t;
		}
	}
	return o;
}
//#endregion
//#region src/domain/prompt-syntax-highlight/tokenizePrompt.ts
var Je = /^<image[ \t]*([1-9][0-9]*)>$/i;
function Ye() {
	let e = "", t = /* @__PURE__ */ new Map();
	return function* (n, r) {
		if (!n || n.length > 65536) return t = /* @__PURE__ */ new Map(), [];
		let i = JSON.stringify([r.id, r.version]), a = i === e ? t : /* @__PURE__ */ new Map(), o = /* @__PURE__ */ new Map(), s = Ve(n);
		r.braceDialogue && s.push(...He(n));
		let c = [], l = [], u = 0;
		for (r.highlightLine || c.push(...r.highlight(n)); u <= n.length;) {
			let e = n.indexOf("\n", u), t = e === -1 ? n.length : e, i = n.slice(u, t), d = o.get(i) ?? a.get(i);
			d ||= [...Be(i).flatMap((e) => {
				let t = i.slice(e.start, e.end);
				if (t === "<d>" || t === "</d>") return [];
				let n = Number(Je.exec(t)?.[1]);
				return [Number.isSafeInteger(n) ? {
					...e,
					cite: {
						media: "image",
						ord: n
					}
				} : e];
			}), ...r.highlightLine?.(i) ?? []], o.set(i, d);
			for (let e of d) {
				let t = {
					...e,
					start: e.start + u,
					end: e.end + u
				};
				e.kind === "dialogue" ? s.push(t) : e.kind === "refTag" && !e.cite ? l.push(t) : c.push(t);
			}
			u = t + 1, yield;
		}
		return e = i, t = o, qe(n, [
			...s,
			...c,
			...l
		], []);
	};
}
//#endregion
//#region src/domain/prompt-syntax-highlight/highlightEnabled.ts
var F = "bgx.promptSyntaxHighlight.enabled.v1", Xe = /* @__PURE__ */ new Set();
function Ze() {
	try {
		let e = localStorage.getItem(F);
		return e === null ? !0 : e === "1";
	} catch {
		return !0;
	}
}
function Qe(e) {
	Xe.add(e);
	let t = (t) => {
		t.key === "bgx.promptSyntaxHighlight.enabled.v1" && e();
	};
	return window.addEventListener("storage", t), () => {
		Xe.delete(e), window.removeEventListener("storage", t);
	};
}
//#endregion
//#region src/components/rich-plain-editor/usePromptImageHover.ts
function $e(e, t, i, a, o) {
	let s = c(null), [u, d] = l(null), f = n(() => {
		s.current && (s.current = null, d(null));
	}, []);
	return r(() => (f(), window.addEventListener("scroll", f, !0), window.addEventListener("resize", f), () => {
		window.removeEventListener("scroll", f, !0), window.removeEventListener("resize", f);
	}), [
		e,
		t,
		i,
		a,
		o,
		f
	]), {
		hover: u,
		target: s,
		show: (e, t, n, r, i) => {
			if (s.current?.element === e && s.current.url === t && s.current.range === n) return;
			let a = e.getBoundingClientRect();
			if (n) {
				let e = Array.from(n.getClientRects()).find((e) => r !== void 0 && i !== void 0 && r >= e.left && r <= e.right && i >= e.top && i <= e.bottom);
				if (!e) {
					f();
					return;
				}
				a = e;
			}
			s.current = {
				element: e,
				url: t,
				range: n
			}, d({
				url: t,
				centerX: a.left + a.width / 2,
				top: a.top,
				bottom: a.bottom
			});
		},
		close: f
	};
}
//#endregion
//#region src/components/rich-plain-editor/longPromptHighlights.ts
function et(e, t, n) {
	return e.length >= 32768 && !e.includes("\n") && !/@(?:图|音|视频)\d/.test(e) && !t && !n && typeof Highlight < "u" && typeof CSS < "u" && !!CSS.highlights;
}
function tt(e, t) {
	let n = /* @__PURE__ */ new Map(), r = [], i = e.ownerDocument.createTreeWalker(e, NodeFilter.SHOW_TEXT), a = i.nextNode(), o = 0, s = (e) => {
		for (; a && e > o + a.length;) o += a.length, a = i.nextNode();
		return a ? {
			node: a,
			offset: e - o
		} : null;
	};
	for (let i of [...t].sort((e, t) => e.start - t.start)) {
		let t = s(i.start), a = s(i.end);
		if (!t || !a) break;
		let o = e.ownerDocument.createRange();
		o.setStart(t.node, t.offset), o.setEnd(a.node, a.offset);
		let c = n.get(i.kind);
		c ? c.push(o) : n.set(i.kind, [o]), i.cite?.media === "image" && r.push({
			range: o,
			ord: i.cite.ord,
			start: i.start,
			end: i.end
		});
	}
	let c = [];
	for (let [e, t] of n) {
		let n = "bgx-prompt-" + e, r = CSS.highlights.get(n) ?? new Highlight();
		for (let e of t) r.add(e);
		CSS.highlights.set(n, r), c.push({
			highlight: r,
			ranges: t
		});
	}
	return {
		imageAt(e) {
			let t = 0, n = r.length;
			for (; t < n;) {
				let i = t + n >>> 1, a = r[i];
				if (e < a.start) n = i;
				else if (e >= a.end) t = i + 1;
				else return a;
			}
		},
		clear() {
			for (let { highlight: e, ranges: t } of c) for (let n of t) e.delete(n);
		}
	};
}
//#endregion
//#region src/components/rich-plain-editor/replaceChangedDisplay.ts
function nt(e, t) {
	let n = e.ownerDocument.createElement("template");
	n.innerHTML = t;
	let r = Array.from(e.childNodes), i = Array.from(n.content.childNodes), a = 0, o = r.length, s = i.length;
	for (; a < o && a < s && r[a].isEqualNode(i[a]);) a += 1;
	for (; a < o && a < s && r[o - 1].isEqualNode(i[s - 1]);) --o, --s;
	for (let t = a; t < o; t += 1) e.removeChild(r[t]);
	if (a < s) {
		let t = e.ownerDocument.createDocumentFragment();
		for (let e = a; e < s; e += 1) t.append(i[e]);
		e.insertBefore(t, r[o] ?? null);
	}
}
//#endregion
//#region src/domain/rich-plain-text/liveRegistry.ts
var rt = /* @__PURE__ */ new Map(), it = /* @__PURE__ */ new Map();
function at(e) {
	if (e) for (let t of it.get(ot(e)) ?? []) t();
}
function ot(e) {
	return `${e.ownerKind}\0${e.ownerId}\0${e.fieldKey}`;
}
function st(e) {
	return !e?.ownerId?.trim() || !e.fieldKey?.trim() ? "" : `${e.ownerKind}\0${e.ownerId}\0${e.fieldKey}\0${e.storyId ?? ""}`;
}
function ct(e, t) {
	let n = rt.get(e);
	rt.set(e, t), n && ot(n.owner) !== ot(t.owner) && at(n.owner), at(t.owner);
}
function lt(e) {
	let t = rt.get(e);
	rt.delete(e), at(t?.owner);
}
//#endregion
//#region src/domain/rich-plain-text/editorDomRegistry.ts
var ut = /* @__PURE__ */ new WeakMap();
function dt(e, t) {
	ut.set(e, t);
}
function ft(e) {
	ut.delete(e);
}
//#endregion
//#region src/domain/rich-plain-text/parse.ts
var pt = "<bgx-b>", mt = "</bgx-b>", ht = "</bgx-c>";
function gt(e, t) {
	if (!e.startsWith("<bgx-c v=\"", t)) return null;
	let n = t + 10, r = e.slice(n, n + 2);
	return !Ee(r) || e.slice(n + 2, n + 4) !== "\">" ? null : {
		color: r,
		consumed: 14
	};
}
function _t(e) {
	if (e.length === 0) return {
		ok: !0,
		doc: {
			plain: "",
			intervals: []
		}
	};
	let t = 0, n = "", r = [], i = [], a = (e) => ({
		ok: !1,
		reason: e
	});
	for (; t < e.length;) {
		let o = e[t];
		if (o === "&") {
			let r = fe(e, t);
			if (!r) return a("bare_ampersand");
			n += r.char, t += r.consumed;
			continue;
		}
		if (o === "<") {
			if (e.startsWith(pt, t)) {
				i.push({
					kind: "b",
					start: n.length
				}), t += 7;
				continue;
			}
			if (e.startsWith(mt, t)) {
				let e = i.pop();
				if (!e || e.kind !== "b") return a("tag_mismatch_b");
				r.push({
					start: e.start,
					end: n.length,
					bold: !0
				}), t += 8;
				continue;
			}
			let o = gt(e, t);
			if (o) {
				i.push({
					kind: "c",
					start: n.length,
					color: o.color
				}), t += o.consumed;
				continue;
			}
			if (e.startsWith(ht, t)) {
				let e = i.pop();
				if (!e || e.kind !== "c") return a("tag_mismatch_c");
				r.push({
					start: e.start,
					end: n.length,
					color: e.color
				}), t += 8;
				continue;
			}
			return a("unknown_tag");
		}
		n += o, t += 1;
	}
	return i.length > 0 ? a("unclosed_tag") : {
		ok: !0,
		doc: {
			plain: n,
			intervals: r
		}
	};
}
//#endregion
//#region src/domain/rich-plain-text/serialize.ts
function vt(e) {
	let t = x(e.text);
	return e.color && e.bold ? `<bgx-c v="${e.color}"><bgx-b>${t}</bgx-b></bgx-c>` : e.color ? `<bgx-c v="${e.color}">${t}</bgx-c>` : e.bold ? `<bgx-b>${t}</bgx-b>` : t;
}
function yt(e) {
	return pe(e).map(vt).join("");
}
function bt(e) {
	return S(pe(e));
}
function xt(e) {
	return {
		plain: e.plain,
		intervals: e.intervals.map((e) => ({ ...e }))
	};
}
function I(e) {
	return {
		doc: xt(e.doc),
		selection: {
			start: e.selection.start,
			end: e.selection.end
		}
	};
}
function St(e) {
	return {
		past: [],
		present: I(e),
		future: [],
		lastInputAt: null
	};
}
function Ct(e, t) {
	if (e.plain !== t.plain || e.intervals.length !== t.intervals.length) return !1;
	for (let n = 0; n < e.intervals.length; n++) {
		let r = e.intervals[n], i = t.intervals[n];
		if (!r || !i || r.start !== i.start || r.end !== i.end || r.bold !== i.bold || r.color !== i.color) return !1;
	}
	return !0;
}
function wt(e) {
	return e.length <= 100 ? e : e.slice(e.length - 100);
}
function Tt(e, t, n, r) {
	return Ct(e.present.doc, t.doc) ? {
		...e,
		present: I(t)
	} : n === "input" && e.lastInputAt != null && r - e.lastInputAt <= 400 ? {
		past: e.past,
		present: I(t),
		future: [],
		lastInputAt: r
	} : {
		past: wt([...e.past, I(e.present)]),
		present: I(t),
		future: [],
		lastInputAt: n === "input" ? r : null
	};
}
function Et(e) {
	if (e.past.length === 0) return {
		state: e,
		applied: null
	};
	let t = e.past[e.past.length - 1];
	return t ? {
		state: {
			past: e.past.slice(0, -1),
			present: I(t),
			future: [I(e.present), ...e.future],
			lastInputAt: null
		},
		applied: I(t)
	} : {
		state: e,
		applied: null
	};
}
function Dt(e) {
	if (e.future.length === 0) return {
		state: e,
		applied: null
	};
	let t = e.future[0];
	return t ? {
		state: {
			past: wt([...e.past, I(e.present)]),
			present: I(t),
			future: e.future.slice(1),
			lastInputAt: null
		},
		applied: I(t)
	} : {
		state: e,
		applied: null
	};
}
function Ot(e) {
	return !(e.ctrlKey || e.metaKey) || e.altKey ? null : e.code === "KeyZ" && e.shiftKey ? "redo" : e.code === "KeyZ" ? "undo" : e.code === "KeyY" && !e.shiftKey ? "redo" : e.code === "KeyA" && !e.shiftKey ? "selectAll" : null;
}
//#endregion
//#region src/domain/overlay-placement/placeAnchoredFixedPanel.ts
function kt() {
	return typeof window > "u" ? {
		left: 0,
		top: 0,
		right: 800,
		bottom: 600
	} : {
		left: 0,
		top: 0,
		right: window.innerWidth,
		bottom: window.innerHeight
	};
}
function At(e) {
	return {
		left: e.left,
		top: e.top,
		right: e.right,
		bottom: e.bottom,
		width: e.width,
		height: e.height
	};
}
function jt(e, t, n) {
	return n < t ? t : Math.min(n, Math.max(t, e));
}
function Mt(e) {
	let t = e.margin ?? 8, n = e.gap ?? 4, r = e.maxHeightCap ?? 400, i = e.minHeightFloor ?? 120, { trigger: a, bounds: o } = e, s = Math.max(0, o.right - o.left - t * 2), c = Math.min(s, e.maxWidth, Math.max(a.width, e.minWidth)), l;
	e.horizontalAlign === "center" ? l = a.left + a.width / 2 - c / 2 : (l = a.left, l + c > o.right - t && (l = a.right - c)), l = jt(l, o.left + t, o.right - t - c);
	let u = o.bottom - a.bottom - t, d = a.top - o.top - t, f = e.preferBelowIfPx, p = (e, t) => e < f && t > e, m = e.preferOpenUp ? !p(d, u) : p(u, d), h = Math.max(i, o.bottom - o.top - t * 2), g = Math.min(r, h), _ = (m ? d : u) - n, v = Math.min(g, Math.max(i, _));
	v = Math.min(v, h);
	let y = m ? a.top - v - n : a.bottom + n;
	return y = jt(y, o.top + t, o.bottom - t - v), {
		top: y,
		left: l,
		width: c,
		maxHeight: v,
		openUp: m
	};
}
//#endregion
//#region src/components/modal/modalZIndex.ts
var L = {
	BASE: 10100,
	TEXTAREA_VERSION_HISTORY: 10100,
	TEXTAREA_WORKBENCH_OPEN_LOADING: 10101,
	WORKBENCH: 10002,
	VIDEO_GENERATION_WORKBENCH: 10030,
	DIALOGUE_AUDIO_WORKBENCH: 10032,
	FC_AUDIO_WORKBENCH: 10033,
	FC_IMAGE_WORKBENCH: 10033,
	FC_VIDEO_WORKBENCH: 10033,
	VIDEO_EDIT_CONTEXT_MENU: 10034,
	VIDEO_UPSCALE_WORKBENCH: 10033,
	VIDEO_FACE_REFINE_WORKBENCH: 10033,
	IMAGE_UPSCALE_WORKBENCH: 10033,
	FC_TEXT_SEGMENT: 10033,
	FC_TEXT_STORYBOARD: 10033,
	DIALOGUE_SEGMENT_MODE: 10034,
	FC_TEMPLATE_PROGRESS: 10040,
	TTS_REF_LIBRARY: 10050,
	TTS_REF_LIBRARY_PROGRESS: 10051,
	AUDIO_EDIT_WORKBENCH: 10052,
	SINGING_RELYRICS_WORKBENCH: 10052,
	MEDIA_CONCAT_WORKBENCH: 10052,
	TTS_REF_LIBRARY_ENROLL: 10053,
	VIDEO_WORKBENCH_SESSION_HISTORY: 10035,
	VIDEO_WORKBENCH_PLAYER: 10036,
	VIDEO_PLAYER: 10025,
	PAD_PICKER: 10050,
	LIGHTBOX: 10100,
	IMAGE_METADATA: 10200,
	MODEL_PICKER_DROPDOWN: 10250,
	CONTENT_SKILL_LISTBOX: 10260,
	SHORTCUT_HOVER_TIP: 10300,
	COPY_MENU: 10150,
	RICH_PLAIN_FORMAT_BUBBLE: 10140,
	PROMO_NOTICE: 10080,
	SIDEBAR_FLOATING: 10900,
	APP_UPDATE_MANDATORY_GATE: 100001
};
L.VIDEO_PLAYER, L.VIDEO_GENERATION_WORKBENCH, L.VIDEO_WORKBENCH_SESSION_HISTORY, L.VIDEO_GENERATION_WORKBENCH, L.AUDIO_EDIT_WORKBENCH, L.FC_AUDIO_WORKBENCH, L.AUDIO_EDIT_WORKBENCH, L.DIALOGUE_AUDIO_WORKBENCH, L.TTS_REF_LIBRARY, L.FC_AUDIO_WORKBENCH, L.TTS_REF_LIBRARY_PROGRESS, L.TTS_REF_LIBRARY, L.AUDIO_EDIT_WORKBENCH, L.TTS_REF_LIBRARY_PROGRESS, L.TTS_REF_LIBRARY_ENROLL, L.TTS_REF_LIBRARY, L.TEXTAREA_VERSION_HISTORY, L.TEXTAREA_VERSION_HISTORY, L.VIDEO_GENERATION_WORKBENCH, L.SHORTCUT_HOVER_TIP, L.TEXTAREA_VERSION_HISTORY, L.PROMO_NOTICE, L.BASE, L.PROMO_NOTICE, L.APP_UPDATE_MANDATORY_GATE, L.RICH_PLAIN_FORMAT_BUBBLE, L.TEXTAREA_VERSION_HISTORY, L.RICH_PLAIN_FORMAT_BUBBLE, L.LIGHTBOX, L.RICH_PLAIN_FORMAT_BUBBLE, L.FC_TEMPLATE_PROGRESS, L.RICH_PLAIN_FORMAT_BUBBLE, L.RICH_PLAIN_FORMAT_BUBBLE, L.COPY_MENU, L.RICH_PLAIN_FORMAT_BUBBLE, L.SHORTCUT_HOVER_TIP, L.SIDEBAR_FLOATING, L.SIDEBAR_FLOATING, L.MODEL_PICKER_DROPDOWN, L.BASE, L.MODEL_PICKER_DROPDOWN, L.LIGHTBOX, L.MODEL_PICKER_DROPDOWN, L.IMAGE_METADATA, L.MODEL_PICKER_DROPDOWN, L.MODEL_PICKER_DROPDOWN, L.CONTENT_SKILL_LISTBOX, L.IMAGE_METADATA, L.CONTENT_SKILL_LISTBOX, L.SHORTCUT_HOVER_TIP;
//#endregion
//#region src/theme/typographyScale.ts
var R = {
	text2xs: "var(--text-2xs)",
	textXs: "var(--text-xs)",
	textSm: "var(--text-sm)",
	textMd: "var(--text-md)",
	textLg: "var(--text-lg)",
	textXl: "var(--text-xl)",
	text2xl: "var(--text-2xl)",
	text3xl: "var(--text-3xl)",
	caption: { fontSize: "var(--text-xs)" }
};
//#endregion
//#region src/components/common/button/btnShortcutPort.ts
function Nt(e) {
	return null;
}
var Pt = null;
function Ft(e) {
	return (Pt ?? Nt)(e);
}
function z(e) {
	let { hostRef: t, label: n, open: i, onDismiss: a } = e, [s, c] = l(i), [u, f] = l(!1), [m, h] = l(null);
	return o(() => {
		if (!i) return;
		let e = t.current;
		if (!e) return;
		let n = e.getBoundingClientRect();
		h({
			left: n.left + n.width / 2,
			top: n.top
		});
	}, [
		i,
		t,
		n
	]), r(() => {
		if (i) {
			c(!0);
			let e = window.requestAnimationFrame(() => f(!0));
			return () => window.cancelAnimationFrame(e);
		}
		f(!1);
		let e = window.setTimeout(() => c(!1), 140);
		return () => window.clearTimeout(e);
	}, [i]), r(() => {
		if (!i) return;
		let e = () => a();
		return window.addEventListener("scroll", e, !0), window.addEventListener("resize", e), () => {
			window.removeEventListener("scroll", e, !0), window.removeEventListener("resize", e);
		};
	}, [i, a]), !s || !m || typeof document > "u" ? null : p(/* @__PURE__ */ d("span", {
		role: "tooltip",
		"aria-hidden": !0,
		style: {
			position: "fixed",
			left: m.left,
			top: m.top,
			transform: "translate(-50%, calc(-100% - 6px))",
			opacity: u ? 1 : 0,
			transition: "opacity 140ms ease-out",
			pointerEvents: "none",
			zIndex: L.SHORTCUT_HOVER_TIP,
			padding: "4px 8px",
			borderRadius: "var(--radius)",
			border: "1px solid var(--border)",
			background: "var(--surface)",
			color: "var(--text1)",
			fontSize: R.textSm,
			fontWeight: 500,
			whiteSpace: "nowrap",
			boxShadow: "var(--shadow-md)"
		},
		children: n
	}), t.current?.closest("dialog[open]") ?? document.body);
}
//#endregion
//#region src/components/common/button/Btn.tsx
var It = {
	primary: {
		background: "var(--primary)",
		color: "var(--primary-fg)",
		fontWeight: 600,
		boxShadow: "0 1px 4px var(--primary-glow)"
	},
	secondary: {
		background: "var(--surface3)",
		color: "var(--text2)",
		border: "1px solid var(--border)",
		boxShadow: "0 1px 3px rgba(0,0,0,0.25)"
	},
	danger: {
		background: "var(--danger-bg)",
		color: "var(--danger)",
		border: "1px solid rgba(239,68,68,0.25)"
	},
	ghost: {
		background: "transparent",
		color: "var(--text3)"
	},
	accent: {
		background: "var(--accent-soft)",
		color: "var(--accent)",
		border: "1px solid rgba(245,158,11,0.3)"
	},
	ai: {
		background: "var(--ai)",
		color: "var(--ai-fg)",
		fontWeight: 600,
		boxShadow: "0 1px 4px var(--ai-glow)"
	}
}, Lt = e(function({ onClick: e, children: t, variant: n = "primary", size: r, disabled: i, style: a, nativeTitle: o, ariaBusy: s, onPointerDown: c, type: l = "button", "aria-label": u, "aria-pressed": f, "aria-expanded": p, "aria-haspopup": m, "aria-selected": h, "data-testid": g, role: _, tabIndex: v, "aria-keyshortcuts": y }, b) {
	return /* @__PURE__ */ d("button", {
		ref: b,
		type: l,
		"data-ui-btn-variant": n,
		onClick: e,
		onPointerDown: c,
		disabled: i,
		title: o,
		"aria-label": u,
		"aria-pressed": f,
		"aria-expanded": p,
		"aria-haspopup": m,
		"aria-selected": h,
		"data-testid": g,
		role: _,
		tabIndex: v,
		"aria-keyshortcuts": y,
		"aria-busy": s === !0 ? !0 : void 0,
		style: {
			padding: r === "compact" ? "2px 6px" : "5px 12px",
			flexShrink: r === "compact" ? 0 : void 0,
			borderRadius: "var(--radius)",
			fontSize: R.textSm,
			fontWeight: 500,
			whiteSpace: "nowrap",
			opacity: i ? .5 : 1,
			cursor: i ? "not-allowed" : "pointer",
			...It[n],
			...a
		},
		children: t
	});
});
function B(e) {
	let { shortcutActionId: t, shortcutLabel: r, forwardedRef: i, title: a, ...o } = e, s = Ft(t), u = r ?? s, p = c(null), [m, h] = l(!1), [g, _] = l(!1), v = n(() => {
		h(!1), _(!1);
	}, []);
	return /* @__PURE__ */ f("span", {
		ref: p,
		style: {
			display: "inline-flex",
			verticalAlign: "middle"
		},
		onMouseEnter: () => h(!0),
		onMouseLeave: () => h(!1),
		onFocus: () => _(!0),
		onBlur: () => _(!1),
		children: [/* @__PURE__ */ d(Lt, {
			ref: i,
			...o,
			nativeTitle: u ? void 0 : a
		}), u ? /* @__PURE__ */ d(z, {
			hostRef: p,
			label: u,
			open: m || g,
			onDismiss: v
		}) : null]
	});
}
var V = e(function(e, t) {
	let { shortcutActionId: n, title: r, ...i } = e;
	return !n && !i.shortcutLabel ? /* @__PURE__ */ d(Lt, {
		ref: t,
		...i,
		nativeTitle: r
	}) : /* @__PURE__ */ d(B, {
		...i,
		title: r,
		shortcutActionId: n,
		forwardedRef: t
	});
}), Rt = {
	fontSize: R.textSm,
	fontWeight: 600,
	color: "var(--text1)",
	lineHeight: "16px"
};
//#endregion
//#region src/components/common/form/choiceStyles.ts
function zt(e, t) {
	return t != null && t !== !1 && t !== "" ? !0 : e == null || e === !1 ? !1 : typeof e == "string" ? e.length > 0 : !0;
}
var Bt = {
	flexShrink: 0,
	width: 16,
	height: 16,
	marginTop: 3,
	boxSizing: "border-box",
	borderRadius: 3,
	border: "1px solid var(--border)",
	background: "var(--surface2)",
	display: "flex",
	alignItems: "center",
	justifyContent: "center",
	pointerEvents: "none"
}, Vt = {
	fontSize: R.textXs,
	lineHeight: 1,
	color: "#fff",
	fontWeight: 700
}, Ht = {
	display: "flex",
	alignItems: "flex-start",
	gap: 8,
	fontSize: R.textSm,
	color: "var(--text1)",
	lineHeight: 1.5,
	userSelect: "none"
};
({ ...Rt });
var Ut = {
	fontSize: R.textSm,
	color: "var(--text2)",
	lineHeight: 1.45
}, Wt = "ui-choice-capsule", Gt = "ui-choice-capsule__mark", Kt = "ui-choice-capsule__text", qt = "ui-choice-capsule__hint";
//#endregion
//#region src/components/common/form/ChoiceCapsuleBody.tsx
function Jt(e) {
	let t = zt(e.label, e.hint);
	return /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("span", {
		"aria-hidden": !0,
		className: `${Gt} ${Gt}--${e.kind}`,
		children: e.kind === "checkbox" && e.checked ? "✓" : null
	}), t ? /* @__PURE__ */ f("span", {
		className: Kt,
		children: [/* @__PURE__ */ d("span", { children: e.label }), e.hint ? /* @__PURE__ */ d("span", {
			className: qt,
			children: e.hint
		}) : null]
	}) : null] });
}
//#endregion
//#region src/components/common/form/UiCheckbox.tsx
var H = t(function(e) {
	let { checked: t, onChange: r, disabled: i = !1, dimmed: a = !1, label: o, ariaLabel: s, hint: c, title: l, id: u, appearance: f = "plain", testId: p } = e, m = zt(o, c), h = n(() => {
		i || r(!t);
	}, [
		t,
		i,
		r
	]), g = n((e) => {
		i || (e.key === " " || e.key === "Enter") && (e.preventDefault(), r(!t));
	}, [
		t,
		i,
		r
	]), _ = f === "capsule";
	return /* @__PURE__ */ d("div", {
		id: u,
		role: "checkbox",
		"aria-label": s,
		"aria-checked": t,
		"aria-disabled": i,
		title: l,
		tabIndex: i ? -1 : 0,
		"data-testid": p,
		"data-choice-appearance": f,
		className: _ ? Wt : void 0,
		onClick: h,
		onKeyDown: g,
		style: _ ? a ? { opacity: .55 } : void 0 : {
			...Ht,
			alignItems: m ? Ht.alignItems : "center",
			opacity: a ? .55 : 1,
			cursor: i ? "not-allowed" : "pointer"
		},
		children: _ ? /* @__PURE__ */ d(Jt, {
			kind: "checkbox",
			checked: t,
			label: o,
			hint: c
		}) : /* @__PURE__ */ d(Yt, {
			checked: t,
			label: o,
			hint: c,
			showTextColumn: m
		})
	});
});
function Yt(e) {
	let { checked: t, label: n, hint: r, showTextColumn: i } = e;
	return /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("span", {
		"aria-hidden": !0,
		style: {
			...Bt,
			marginTop: i ? Bt.marginTop : 0,
			borderColor: t ? "var(--primary)" : "var(--border)",
			background: t ? "var(--primary)" : "var(--surface2)"
		},
		children: t ? /* @__PURE__ */ d("span", {
			style: Vt,
			children: "✓"
		}) : null
	}), i ? /* @__PURE__ */ f("span", {
		style: {
			flex: 1,
			minWidth: 0
		},
		children: [/* @__PURE__ */ d("span", { children: n }), r ? /* @__PURE__ */ d("div", {
			style: {
				marginTop: 2,
				...Ut
			},
			children: r
		}) : null]
	}) : null] });
}
//#endregion
//#region src/components/common/form/CheckboxField.tsx
var U = t(function(e) {
	return /* @__PURE__ */ d(H, { ...e });
});
//#endregion
//#region src/domain/rich-plain-text/findReplace.ts
function Xt(e, t) {
	let n = [];
	if (!t) return n;
	let r = 0;
	for (; r <= e.length - t.length;) {
		let i = e.indexOf(t, r);
		if (i < 0) break;
		n.push({
			start: i,
			end: i + t.length
		}), r = i + t.length;
	}
	return n;
}
function Zt(e, t, n, r) {
	let i = Xt(e.plain, t);
	if (!i.length) return {
		doc: e,
		count: 0,
		selection: {
			start: 0,
			end: 0
		}
	};
	let a = pe(e), o = [], s = 0, c = 0, l = 0, u = (t, n) => {
		for (; l < t && s < a.length;) {
			let r = a[s];
			if (!r) break;
			let i = Math.min(t, c + r.text.length);
			n && o.push({
				...r,
				text: e.plain.slice(l, i)
			}), l = i, l === c + r.text.length && (c = l, s++);
		}
	};
	for (let e of i) {
		u(e.start, !0);
		let t = a[s];
		n && o.push({
			text: n,
			bold: t?.bold ?? !1,
			color: r ?? t?.color ?? null
		}), u(e.end, !1);
	}
	return u(e.plain.length, !0), {
		doc: C(o),
		count: i.length,
		selection: {
			start: i[0]?.start ?? 0,
			end: (i[0]?.start ?? 0) + (i.length ? n.length : 0)
		}
	};
}
//#endregion
//#region src/components/rich-plain-editor/FindReplacePanel.tsx
function Qt(e) {
	let { onPreview: t } = e, [n, i] = l(e.initialQuery), [a, o] = l(""), [s, u] = l("c2"), [p, m] = l(e.initialQuery ? {
		query: e.initialQuery,
		plain: e.plain
	} : null), [h, g] = l(0), _ = c(null), v = c(null), y = p?.query === n && p?.plain === e.plain, b = y ? Xt(e.plain, n) : [], ee = b.map((e) => `${e.start}:${e.end}`).join(",");
	r(() => {
		(e.initialQuery ? v : _).current?.focus();
	}, [e.initialQuery]), r(() => {
		t(y ? Xt(e.plain, n) : [], h);
	}, [
		ee,
		h,
		y,
		e.plain,
		n,
		t
	]);
	let te = () => {
		m({
			query: n,
			plain: e.plain
		}), g(0);
	}, ne = {
		minWidth: 0,
		width: "100%",
		background: "var(--surface)",
		color: "var(--text)",
		border: "1px solid var(--border)",
		borderRadius: 4,
		padding: "6px 8px"
	};
	return /* @__PURE__ */ f("div", {
		style: {
			borderTop: "1px solid var(--border)",
			marginTop: 6,
			paddingTop: 10,
			display: "grid",
			gap: 10
		},
		onMouseDown: (e) => {
			e.target instanceof HTMLElement && e.target.closest("button") && e.preventDefault();
		},
		onKeyDown: (t) => {
			t.stopPropagation(), !(t.nativeEvent.isComposing || t.keyCode === 229) && (t.key === "Escape" && (t.preventDefault(), e.onCancel()), t.key === "Enter" && t.target === _.current && (t.preventDefault(), te()));
		},
		children: [
			/* @__PURE__ */ f("div", {
				style: {
					display: "flex",
					alignItems: "center",
					gap: 8
				},
				children: [
					/* @__PURE__ */ f("label", {
						style: {
							display: "flex",
							alignItems: "center",
							gap: 8,
							flex: 1
						},
						children: [/* @__PURE__ */ d("span", {
							style: {
								whiteSpace: "nowrap",
								minWidth: "3em"
							},
							children: "查找"
						}), /* @__PURE__ */ d("input", {
							ref: _,
							"aria-label": "查找内容",
							value: n,
							placeholder: "输入查找内容",
							style: ne,
							onChange: (e) => {
								i(e.target.value), m(null);
							}
						})]
					}),
					/* @__PURE__ */ d(V, {
						variant: "ghost",
						title: "清空查找",
						"aria-label": "清空查找",
						onClick: () => {
							i(""), m(null), _.current?.focus();
						},
						children: "×"
					}),
					/* @__PURE__ */ d(V, {
						variant: "ghost",
						disabled: !n,
						onClick: te,
						children: "查找"
					})
				]
			}),
			/* @__PURE__ */ f("label", {
				style: {
					display: "flex",
					alignItems: "center",
					gap: 8
				},
				children: [/* @__PURE__ */ d("span", {
					style: {
						whiteSpace: "nowrap",
						minWidth: "3em"
					},
					children: "替换为"
				}), /* @__PURE__ */ d("input", {
					ref: v,
					"aria-label": "替换为",
					placeholder: "输入替换内容（留空则删除）",
					value: a,
					style: ne,
					onChange: (e) => o(e.target.value)
				})]
			}),
			/* @__PURE__ */ f("div", {
				style: {
					display: "flex",
					alignItems: "center",
					gap: 8
				},
				children: [
					/* @__PURE__ */ d("span", {
						role: "status",
						"aria-live": "polite",
						style: { flex: 1 },
						children: y ? `找到 ${b.length} 处${b.length ? ` · 当前 ${h + 1}/${b.length}` : ""}` : p ? "正文已变化，请重新查找" : "输入关键词后点击查找"
					}),
					/* @__PURE__ */ d(V, {
						variant: "ghost",
						"aria-label": "上一个匹配",
						disabled: !b.length,
						onClick: () => g((h + b.length - 1) % b.length),
						children: "‹"
					}),
					/* @__PURE__ */ d(V, {
						variant: "ghost",
						"aria-label": "下一个匹配",
						disabled: !b.length,
						onClick: () => g((h + 1) % b.length),
						children: "›"
					})
				]
			}),
			/* @__PURE__ */ f("div", {
				style: {
					display: "flex",
					alignItems: "center",
					gap: 6,
					flexWrap: "wrap"
				},
				children: [
					/* @__PURE__ */ d("span", { children: "替换后文字颜色" }),
					we.map((e) => /* @__PURE__ */ d("button", {
						type: "button",
						"aria-label": `替换颜色 ${e}`,
						"aria-pressed": s === e,
						onClick: () => u(e),
						style: {
							width: 22,
							height: 22,
							borderRadius: "50%",
							background: `var(--rich-mark-${e})`,
							border: s === e ? "2px solid var(--text)" : "2px solid transparent"
						}
					}, e)),
					/* @__PURE__ */ d(U, {
						label: "保留原色",
						checked: s === null,
						onChange: (e) => u(e ? null : "c2")
					})
				]
			}),
			/* @__PURE__ */ f("div", {
				style: {
					display: "flex",
					alignItems: "center",
					gap: 8,
					flexWrap: "wrap"
				},
				children: [
					/* @__PURE__ */ d("small", {
						style: { flex: 1 },
						children: "范围：当前文本框全文"
					}),
					/* @__PURE__ */ d(V, {
						variant: "ghost",
						onClick: e.onCancel,
						children: "取消"
					}),
					/* @__PURE__ */ d(V, {
						disabled: !y || !b.length,
						onClick: () => e.onReplace(n, a, s, p?.plain ?? e.plain),
						children: a ? `确定替换全部（${b.length}处）` : `确定删除匹配文本（${b.length}处）`
					})
				]
			})
		]
	});
}
//#endregion
//#region src/components/rich-plain-editor/FindReplacePreview.tsx
function $t({ root: e, matches: t, active: n }) {
	let [r, i] = l([]);
	return o(() => {
		if (!e) return;
		let r = () => {
			let r = e.getBoundingClientRect();
			i(t.flatMap((t, i) => Array.from(O(e, t.start, t.end)?.getClientRects() ?? []).flatMap((e) => {
				let t = Math.max(e.left, r.left, 0), a = Math.max(e.top, r.top, 0), o = Math.min(e.right, r.right, window.innerWidth), s = Math.min(e.bottom, r.bottom, window.innerHeight);
				return o > t && s > a ? [{
					x: t,
					y: a,
					w: o - t,
					h: s - a,
					active: i === n
				}] : [];
			})));
		}, a = t[n];
		if (a) {
			let t = O(e, a.start, a.end)?.getBoundingClientRect(), n = e.getBoundingClientRect();
			t && (t.top < n.top || t.bottom > n.bottom) && e.scrollBy({ top: t.top - n.top - n.height / 2 });
		}
		r();
		let o = new MutationObserver(r);
		return o.observe(e, {
			subtree: !0,
			childList: !0,
			characterData: !0
		}), window.addEventListener("scroll", r, !0), window.addEventListener("resize", r), () => {
			o.disconnect(), window.removeEventListener("scroll", r, !0), window.removeEventListener("resize", r);
		};
	}, [
		e,
		t,
		n
	]), p(/* @__PURE__ */ d("div", {
		"aria-hidden": "true",
		style: {
			pointerEvents: "none",
			position: "fixed",
			inset: 0,
			zIndex: L.RICH_PLAIN_FORMAT_BUBBLE - 1
		},
		children: r.map((e, t) => /* @__PURE__ */ d("div", { style: {
			position: "absolute",
			left: e.x,
			top: e.y,
			width: e.w,
			height: e.h,
			background: "var(--rich-mark-c2)",
			opacity: e.active ? .38 : .18,
			outline: e.active ? "1px solid var(--rich-mark-c2)" : void 0
		} }, t))
	}), document.body);
}
function en(e) {
	return {
		viewBox: "0 0 24 24",
		width: e,
		height: e,
		fill: "none",
		stroke: "currentColor",
		strokeWidth: 2,
		strokeLinecap: "round",
		strokeLinejoin: "round",
		"aria-hidden": !0
	};
}
function tn({ size: e = 14 }) {
	return /* @__PURE__ */ f("svg", {
		...en(e),
		children: [/* @__PURE__ */ d("rect", {
			x: "9",
			y: "9",
			width: "13",
			height: "13",
			rx: "2"
		}), /* @__PURE__ */ d("path", { d: "M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1" })]
	});
}
function nn({ size: e = 14 }) {
	return /* @__PURE__ */ f("svg", {
		...en(e),
		children: [
			/* @__PURE__ */ d("circle", {
				cx: "6",
				cy: "6",
				r: "3"
			}),
			/* @__PURE__ */ d("circle", {
				cx: "6",
				cy: "18",
				r: "3"
			}),
			/* @__PURE__ */ d("path", { d: "M20 4L8.12 15.88M14.47 14.48L20 20M8.12 8.12L12 12" })
		]
	});
}
//#endregion
//#region src/components/rich-plain-editor/FormatMarksBar.tsx
function rn(e) {
	let { disabled: t, layout: n = "bubble", onBold: r, onColor: i, onClear: a, onCut: o, onCopy: s, onFindReplace: c } = e, l = n === "toolbar";
	return /* @__PURE__ */ f("div", {
		style: {
			display: "flex",
			gap: l ? 4 : 8,
			justifyContent: l ? "flex-start" : "center",
			flexWrap: "nowrap",
			alignItems: "center",
			flexShrink: 0
		},
		onMouseDown: (e) => e.preventDefault(),
		children: [
			o ? /* @__PURE__ */ d(V, {
				variant: "ghost",
				disabled: t,
				onClick: o,
				title: "剪切",
				"aria-label": "剪切",
				children: /* @__PURE__ */ d(nn, {})
			}) : null,
			s ? /* @__PURE__ */ d(V, {
				variant: "ghost",
				disabled: t,
				onClick: s,
				title: "复制",
				"aria-label": "复制",
				children: /* @__PURE__ */ d(tn, {})
			}) : null,
			/* @__PURE__ */ d(V, {
				variant: "ghost",
				disabled: t,
				onClick: r,
				title: "加粗",
				"aria-label": "加粗",
				children: /* @__PURE__ */ d("span", {
					style: {
						fontWeight: 700,
						fontSize: R.textSm
					},
					children: "B"
				})
			}),
			we.map((e) => /* @__PURE__ */ d(V, {
				variant: "ghost",
				disabled: t,
				onClick: () => i(e),
				title: `颜色 ${e}`,
				"aria-label": `颜色 ${e}`,
				style: { padding: l ? "2px 4px" : "4px 6px" },
				children: /* @__PURE__ */ d("span", { style: {
					display: "inline-block",
					width: 12,
					height: 12,
					borderRadius: "50%",
					background: `var(--rich-mark-${e})`,
					boxShadow: "0 0 0 1px var(--border)"
				} })
			}, e)),
			c ? /* @__PURE__ */ d(V, {
				variant: "ghost",
				disabled: t,
				onClick: c,
				title: "查找替换",
				"aria-label": "查找替换",
				children: "查找替换"
			}) : null,
			/* @__PURE__ */ d(V, {
				variant: "ghost",
				disabled: t,
				onClick: a,
				title: "清除样式",
				"aria-label": "清除样式",
				children: /* @__PURE__ */ d("span", {
					style: { fontSize: R.textSm },
					children: "清除"
				})
			})
		]
	});
}
//#endregion
//#region src/components/rich-plain-editor/restoreOffsets.ts
function an(e, t) {
	return t === "keepRange" ? {
		start: e.start,
		end: e.end
	} : {
		start: e.end,
		end: e.end
	};
}
//#endregion
//#region src/components/rich-plain-editor/hostPorts.ts
var W = {
	shortcuts: { textareaWorkbench: {
		fontSizeIncrease: "增大字号",
		fontSizeDecrease: "缩小字号"
	} },
	common: {
		clipboardCopied: "已复制",
		clipboardCut: "已剪切",
		clipboardPasted: "已粘贴",
		clipboardCopyFailed: "复制失败",
		clipboardCutFailed: "剪切失败",
		clipboardPasteFailed: "粘贴失败",
		clipboardSelectFirst: "请先选择文本"
	}
};
function on() {
	return W;
}
function sn() {
	return {
		registerHandler: () => void 0,
		unregisterHandler: () => void 0
	};
}
function G(e) {
	return {
		copied: e.common.clipboardCopied,
		cutDone: e.common.clipboardCut,
		pasted: e.common.clipboardPasted,
		copyFailed: e.common.clipboardCopyFailed,
		cutFailed: e.common.clipboardCutFailed,
		pasteFailed: e.common.clipboardPasteFailed,
		selectFirst: e.common.clipboardSelectFirst
	};
}
async function K(e) {
	if (typeof navigator < "u" && navigator.clipboard?.writeText) {
		await navigator.clipboard.writeText(e);
		return;
	}
	throw Error("clipboard unavailable");
}
function q(e) {
	let t = e;
	if (typeof t.value == "string" && typeof t.selectionStart == "number" && typeof t.selectionEnd == "number") {
		let e = t.selectionStart, n = t.selectionEnd;
		if (e !== n) {
			typeof t.setRangeText == "function" ? t.setRangeText("", e, n, "end") : (t.value = t.value.slice(0, e) + t.value.slice(n), typeof t.setSelectionRange == "function" && t.setSelectionRange(e, e)), t.dispatchEvent(new Event("input", { bubbles: !0 }));
			return;
		}
	}
	let n = typeof window < "u" ? window.getSelection() : null;
	n && n.rangeCount > 0 && !n.isCollapsed && n.getRangeAt(0).deleteContents();
}
function J(e, t) {
	if (t.rangeOverride) {
		let n = Math.min(t.rangeOverride.start, t.rangeOverride.end), r = Math.max(t.rangeOverride.start, t.rangeOverride.end);
		return t.requireNonCollapsed && n === r ? "" : (e.innerText ?? e.textContent ?? "").slice(n, r);
	}
	return (typeof window < "u" ? window.getSelection()?.toString() ?? "" : "") || (e.innerText ?? e.textContent ?? "");
}
var Y = {
	loadRichDocForPlain: async (e, t) => De(t),
	writeRichSource: async () => void 0,
	reportRichStyleSaveFailed: () => void 0,
	notifyToast: () => void 0,
	copyFormControl: async (e, t, n) => {
		let r = J(e, n);
		if (!r) return t(n.speech.selectFirst, { variant: "info" }), !1;
		try {
			return await K(r), t(n.speech.copied, { variant: "success" }), !0;
		} catch {
			return t(n.speech.copyFailed, { variant: "error" }), !1;
		}
	},
	cutFormControl: async (e, t, n) => {
		let r = J(e, n);
		if (!r) return t(n.speech.selectFirst, { variant: "info" }), !1;
		try {
			return await K(r), q(e), t(n.speech.cutDone, { variant: "success" }), !0;
		} catch {
			return t(n.speech.cutFailed, { variant: "error" }), !1;
		}
	},
	formClipboardSpeechFromLocale: G,
	useI18n: on,
	useShortcutHandlers: sn,
	log: () => void 0,
	logError: () => void 0
}, X = null;
function cn(e) {
	return e ?? X ?? Y;
}
//#endregion
//#region src/domain/rich-plain-text/editorTypographyPrefs.ts
var ln = "bgx.versionHistoryWorkbench.typography.v1", un = "bgx.richPlainEditor.typography.v1", dn = 1.4, fn = 2.4, pn = 1.8, mn = 1.5;
function hn(e, t, n) {
	return Math.min(n, Math.max(t, e));
}
function gn(e) {
	return {
		fontSizePx: hn(typeof e.fontSizePx == "number" ? e.fontSizePx : 14, 12, 88),
		lineHeight: hn(typeof e.lineHeight == "number" ? e.lineHeight : pn, dn, fn)
	};
}
function _n(e) {
	return e === "chrome" ? un : ln;
}
function vn(e) {
	return {
		fontSizePx: 14,
		lineHeight: e === "chrome" ? mn : pn
	};
}
function yn(e) {
	try {
		let t = localStorage.getItem(_n(e));
		return t ? gn(JSON.parse(t)) : null;
	} catch {
		return null;
	}
}
function bn(e, t) {
	try {
		localStorage.setItem(_n(e), JSON.stringify(gn(t)));
	} catch {}
}
var Z = {
	chrome: {
		hydrated: !1,
		value: null,
		listeners: /* @__PURE__ */ new Set()
	},
	workbench: {
		hydrated: !1,
		value: null,
		listeners: /* @__PURE__ */ new Set()
	}
};
function xn(e) {
	let t = Z[e];
	if (t.hydrated) return;
	t.hydrated = !0;
	let n = yn(e);
	t.value = e === "workbench" ? n ?? vn("workbench") : n;
}
function Sn(e) {
	let t = Z[e];
	for (let e of t.listeners) e(t.value);
}
function Cn(e, t) {
	let n = Z[e];
	n.hydrated = !0, n.value = gn(t), bn(e, n.value), Sn(e);
}
function wn(e = "workbench") {
	return xn(e), Z[e].value;
}
function Tn(e, t) {
	return xn(e), Z[e].listeners.add(t), () => {
		Z[e].listeners.delete(t);
	};
}
function En(e, t = "workbench") {
	xn(t);
	let n = Z[t].value ?? vn(t);
	Cn(t, {
		...n,
		fontSizePx: n.fontSizePx + e
	});
}
function Dn(e, t = "workbench") {
	xn(t);
	let n = Z[t].value ?? vn(t), r = Math.round((n.lineHeight + e) * 10) / 10;
	Cn(t, {
		...n,
		lineHeight: r
	});
}
typeof window < "u" && window.addEventListener("storage", (e) => {
	e.key === "bgx.richPlainEditor.typography.v1" && (Z.chrome.hydrated = !0, Z.chrome.value = yn("chrome"), Sn("chrome")), e.key === "bgx.versionHistoryWorkbench.typography.v1" && (Z.workbench.hydrated = !0, Z.workbench.value = yn("workbench") ?? vn("workbench"), Sn("workbench"));
});
function On(e = "workbench") {
	let [t, n] = l(() => wn(e));
	return r(() => Tn(e, n), [e]), t;
}
//#endregion
//#region src/components/rich-plain-editor/RichPlainEditorCore.tsx
var kn = 8, An = 8;
function Q(e) {
	let t = e.getBoundingClientRect();
	return t.width !== 0 || t.height !== 0 || t.left !== 0 || t.top !== 0 ? t : e.getClientRects()[0] ?? null;
}
function jn(e) {
	let t = e.getBoundingClientRect(), n = window.getComputedStyle(e), r = t.left + (Number.parseFloat(n.paddingLeft) || 0), i = t.top + (Number.parseFloat(n.paddingTop) || 0), a = Number.parseFloat(n.lineHeight), o = Number.isFinite(a) && a > 0 ? a : 20;
	return {
		left: r,
		top: i,
		right: r,
		bottom: i + o,
		width: 0,
		height: o
	};
}
function Mn(e, t) {
	if (!e) return null;
	let n = window.getSelection();
	if (n && n.rangeCount > 0) {
		let t = n.getRangeAt(0);
		if (e.contains(t.commonAncestorContainer) || t.commonAncestorContainer === e) {
			let e = Q(t);
			if (e) return At(e);
		}
	}
	let r = O(e, t.start, t.end), i = r ? Q(r) : null;
	return i ? At(i) : jn(e);
}
function Nn(e, t, n, r) {
	if (!e) return !0;
	if (!r) return !1;
	let i = r.getBoundingClientRect(), a = i.bottom - t.bottom - An, o = t.top - i.top - An;
	return a < n + kn && o > a;
}
var $ = "RICH_PLAIN", Pn = 400, Fn = e(function(e, t) {
	let { value: m, onValueChange: h, onSourceChange: g, richOwner: _, hydrateSource: v, placeholder: y, disabled: b = !1, className: ee = "", style: te, spellCheck: ne = !1, showBubble: re = !0, id: ie, onFocus: ae, onBlur: oe, onKeyDown: se, onClick: x, onCompositionStart: fe, onCompositionEnd: pe, syntaxProfileId: S, pauseSyntaxRefresh: C = !1, citeImagePreviewByOrdinal: me, mediaReferenceInventory: he, typographySurface: w = "chrome", host: _e } = e, ve = s(() => he && ge(he), [he]), T = ve?.previews, E = ve?.labels, D = cn(_e), { writeRichSource: ye, loadRichDocForPlain: be, reportRichStyleSaveFailed: we, copyFormControl: Ee, cutFormControl: Oe } = D, Ae = D.log, O = D.logError, k = D.notifyToast, Pe = e["aria-label"], Re = e["aria-describedby"], Be = e["aria-invalid"], A = c(null), j = c(De(m)), Ve = c(null), He = c(null), Ue = c(""), We = c(null), M = c(null), N = c(_);
	N.current = _;
	let Ge = c(g);
	Ge.current = g;
	let P = c(!1), Ke = c(!1), qe = c(0), Je = c(""), F = c(null), Xe = s(Ye, [st(_)]), rt = c(() => {}), it = c(S);
	it.current = S;
	let ot = c(C);
	ot.current = C;
	let { registerHandler: ut, unregisterHandler: pt } = D.useShortcutHandlers(), mt = D.useI18n(), ht = s(() => D.formClipboardSpeechFromLocale(mt), [mt, D]), gt = On(w), [vt, xt] = l(!1), [I, Ct] = l(() => Ze()), wt = c(I);
	wt.current = I;
	let jt = i(), [R, Nt] = l(null), [Pt, Ft] = l(null), { hover: z, target: It, show: Lt, close: B } = $e(me, T, S, st(_), C), V = c(!0), Rt = c(null), zt = c(!1), [Bt, Vt] = l(null), Ht = (() => {
		let e = Bt && z && Bt.url === z.url ? Bt : null, t = e && e.height > 0 ? e.width / e.height : 1;
		return {
			boxWidth: t >= 1 ? 240 : Math.max(80, Math.round(240 * t)),
			boxHeight: t >= 1 ? Math.max(80, Math.round(240 / t)) : 240
		};
	})(), Ut = c(me);
	Ut.current = me;
	let Wt = c(E);
	Wt.current = E;
	let Gt = c(T);
	Gt.current = T;
	let Kt = c(null), qt = c(!1), Jt = c(null), H = c(null), Yt = c(!1), [U, Xt] = l(null), [en, tn] = l({
		matches: [],
		active: 0
	}), nn = n((e, t) => tn({
		matches: e,
		active: t
	}), []), W = n(() => {
		Xt(null), tn({
			matches: [],
			active: 0
		}), H.current = null, Nt(null), Ft(null);
	}, []), on = c(St({
		doc: De(m),
		selection: {
			start: 0,
			end: 0
		}
	})), sn = c(!1), G = st(_), K = n((e) => {
		We.current !== null && (qe.current += 1, We.current = null, Ue.current = st(N.current)), j.current = e;
		let t = yt(e);
		Ve.current = e.plain, He.current = t, h(e.plain), g?.(t, "edit"), at(N.current);
	}, [g, h]), q = n((e, t, n) => {
		on.current = Tt(on.current, {
			doc: e,
			selection: n
		}, t, Date.now());
	}, []), J = n((e, t, n) => {
		let r = A.current;
		if (!r) return;
		let i = it.current, a = !!i && wt.current;
		a && !n && rt.current();
		let o = i ? ze(i) : void 0, s = Se(e.plain), c = Ce(Gt.current), l = Wt.current ? `labels:${Ce(Wt.current)}` : "", u = `${yt(e)}\0${i ?? ""}\0${a ? "1" : "0"}\0${o?.version ?? 0}\0${c}\0${l}\0${s.map((e) => `${e.start}:${e.end}:${e.referenceId}`).join(",")}` + (n ? ":decorated" : ":plain");
		if (Je.current === u) {
			Ae($, "writeHtml_skip_unchanged", { ownerKey: st(N.current) || null }), V.current = !0, t && Me(r, t.start, t.end);
			return;
		}
		Je.current = u;
		let d = a && n && et(e.plain, e.intervals.length > 0, s.length > 0);
		Rt.current?.clear(), Rt.current = null;
		let f = xe(e, {
			chunkLongPlainRuns: !!i,
			decoSpans: a && !d ? n : void 0,
			mediaRefSpans: s,
			mediaRefPreviewById: Gt.current,
			mediaRefLabelById: Wt.current
		}), { scrollLeft: p, scrollTop: m } = r;
		n ? nt(r, f) : r.innerHTML = f, d && (Rt.current = tt(r, n)), V.current = !0, It.current && !r.contains(It.current.element) && B(), t && Me(r, t.start, t.end), r.scrollLeft = p, r.scrollTop = m;
	}, [B, It]), Y = n(() => {
		let e = A.current;
		if (!e) return j.current;
		let t = ke(e);
		return j.current = t, t;
	}, []), X = n(() => {
		let e = A.current, t = window.getSelection();
		if (!e || !t || t.rangeCount === 0) {
			let e = j.current.plain.length;
			return {
				start: e,
				end: e
			};
		}
		let n = t.getRangeAt(0);
		if (!e.contains(n.commonAncestorContainer) && n.commonAncestorContainer !== e) {
			let e = j.current.plain.length;
			return {
				start: e,
				end: e
			};
		}
		return je(e, n) ?? {
			start: 0,
			end: 0
		};
	}, []), ln = n(() => {
		F.current !== null && window.clearTimeout(F.current), F.current = null;
		let e = it.current;
		if (!e || !wt.current) return;
		let t = ze(e);
		if (!t) {
			cn().logError(Le, Fe, { profileId: e });
			return;
		}
		let n, r, i = () => {
			if (F.current = null, !(!A.current || P.current || ot.current || e !== it.current || !wt.current) && !(r && r !== j.current)) {
				r = j.current, n ??= Xe(r.plain, t);
				try {
					let e = performance.now() + 4, t = n.next();
					for (; !t.done && performance.now() < e;) t = n.next();
					if (t.done) {
						let e = Ke.current ? X() : void 0;
						zt.current = !!(e && e.start !== e.end), zt.current || J(r, e, t.value);
					} else F.current = window.setTimeout(i, 0);
				} catch (t) {
					cn().logError(Le, Ie, {
						profileId: e,
						error: t instanceof Error ? t.message : String(t)
					});
				}
			}
		};
		F.current = window.setTimeout(i, Pn);
	}, [
		X,
		Xe,
		J
	]);
	rt.current = ln, r(() => {
		let e = () => {
			!zt.current || !Ke.current || !window.getSelection()?.isCollapsed || (zt.current = !1, ln());
		};
		return document.addEventListener("selectionchange", e), () => document.removeEventListener("selectionchange", e);
	}, [ln]);
	let un = n((e, t) => {
		qe.current += 1, We.current = null;
		let n = _t(e), r;
		n.ok && n.doc.plain === t ? r = n.doc : (Ae("RICH_PLAIN", "hydrate_mismatch", {
			ownerKey: st(N.current) || null,
			incomingLen: e.length,
			valueLen: t.length,
			parseOk: n.ok,
			incomingPlainLen: n.ok ? n.doc.plain.length : 0,
			hadMarks: n.ok ? bt(n.doc) : !1,
			via: "hydrateFromSource"
		}), r = De(t)), j.current = r, Ve.current = r.plain, He.current = yt(r), Ue.current = st(N.current);
		let i = X(), a = i.start !== i.end || i.start > 0 && i.start < r.plain.length ? i : void 0;
		J(r, a), Ge.current?.(He.current, "hydrate"), at(N.current);
	}, [X, J]), dn = n((e, t) => {
		if (b) return;
		let n = H.current, r;
		if (R != null) {
			if (!n || n.start === n.end) {
				k(ht.selectFirst, { variant: "info" });
				return;
			}
			r = {
				start: Math.min(n.start, n.end),
				end: Math.max(n.start, n.end)
			};
		} else if (r = X(), r.start === r.end) return;
		let i = e(Y(), r.start, r.end), a = an(r, t);
		J(i, a), t === "collapseToEnd" ? W() : H.current = a, q(i, "atomic", a), K(i);
		let o = N.current;
		o?.ownerId && o.fieldKey && ye(o, i.plain, yt(i)).catch((e) => {
			O($, Te, {
				ownerKind: o.ownerKind,
				ownerId: o.ownerId,
				fieldKey: o.fieldKey,
				error: e instanceof Error ? e.message : String(e)
			}), we();
		});
	}, [
		R,
		W,
		X,
		b,
		K,
		Y,
		q,
		ht,
		J
	]), fn = n(() => dn(ce, "keepRange"), [dn]), pn = n(() => {
		let e = A.current;
		if (!e) return;
		let t = H.current;
		if (!t || t.start === t.end) {
			k(ht.selectFirst, { variant: "info" }), O($, "bubble_clip_cut", {
				textLen: 0,
				ok: !1
			});
			return;
		}
		let n = {
			start: Math.min(t.start, t.end),
			end: Math.max(t.start, t.end)
		}, r = n.end - n.start;
		Y(), Promise.resolve(Oe(e, k, {
			speech: ht,
			rangeOverride: n,
			requireNonCollapsed: !0
		})).then((e) => {
			if (e) {
				Ae($, "bubble_clip_cut", { textLen: r }), W();
				return;
			}
			O($, "bubble_clip_cut", {
				textLen: r,
				ok: !1
			});
		});
	}, [
		W,
		Y,
		ht
	]), mn = n(() => {
		let e = A.current;
		if (!e) return;
		let t = H.current;
		if (!t || t.start === t.end) {
			k(ht.selectFirst, { variant: "info" }), O($, "bubble_clip_copy", {
				textLen: 0,
				ok: !1
			});
			return;
		}
		let n = {
			start: Math.min(t.start, t.end),
			end: Math.max(t.start, t.end)
		}, r = n.end - n.start;
		Y(), Promise.resolve(Ee(e, k, {
			speech: ht,
			rangeOverride: n,
			requireNonCollapsed: !0
		})).then((e) => {
			if (e) {
				Ae($, "bubble_clip_copy", { textLen: r });
				return;
			}
			O($, "bubble_clip_copy", {
				textLen: r,
				ok: !1
			});
		});
	}, [Y, ht]), hn = n((e) => dn((t, n, r) => le(t, n, r, e), "collapseToEnd"), [dn]), gn = n(() => dn(ue, "collapseToEnd"), [dn]), _n = n(() => {
		if (b || P.current) return;
		let e = Y(), t = H.current ?? X();
		Xt({
			query: e.plain.slice(t.start, t.end),
			selection: t
		}), Nt(Mn(A.current, t));
	}, [
		b,
		Y,
		X
	]), vn = n(() => {
		let e = U?.selection;
		W(), A.current?.focus(), e && A.current && Me(A.current, e.start, e.end);
	}, [U, W]), yn = n((e, t, n, r) => {
		if (b || P.current) return;
		let i = Y();
		if (i.plain !== r) {
			k("正文已变化，请重新查找", { variant: "info" });
			return;
		}
		let a = Zt(i, e, t, n);
		if (!a.count) return;
		W(), A.current?.focus(), J(a.doc, a.selection), q(a.doc, "atomic", a.selection), K(a.doc);
		let o = N.current;
		o?.ownerId && o.fieldKey && ye(o, a.doc.plain, yt(a.doc)).catch((e) => {
			O($, Te, { error: String(e) }), we();
		}), k(`已替换 ${a.count} 处 · 可撤销`, { variant: "success" });
	}, [
		b,
		Y,
		W,
		J,
		q,
		K
	]), bn = n((e, t, n) => {
		if (b && !n?.programmatic) return;
		let r = t ?? X(), i = {
			start: Math.min(r.start, r.end),
			end: Math.max(r.start, r.end)
		}, a = de(Y(), i.start, i.end, e), o = i.start + e.length;
		J(a, {
			start: o,
			end: o
		}), q(a, "atomic", {
			start: o,
			end: o
		}), K(a);
	}, [
		X,
		b,
		K,
		Y,
		q,
		J
	]), Z = n((e) => {
		sn.current = !0;
		try {
			j.current = e.doc, J(e.doc, e.selection), K(e.doc);
		} finally {
			sn.current = !1;
		}
	}, [K, J]), xn = n(() => {
		if (b) return;
		let { state: e, applied: t } = Et(on.current);
		t && (on.current = e, Z(t));
	}, [Z, b]), Sn = n(() => {
		if (b) return;
		let { state: e, applied: t } = Dt(on.current);
		t && (on.current = e, Z(t));
	}, [Z, b]), Cn = n(() => {
		let e = A.current;
		if (!e) return;
		let t = j.current.plain.length;
		Me(e, 0, t);
	}, []), wn = n(() => {
		let e = {
			focus: () => A.current?.focus(),
			getSelection: X,
			setSelection: (e, t) => {
				let n = A.current;
				n && Me(n, e, t);
			},
			getPlain: () => j.current.plain,
			getSource: () => yt(j.current),
			getDisplayOptions: () => ({
				syntaxProfileId: S,
				citeImagePreviewByOrdinal: me,
				mediaReferenceInventory: he
			}),
			hydrateFromSource: un,
			getRootElement: () => A.current,
			applyBold: fn,
			applyColor: hn,
			clearMarks: gn,
			replaceSelection: bn,
			offsetFromPoint: (e, t) => {
				let n = A.current;
				return n ? Ne(n, e, t, j.current.plain.length) : null;
			},
			undo: xn,
			redo: Sn,
			selectAll: Cn
		};
		return M.current = e, e;
	}, [
		bn,
		X,
		fn,
		hn,
		gn,
		Sn,
		Cn,
		xn,
		un,
		S,
		me,
		he
	]);
	o(() => {
		wn();
	}, [wn]), a(t, wn, [wn]), r(() => {
		let e = A.current;
		if (e) return dt(e, {
			focus: () => M.current?.focus(),
			getSelection: () => M.current?.getSelection() ?? {
				start: 0,
				end: 0
			},
			getDisplayOptions: () => M.current?.getDisplayOptions?.() ?? {},
			setSelection: (e, t) => M.current?.setSelection(e, t),
			getPlain: () => j.current.plain,
			getSource: () => yt(j.current),
			hydrateFromSource: (e, t) => {
				let n = M.current;
				if (!n) {
					O($, "handle_api_missing", { op: "hydrateFromSource" });
					return;
				}
				n.hydrateFromSource(e, t);
			},
			getRootElement: () => A.current,
			applyBold: () => M.current?.applyBold(),
			applyColor: (e) => M.current?.applyColor(e),
			clearMarks: () => M.current?.clearMarks(),
			replaceSelection: (e, t, n) => {
				let r = M.current;
				if (!r) {
					O($, "handle_api_missing", { op: "replaceSelection" });
					return;
				}
				r.replaceSelection(e, t, n);
			},
			offsetFromPoint: (e, t) => M.current?.offsetFromPoint(e, t) ?? null,
			undo: () => {
				let e = M.current;
				if (!e) {
					O($, "handle_api_missing", { op: "undo" });
					return;
				}
				e.undo();
			},
			redo: () => {
				let e = M.current;
				if (!e) {
					O($, "handle_api_missing", { op: "redo" });
					return;
				}
				e.redo();
			},
			selectAll: () => {
				let e = M.current;
				if (!e) {
					O($, "handle_api_missing", { op: "selectAll" });
					return;
				}
				e.selectAll();
			}
		}), () => ft(e);
	}, []), r(() => {
		if (!G) {
			lt(jt);
			return;
		}
		let e = N.current;
		if (!e) {
			lt(jt);
			return;
		}
		return ct(jt, {
			owner: e,
			getPlain: () => j.current.plain,
			getSource: () => yt(j.current),
			hydrateFromSource: (e, t) => {
				M.current?.hydrateFromSource(e, t);
			}
		}), () => lt(jt);
	}, [jt, G]), o(() => {
		if (P.current) return;
		let e = v === void 0 ? void 0 : v ?? "", t = m === Ve.current, n = e === void 0 || e === He.current, r = G === Ue.current;
		if (t && n && r && Ve.current !== null) return;
		let i = `${G}\0${m}\0${e ?? ""}`;
		if (We.current === i) {
			Ae($, "hydrate_skip_inflight", {
				ownerKey: G || null,
				plainLen: m.length
			});
			return;
		}
		let a = ++qe.current;
		We.current = i, Ae($, "hydrate_begin", {
			ownerKey: G || null,
			plainLen: m.length,
			via: e === void 0 ? G ? "ipc" : "empty" : "hydrateSource"
		});
		let o = (e) => {
			if (qe.current !== a || P.current) return;
			We.current === i && (We.current = null), j.current = e, Ve.current = e.plain, He.current = yt(e), Ue.current = G;
			let t = X(), n = t.start !== t.end || t.start > 0 && t.start < e.plain.length ? t : void 0;
			Ae($, "hydrate_apply", {
				ownerKey: G || null,
				plainLen: e.plain.length,
				restore: !!n
			}), J(e, n), on.current = St({
				doc: e,
				selection: n ?? {
					start: 0,
					end: 0
				}
			});
		};
		if (e !== void 0) {
			let t = _t(e);
			t.ok && t.doc.plain === m ? o(t.doc) : (Ae("RICH_PLAIN", "hydrate_mismatch", {
				ownerKey: G || null,
				incomingLen: e.length,
				valueLen: m.length,
				parseOk: t.ok,
				incomingPlainLen: t.ok ? t.doc.plain.length : 0,
				hadMarks: t.ok ? bt(t.doc) : !1
			}), o(De(m)));
			return;
		}
		let s = N.current;
		s && s.ownerId && G ? be(s, m).then(o) : o(De(m));
	}, [
		m,
		G,
		v,
		J,
		X
	]), r(() => {
		if (S) return Ct(Ze()), Qe(() => {
			Ct(Ze());
		});
	}, [S]), o(() => {
		V.current = !1, !P.current && !C && (!I || !S ? J(j.current, Ke.current ? X() : void 0) : ln());
	}, [
		S,
		I,
		C,
		J,
		X,
		ln
	]);
	let Tn = n(() => {
		qt.current = P.current;
		let e = A.current;
		if (!e || qt.current) return;
		let { scrollLeft: t, scrollTop: n } = e, r = document.activeElement === e ? X() : void 0, i = Je.current;
		J(j.current, r), e.scrollLeft = t, e.scrollTop = n, Kt.current && Je.current !== i && (Kt.current = null, B());
	}, [
		J,
		X,
		B
	]);
	r(() => {
		Tn();
	}, [
		T,
		E,
		Tn
	]), r(() => () => {
		Rt.current?.clear(), F.current != null && window.clearTimeout(F.current);
	}, []);
	let Q = c(!1), jn = n(() => {
		if (!re || b || Q.current) {
			W();
			return;
		}
		if (U) return;
		let e = Yt.current || !!(Jt.current && document.activeElement && Jt.current.contains(document.activeElement)), t = A.current, n = window.getSelection();
		if (!t || !n || n.rangeCount === 0 || n.isCollapsed) {
			if (e) return;
			W();
			return;
		}
		let r = n.getRangeAt(0);
		if (!t.contains(r.commonAncestorContainer) && r.commonAncestorContainer !== t) {
			if (e) return;
			W();
			return;
		}
		let i = r.getBoundingClientRect();
		if (!n.isCollapsed && i.width === 0 && i.height === 0) {
			if (e) return;
			W();
			return;
		}
		let a = je(t, r);
		if (!a) {
			if (e) return;
			W();
			return;
		}
		H.current = {
			start: Math.min(a.start, a.end),
			end: Math.max(a.start, a.end)
		}, Ft(null), Nt(At(i.width || i.height ? i : t.getBoundingClientRect()));
	}, [
		W,
		b,
		re,
		U
	]), Fn = n(() => {
		if (!R) {
			Ft(null);
			return;
		}
		let e = Jt.current;
		if (!e) return;
		let t = e.offsetWidth, n = e.offsetHeight;
		if (t <= 0 || n <= 0) {
			Ft(null);
			return;
		}
		let r = Mt({
			trigger: R,
			bounds: kt(),
			minWidth: t,
			maxWidth: t,
			preferBelowIfPx: n + kn,
			preferOpenUp: Nn(U, R, n, A.current),
			horizontalAlign: "center",
			margin: An,
			gap: kn,
			minHeightFloor: n,
			maxHeightCap: n
		});
		Ft({
			top: r.top,
			left: r.left
		});
	}, [R, U]);
	o(() => {
		if (!R) {
			Ft(null);
			return;
		}
		Fn();
		let e = new ResizeObserver(Fn);
		return Jt.current && e.observe(Jt.current), () => e.disconnect();
	}, [R, Fn]), r(() => {
		let e = () => {
			requestAnimationFrame(() => {
				requestAnimationFrame(() => {
					Yt.current = !1;
				});
			});
		};
		return window.addEventListener("pointerup", e), window.addEventListener("pointercancel", e), () => {
			window.removeEventListener("pointerup", e), window.removeEventListener("pointercancel", e);
		};
	}, []), r(() => {
		if (!R) return;
		let e = () => {
			U ? Fn() : jn();
		};
		return window.addEventListener("resize", e), window.addEventListener("scroll", e, !0), () => {
			window.removeEventListener("resize", e), window.removeEventListener("scroll", e, !0);
		};
	}, [
		R,
		jn,
		U,
		Fn
	]), r(() => {
		if (!re || b) {
			W();
			return;
		}
		let e = () => {
			if (Q.current) {
				W();
				return;
			}
			jn();
		};
		return document.addEventListener("selectionchange", e), () => document.removeEventListener("selectionchange", e);
	}, [
		W,
		b,
		re,
		jn
	]);
	let In = n((e) => {
		e.button === 0 && (Q.current = !1);
	}, []), Ln = n((e) => {
		if (e.button !== 0) {
			Q.current = !0, W();
			return;
		}
		Q.current = !1, requestAnimationFrame(() => {
			Q.current || jn();
		});
	}, [W, jn]), Rn = n(() => {
		Q.current = !0, W();
	}, [W]), zn = n(() => {
		if (sn.current || P.current || b) return;
		V.current = !1, Je.current = "", B();
		let e = Y();
		q(e, "input", X()), K(e), Q.current || jn(), ln();
	}, [
		X,
		b,
		K,
		Y,
		q,
		jn,
		ln,
		B
	]), Bn = n((e) => {
		if (b) {
			e.preventDefault();
			return;
		}
		let t = e.nativeEvent;
		if (t.inputType === "insertParagraph" || t.inputType === "insertLineBreak") {
			e.preventDefault();
			let t = X(), n = de(Y(), t.start, t.end, "\n"), r = t.start + 1;
			J(n, {
				start: r,
				end: r
			}), q(n, "atomic", {
				start: r,
				end: r
			}), K(n);
		}
	}, [
		X,
		b,
		K,
		Y,
		q,
		J
	]), Vn = n((e) => {
		if (e.preventDefault(), b) return;
		let t = e.clipboardData.getData("text/plain"), n = X(), r = de(Y(), n.start, n.end, t), i = n.start + t.length;
		J(r, {
			start: i,
			end: i
		}), q(r, "atomic", {
			start: i,
			end: i
		}), K(r);
	}, [
		X,
		b,
		K,
		Y,
		q,
		J
	]), Hn = n((e, t) => {
		e.preventDefault();
		let n = X(), r = j.current.plain.slice(n.start, n.end);
		if (e.clipboardData.setData("text/plain", r), t && !b) {
			let e = de(Y(), n.start, n.end, "");
			J(e, {
				start: n.start,
				end: n.start
			}), q(e, "atomic", {
				start: n.start,
				end: n.start
			}), K(e);
		}
	}, [
		X,
		b,
		K,
		Y,
		q,
		J
	]), Un = n((e) => {
		if (e.nativeEvent.isComposing || e.keyCode === 229 || P.current) {
			se?.(e);
			return;
		}
		if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "h") {
			e.preventDefault(), e.stopPropagation(), _n();
			return;
		}
		let t = Ot(e);
		if (t) {
			e.preventDefault(), e.stopPropagation(), t === "undo" ? xn() : t === "redo" ? Sn() : Cn();
			return;
		}
		if ((e.ctrlKey || e.metaKey) && (e.key === "b" || e.key === "B")) {
			e.preventDefault(), e.stopPropagation(), fn();
			return;
		}
		se?.(e);
	}, [
		fn,
		Sn,
		Cn,
		xn,
		se,
		_n
	]);
	r(() => {
		if (!vt || b) return;
		let e = [
			ut("textareaWorkbench.fontSizeIncrease", () => En(1, w)),
			ut("textareaWorkbench.fontSizeDecrease", () => En(-1, w)),
			ut("textareaWorkbench.lineHeightIncrease", () => Dn(.1, w)),
			ut("textareaWorkbench.lineHeightDecrease", () => Dn(-.1, w))
		];
		return () => {
			pt("textareaWorkbench.fontSizeIncrease", e[0]), pt("textareaWorkbench.fontSizeDecrease", e[1]), pt("textareaWorkbench.lineHeightIncrease", e[2]), pt("textareaWorkbench.lineHeightDecrease", e[3]);
		};
	}, [
		vt,
		b,
		ut,
		pt,
		w
	]), r(() => {
		W();
	}, [G, W]), r(() => {
		if (!U) return;
		let e = (e) => {
			e.target instanceof Node && !Jt.current?.contains(e.target) && W();
		};
		return document.addEventListener("pointerdown", e), () => document.removeEventListener("pointerdown", e);
	}, [U, W]);
	let Wn = ["ui-edit-textarea", ee].filter(Boolean).join(" "), Gn = j.current.plain.length === 0 && m.length === 0, Kn = gt ? {
		fontSize: gt.fontSizePx,
		lineHeight: gt.lineHeight
	} : void 0;
	return /* @__PURE__ */ f(u, { children: [
		/* @__PURE__ */ d("div", {
			ref: A,
			id: ie,
			className: Wn,
			style: {
				whiteSpace: "pre-wrap",
				...te,
				...Kn
			},
			contentEditable: !b,
			suppressContentEditableWarning: !0,
			"data-canvas-ui": !0,
			"data-canvas-ui-scroll": "true",
			"data-rich-plain": "1",
			"data-placeholder": Gn ? y ?? "" : "",
			spellCheck: ne,
			onInput: zn,
			onBeforeInput: Bn,
			onPaste: Vn,
			onCopy: (e) => Hn(e, !1),
			onCut: (e) => Hn(e, !0),
			onCompositionStart: () => {
				P.current = !0, B(), F.current !== null && window.clearTimeout(F.current), F.current = null, fe?.();
			},
			onCompositionEnd: () => {
				P.current = !1, pe?.(), zn(), qt.current && Tn(), wt.current || J(j.current, X());
			},
			onKeyDown: Un,
			onKeyUp: () => {
				Q.current = !1, jn();
			},
			onMouseDown: In,
			onMouseUp: Ln,
			onMouseMove: (e) => {
				if (ot.current || P.current) {
					Kt.current &&= (A.current?.querySelectorAll("[data-media-ref-hover='1']").forEach((e) => {
						e.style.outline = "", e.style.outlineOffset = "", e.removeAttribute("data-media-ref-hover");
					}), null), B();
					return;
				}
				let t = e.target?.closest?.("[data-media-ref-id]");
				if (t instanceof HTMLElement && A.current?.contains(t)) {
					let e = (t.getAttribute("data-media-ref-id") ?? "").trim(), n = (Gt.current?.[e] ?? "").trim();
					if (e && Kt.current !== e && (A.current.querySelectorAll("[data-media-ref-hover='1']").forEach((e) => {
						e.style.outline = "", e.style.outlineOffset = "", e.removeAttribute("data-media-ref-hover");
					}), t.setAttribute("data-media-ref-hover", "1"), t.style.outline = "2px solid var(--accent)", t.style.outlineOffset = "1px", Kt.current = e), n) {
						Lt(t, n);
						return;
					}
				} else Kt.current &&= (A.current?.querySelectorAll("[data-media-ref-hover='1']").forEach((e) => {
					e.style.outline = "", e.style.outlineOffset = "", e.removeAttribute("data-media-ref-hover");
				}), null);
				let n = Ut.current;
				if (!n || !V.current) {
					B();
					return;
				}
				let r = e.target?.closest?.("[data-cite-kind='image']"), i = A.current;
				if (!(r instanceof HTMLElement) || !i?.contains(r)) {
					if (i && Rt.current) {
						let t = document.caretRangeFromPoint(e.clientX, e.clientY), r = t && i.contains(t.startContainer) ? je(i, t)?.start : void 0, a = r === void 0 ? void 0 : Rt.current.imageAt(r), o = a ? n[a.ord]?.trim() : void 0;
						if (a && o) {
							Lt(i, o, a.range, e.clientX, e.clientY);
							return;
						}
					}
					B();
					return;
				}
				let a = (n[Number(r.getAttribute("data-cite-ord"))] ?? "").trim();
				if (!a) {
					B();
					return;
				}
				Lt(r, a);
			},
			onMouseLeave: () => {
				Kt.current &&= (A.current?.querySelectorAll("[data-media-ref-hover='1']").forEach((e) => {
					e.style.outline = "", e.style.outlineOffset = "", e.removeAttribute("data-media-ref-hover");
				}), null), B();
			},
			onContextMenu: Rn,
			onFocus: () => {
				Ke.current = !0, b || xt(!0), ae?.();
			},
			onBlur: (e) => {
				Ke.current = !1, xt(!1);
				let t = e.relatedTarget;
				if (Yt.current || t instanceof Node && Jt.current?.contains(t)) {
					oe?.();
					return;
				}
				W(), oe?.();
			},
			onClick: x,
			role: "textbox",
			"aria-multiline": "true",
			"aria-label": Pe,
			"aria-describedby": Re,
			"aria-invalid": Be || void 0,
			"aria-disabled": b || void 0
		}),
		R && !b ? p(/* @__PURE__ */ f("div", {
			ref: Jt,
			"data-rich-plain-bubble": "1",
			style: {
				position: "fixed",
				top: Pt?.top ?? 0,
				left: Pt?.left ?? 0,
				visibility: Pt ? "visible" : "hidden",
				width: U ? 500 : "max-content",
				maxWidth: "calc(100vw - 16px)",
				maxHeight: "calc(100vh - 16px)",
				overflow: "auto",
				zIndex: L.RICH_PLAIN_FORMAT_BUBBLE,
				background: "var(--surface2)",
				border: "1px solid var(--border)",
				borderRadius: "var(--radius)",
				padding: "6px 8px",
				boxShadow: "var(--shadow-md)"
			},
			onMouseDown: (e) => {
				(!(e.target instanceof HTMLElement) || !e.target.closest("input, button, label")) && e.preventDefault();
			},
			onPointerDown: () => {
				Yt.current = !0;
			},
			children: [H.current && H.current.start !== H.current.end ? /* @__PURE__ */ d(rn, {
				onFindReplace: _n,
				onCut: pn,
				onCopy: mn,
				onBold: fn,
				onColor: hn,
				onClear: gn
			}) : null, U ? /* @__PURE__ */ d(Qt, {
				initialQuery: U.query,
				plain: m,
				onPreview: nn,
				onCancel: vn,
				onReplace: yn
			}) : null]
		}), document.body) : null,
		U ? /* @__PURE__ */ d($t, {
			root: A.current,
			matches: en.matches,
			active: en.active
		}) : null,
		z ? p(/* @__PURE__ */ d("div", {
			"data-rich-cite-preview": "1",
			style: {
				position: "fixed",
				left: Math.max(8, Math.min(window.innerWidth - Ht.boxWidth - 8, z.centerX - Ht.boxWidth / 2)),
				top: z.top > Ht.boxHeight + 16 ? z.top - Ht.boxHeight - 8 : Math.max(8, Math.min(window.innerHeight - Ht.boxHeight - 8, z.bottom + 8)),
				pointerEvents: "none",
				zIndex: L.RICH_PLAIN_FORMAT_BUBBLE,
				width: Ht.boxWidth,
				height: Ht.boxHeight,
				borderRadius: 8,
				overflow: "hidden",
				border: "1px solid var(--border)",
				boxShadow: "var(--shadow-md)",
				background: "var(--surface)"
			},
			children: /* @__PURE__ */ d("img", {
				src: z.url,
				onError: () => {
					It.current?.url === z.url && B();
				},
				alt: "",
				onLoad: (e) => {
					let t = e.currentTarget;
					It.current?.url === z.url && t.naturalWidth > 0 && t.naturalHeight > 0 && Vt({
						url: z.url,
						width: t.naturalWidth,
						height: t.naturalHeight
					});
				},
				style: {
					width: "100%",
					height: "100%",
					objectFit: "contain",
					display: "block"
				}
			}, z.url)
		}), document.body) : null
	] });
}), In = {
	version: 1,
	specialKeys: {
		Delete: "Delete",
		Home: "Home",
		End: "End",
		Space: "Space",
		PageUp: "PageUp",
		PageDown: "PageDown",
		ArrowUp: "Up",
		ArrowDown: "Down",
		ArrowLeft: "Left",
		ArrowRight: "Right",
		NumpadDecimal: "Kp Period",
		NumpadAdd: "Kp Add",
		NumpadSubtract: "Kp Subtract",
		NumpadMultiply: "Kp Multiply",
		NumpadDivide: "Kp Divide",
		BracketLeft: "[",
		BracketRight: "]",
		Minus: "-",
		Equal: "=",
		Comma: ",",
		Period: ".",
		Slash: "/",
		Backslash: "\\",
		Semicolon: ";",
		Quote: "'",
		Backquote: "`"
	},
	actions: [
		{
			id: "box_select",
			zh: "框选人物",
			en: "Box select",
			group: "编辑",
			defaultChord: { code: "KeyB" },
			aliases: [],
			settings: !1
		},
		{
			id: "move",
			zh: "移动工具 / 拖动位置",
			en: "Move tool / Joint translation",
			group: "编辑",
			defaultChord: { code: "KeyG" },
			aliases: [],
			settings: !0
		},
		{
			id: "rotate",
			zh: "旋转工具 / 旋转关节",
			en: "Rotate tool / Joint rotation",
			group: "编辑",
			defaultChord: { code: "KeyR" },
			aliases: [],
			settings: !0
		},
		{
			id: "pose",
			zh: "摆姿 / 整人编辑",
			en: "Pose / Object editing",
			group: "编辑",
			defaultChord: { code: "KeyP" },
			aliases: [],
			settings: !1
		},
		{
			id: "frame",
			zh: "聚焦所选人物 / 关节",
			en: "Frame selection",
			group: "视图",
			defaultChord: { code: "KeyF" },
			aliases: [{ code: "NumpadDecimal" }],
			settings: !1
		},
		{
			id: "all",
			zh: "框住全部 / 适配取景框",
			en: "Frame all",
			group: "视图",
			defaultChord: { code: "Home" },
			aliases: [],
			settings: !1
		},
		{
			id: "camera_view",
			zh: "场景 / 相机",
			en: "Scene / Camera",
			group: "视图",
			defaultChord: { code: "Digit0" },
			aliases: [{ code: "Numpad0" }],
			settings: !1
		},
		{
			id: "front",
			zh: "前视图",
			en: "Front",
			group: "视图",
			defaultChord: { code: "Numpad1" },
			aliases: [],
			settings: !1
		},
		{
			id: "back",
			zh: "后视图",
			en: "Back",
			group: "视图",
			defaultChord: {
				code: "Numpad1",
				ctrl: !0
			},
			aliases: [],
			settings: !1
		},
		{
			id: "right",
			zh: "右视图",
			en: "Right",
			group: "视图",
			defaultChord: { code: "Numpad3" },
			aliases: [],
			settings: !1
		},
		{
			id: "left",
			zh: "左视图",
			en: "Left",
			group: "视图",
			defaultChord: {
				code: "Numpad3",
				ctrl: !0
			},
			aliases: [],
			settings: !1
		},
		{
			id: "top",
			zh: "顶视图",
			en: "Top",
			group: "视图",
			defaultChord: { code: "Numpad7" },
			aliases: [],
			settings: !1
		},
		{
			id: "bottom",
			zh: "底视图",
			en: "Bottom",
			group: "视图",
			defaultChord: {
				code: "Numpad7",
				ctrl: !0
			},
			aliases: [],
			settings: !1
		},
		{
			id: "projection",
			zh: "透视 / 正交",
			en: "Perspective / Orthographic",
			group: "视图",
			defaultChord: { code: "Numpad5" },
			aliases: [],
			settings: !1
		},
		{
			id: "align_camera",
			zh: "用当前视角设机位",
			en: "Align camera to view",
			group: "镜头",
			defaultChord: {
				code: "Numpad0",
				ctrl: !0,
				alt: !0
			},
			aliases: [],
			settings: !1
		},
		{
			id: "focus_view",
			zh: "专注视口",
			en: "Focus viewport",
			group: "界面",
			defaultChord: {
				code: "Space",
				ctrl: !0
			},
			aliases: [],
			settings: !1
		},
		{
			id: "left_panel",
			zh: "场景栏",
			en: "Scene panel",
			group: "界面",
			defaultChord: { code: "KeyT" },
			aliases: [],
			settings: !1
		},
		{
			id: "right_panel",
			zh: "属性栏",
			en: "Inspector",
			group: "界面",
			defaultChord: { code: "KeyN" },
			aliases: [],
			settings: !1
		},
		{
			id: "save",
			zh: "保存到画布",
			en: "Save to canvas",
			group: "文件",
			defaultChord: {
				code: "KeyS",
				ctrl: !0
			},
			aliases: [],
			settings: !1
		},
		{
			id: "undo",
			zh: "撤销",
			en: "Undo",
			group: "编辑",
			defaultChord: {
				code: "KeyZ",
				ctrl: !0
			},
			aliases: [],
			settings: !1
		},
		{
			id: "redo",
			zh: "重做",
			en: "Redo",
			group: "编辑",
			defaultChord: {
				code: "KeyZ",
				ctrl: !0,
				shift: !0
			},
			aliases: [],
			settings: !1
		},
		{
			id: "rename",
			zh: "重命名人物",
			en: "Rename selection",
			group: "编辑",
			defaultChord: { code: "F2" },
			aliases: [],
			settings: !1
		},
		{
			id: "duplicate",
			zh: "复制人物",
			en: "Duplicate selection",
			group: "编辑",
			defaultChord: {
				code: "KeyD",
				shift: !0
			},
			aliases: [],
			settings: !1
		},
		{
			id: "delete",
			zh: "删除人物",
			en: "Delete selection",
			group: "编辑",
			defaultChord: { code: "Delete" },
			aliases: [],
			settings: !1
		},
		{
			id: "help",
			zh: "快捷键与帮助",
			en: "Shortcut help",
			group: "界面",
			defaultChord: { code: "F1" },
			aliases: [],
			settings: !1
		}
	]
}, Ln = {
	schemaVersion: 1,
	actions: [
		{
			id: "any2text.previousSegment",
			defaultChord: {
				code: "ArrowUp",
				shift: !0,
				alt: !0
			},
			zh: "上一段",
			en: "Previous subtitle"
		},
		{
			id: "any2text.nextSegment",
			defaultChord: {
				code: "ArrowDown",
				shift: !0,
				alt: !0
			},
			zh: "下一段",
			en: "Next subtitle"
		},
		{
			id: "any2text.insertLineBreak",
			defaultChord: {
				code: "Enter",
				shift: !0,
				alt: !0
			},
			zh: "插入换行",
			en: "Insert line break"
		},
		{
			id: "any2text.splitAtCursor",
			defaultChord: {
				code: "Enter",
				shift: !0,
				ctrl: !0
			},
			zh: "在光标处拆段",
			en: "Split at cursor"
		},
		{
			id: "any2text.mergePrevious",
			defaultChord: {
				code: "ArrowLeft",
				shift: !0,
				alt: !0
			},
			zh: "与上一段合并",
			en: "Merge with previous"
		},
		{
			id: "any2text.mergeNext",
			defaultChord: {
				code: "ArrowRight",
				shift: !0,
				alt: !0
			},
			zh: "与下一段合并",
			en: "Merge with next"
		},
		{
			id: "any2text.suggestBreaks",
			defaultChord: {
				code: "KeyA",
				shift: !0,
				alt: !0
			},
			zh: "自动整理",
			en: "Suggest subtitle breaks"
		},
		{
			id: "any2text.undoEdit",
			defaultChord: {
				code: "KeyZ",
				shift: !0,
				alt: !0
			},
			zh: "撤销",
			en: "Undo subtitle edit"
		},
		{
			id: "any2text.reviewCurrent",
			defaultChord: {
				code: "KeyR",
				shift: !0,
				alt: !0
			},
			zh: "复核当前段",
			en: "Review current subtitle"
		},
		{
			id: "any2text.reviewAll",
			defaultChord: {
				code: "KeyB",
				shift: !0,
				alt: !0
			},
			zh: "复核全部",
			en: "Review all subtitles"
		},
		{
			id: "any2text.confirmReview",
			defaultChord: {
				code: "KeyC",
				shift: !0,
				alt: !0
			},
			zh: "确认时间",
			en: "Confirm timing"
		}
	]
};
new Map(Ln.actions.map((e) => [e.id, {
	"zh-CN": e.zh,
	en: e.en
}]));
function Rn(e) {
	let { code: t, ctrl: n, alt: r, meta: i } = e;
	return i || /^(Escape|Tab|F4|F11)$/.test(t) || n && !r && /^(Key[ACVXYZ]|Backspace|Delete)$/.test(t) ? !1 : !!(n || r || /^F([1-9]|1[0-9]|2[0-4])$/.test(t));
}
var zn = [
	{
		id: "app.save",
		scope: "global",
		defaultChord: {
			code: "KeyS",
			ctrl: !0
		},
		allowInEditableTarget: !0,
		labelKey: "shortcuts.app.save",
		categoryKey: "shortcuts.categories.global"
	},
	{
		id: "app.toggleSidebar",
		scope: "global",
		defaultChord: {
			code: "KeyB",
			ctrl: !0
		},
		allowInEditableTarget: !0,
		labelKey: "shortcuts.app.toggleSidebar",
		categoryKey: "shortcuts.categories.global"
	},
	{
		id: "canvas.toggleFullscreen",
		scope: "global",
		defaultChord: { code: "F11" },
		allowInEditableTarget: !0,
		labelKey: "shortcuts.canvas.toggleFullscreen",
		categoryKey: "shortcuts.categories.canvas"
	},
	{
		id: "canvas.resetLayout",
		scope: "global",
		defaultChord: null,
		allowInEditableTarget: !1,
		labelKey: "shortcuts.canvas.resetLayout",
		categoryKey: "shortcuts.categories.canvas"
	},
	{
		id: "canvas.zoomTo100",
		scope: "global",
		defaultChord: {
			code: "KeyZ",
			shift: !0
		},
		allowInEditableTarget: !1,
		labelKey: "shortcuts.canvas.zoomTo100",
		categoryKey: "shortcuts.categories.canvas"
	},
	{
		id: "canvas.fitAllNodes",
		scope: { mainTabs: [
			"freeCanvas",
			"clips",
			"chapters",
			"scenes",
			"storyboard",
			"segments"
		] },
		defaultChord: {
			code: "KeyZ",
			alt: !0,
			shift: !0
		},
		allowInEditableTarget: !1,
		labelKey: "shortcuts.canvas.fitAllNodes",
		categoryKey: "shortcuts.categories.canvas"
	},
	{
		id: "canvas.zoomIn",
		scope: { mainTabs: ["clips", "freeCanvas"] },
		defaultChord: {
			code: "Equal",
			alt: !0
		},
		aliases: [{
			code: "Equal",
			alt: !0,
			shift: !0
		}, {
			code: "NumpadAdd",
			alt: !0
		}],
		allowInEditableTarget: !1,
		allowKeyRepeat: !0,
		labelKey: "shortcuts.canvas.zoomIn",
		categoryKey: "shortcuts.categories.canvas"
	},
	{
		id: "canvas.zoomOut",
		scope: { mainTabs: ["clips", "freeCanvas"] },
		defaultChord: {
			code: "Minus",
			alt: !0
		},
		aliases: [{
			code: "NumpadSubtract",
			alt: !0
		}],
		allowInEditableTarget: !1,
		allowKeyRepeat: !0,
		labelKey: "shortcuts.canvas.zoomOut",
		categoryKey: "shortcuts.categories.canvas"
	},
	{
		id: "canvas.toggleSceneListPeek",
		scope: { mainTabs: ["storyboard", "segments"] },
		defaultChord: {
			code: "KeyS",
			alt: !0
		},
		allowInEditableTarget: !1,
		labelKey: "shortcuts.canvas.toggleSceneListPeek",
		categoryKey: "shortcuts.categories.canvas"
	},
	{
		id: "canvas.undo",
		scope: "global",
		defaultChord: {
			code: "KeyZ",
			ctrl: !0
		},
		allowInEditableTarget: !1,
		labelKey: "shortcuts.canvas.undo",
		categoryKey: "shortcuts.categories.canvas"
	},
	{
		id: "canvas.redo",
		scope: "global",
		defaultChord: {
			code: "KeyY",
			ctrl: !0
		},
		allowInEditableTarget: !1,
		labelKey: "shortcuts.canvas.redo",
		categoryKey: "shortcuts.categories.canvas"
	},
	{
		id: "canvas.selectAll",
		scope: { mainTabs: [
			"storyboard",
			"segments",
			"clips",
			"freeCanvas",
			"scenes",
			"roles",
			"characters",
			"storyProps"
		] },
		defaultChord: {
			code: "KeyA",
			ctrl: !0
		},
		allowInEditableTarget: !1,
		labelKey: "shortcuts.canvas.selectAll",
		categoryKey: "shortcuts.categories.canvas"
	},
	{
		id: "canvas.alignNodes",
		scope: { mainTabs: [
			"chapters",
			"storyboard",
			"segments",
			"clips",
			"freeCanvas"
		] },
		defaultChord: {
			code: "KeyA",
			alt: !0
		},
		allowInEditableTarget: !1,
		labelKey: "shortcuts.canvas.alignNodes",
		categoryKey: "shortcuts.categories.canvas"
	},
	{
		id: "globalAssistant.toggle",
		scope: "global",
		defaultChord: { code: "F1" },
		allowInEditableTarget: !0,
		labelKey: "shortcuts.globalAssistant.toggle",
		categoryKey: "shortcuts.categories.global"
	},
	{
		id: "globalAssistant.startMic",
		scope: "global",
		defaultChord: {
			code: "KeyM",
			ctrl: !0,
			shift: !0
		},
		allowInEditableTarget: !0,
		allowWhenModalOpen: !1,
		labelKey: "shortcuts.globalAssistant.startMic",
		categoryKey: "shortcuts.categories.global"
	},
	{
		id: "globalAssistant.cancelMic",
		scope: "global",
		defaultChord: { code: "Escape" },
		allowInEditableTarget: !0,
		allowWhenModalOpen: !1,
		labelKey: "shortcuts.globalAssistant.cancelMic",
		categoryKey: "shortcuts.categories.global"
	},
	{
		id: "segmentCanvas.toggleRightPanel",
		scope: { mainTab: "segments" },
		defaultChord: {
			code: "KeyB",
			shift: !0
		},
		allowInEditableTarget: !1,
		labelKey: "shortcuts.segmentCanvas.toggleRightPanel",
		categoryKey: "shortcuts.categories.segments"
	},
	{
		id: "canvas.group",
		scope: { mainTabs: [
			"clips",
			"freeCanvas",
			"segments",
			"scenes",
			"storyboard"
		] },
		defaultChord: {
			code: "KeyG",
			ctrl: !0
		},
		allowInEditableTarget: !1,
		labelKey: "shortcuts.canvas.group",
		categoryKey: "shortcuts.categories.canvas"
	},
	{
		id: "canvas.ungroup",
		scope: { mainTabs: [
			"clips",
			"freeCanvas",
			"segments",
			"scenes",
			"storyboard"
		] },
		defaultChord: {
			code: "KeyG",
			ctrl: !0,
			alt: !0
		},
		allowInEditableTarget: !1,
		labelKey: "shortcuts.canvas.ungroup",
		categoryKey: "shortcuts.categories.canvas"
	},
	{
		id: "storyboard.toggleShotHistory",
		scope: { mainTab: "storyboard" },
		defaultChord: {
			code: "KeyB",
			shift: !0
		},
		allowInEditableTarget: !1,
		labelKey: "shortcuts.storyboard.toggleShotHistory",
		categoryKey: "shortcuts.categories.storyboard"
	},
	{
		id: "refineWorkbench.toolMouse",
		scope: "global",
		defaultChord: { code: "KeyA" },
		allowInEditableTarget: !1,
		labelKey: "shortcuts.refineWorkbench.toolMouse",
		categoryKey: "shortcuts.categories.canvas"
	},
	{
		id: "refineWorkbench.toolBrush",
		scope: "global",
		defaultChord: { code: "KeyB" },
		allowInEditableTarget: !1,
		labelKey: "shortcuts.refineWorkbench.toolBrush",
		categoryKey: "shortcuts.categories.canvas"
	},
	{
		id: "refineWorkbench.toolCrop",
		scope: "global",
		defaultChord: { code: "KeyC" },
		allowInEditableTarget: !1,
		labelKey: "shortcuts.refineWorkbench.toolCrop",
		categoryKey: "shortcuts.categories.canvas"
	},
	{
		id: "refineWorkbench.toolRotate",
		scope: "global",
		defaultChord: { code: "KeyR" },
		allowInEditableTarget: !1,
		labelKey: "shortcuts.refineWorkbench.toolRotate",
		categoryKey: "shortcuts.categories.canvas"
	},
	{
		id: "refineWorkbench.brushSizeIncrease",
		scope: "global",
		defaultChord: { code: "BracketRight" },
		allowInEditableTarget: !1,
		allowKeyRepeat: !0,
		labelKey: "shortcuts.refineWorkbench.brushSizeIncrease",
		categoryKey: "shortcuts.categories.canvas"
	},
	{
		id: "refineWorkbench.brushSizeDecrease",
		scope: "global",
		defaultChord: { code: "BracketLeft" },
		allowInEditableTarget: !1,
		allowKeyRepeat: !0,
		labelKey: "shortcuts.refineWorkbench.brushSizeDecrease",
		categoryKey: "shortcuts.categories.canvas"
	},
	{
		id: "refineWorkbench.brushOpacityIncrease",
		scope: "global",
		defaultChord: { code: "Equal" },
		allowInEditableTarget: !1,
		allowKeyRepeat: !0,
		labelKey: "shortcuts.refineWorkbench.brushOpacityIncrease",
		categoryKey: "shortcuts.categories.canvas"
	},
	{
		id: "refineWorkbench.brushOpacityDecrease",
		scope: "global",
		defaultChord: { code: "Minus" },
		allowInEditableTarget: !1,
		allowKeyRepeat: !0,
		labelKey: "shortcuts.refineWorkbench.brushOpacityDecrease",
		categoryKey: "shortcuts.categories.canvas"
	},
	{
		id: "sceneTab.prevScene",
		scope: { mainTabs: ["chapters", "scenes"] },
		defaultChord: {
			code: "ArrowLeft",
			alt: !0
		},
		allowInEditableTarget: !0,
		labelKey: "shortcuts.sceneTab.prevScene",
		categoryKey: "shortcuts.categories.chapters"
	},
	{
		id: "sceneTab.nextScene",
		scope: { mainTabs: ["chapters", "scenes"] },
		defaultChord: {
			code: "ArrowRight",
			alt: !0
		},
		allowInEditableTarget: !0,
		labelKey: "shortcuts.sceneTab.nextScene",
		categoryKey: "shortcuts.categories.chapters"
	},
	{
		id: "entityNav.prevEntity",
		scope: "global",
		defaultChord: {
			code: "ArrowLeft",
			alt: !0
		},
		allowInEditableTarget: !0,
		labelKey: "shortcuts.workbench.prevEntity",
		categoryKey: "shortcuts.categories.textareaWorkbench"
	},
	{
		id: "entityNav.nextEntity",
		scope: "global",
		defaultChord: {
			code: "ArrowRight",
			alt: !0
		},
		allowInEditableTarget: !0,
		labelKey: "shortcuts.workbench.nextEntity",
		categoryKey: "shortcuts.categories.textareaWorkbench"
	},
	{
		id: "entityNav.prevField",
		scope: "global",
		defaultChord: {
			code: "ArrowUp",
			alt: !0
		},
		allowInEditableTarget: !0,
		labelKey: "shortcuts.workbench.prevField",
		categoryKey: "shortcuts.categories.textareaWorkbench"
	},
	{
		id: "entityNav.nextField",
		scope: "global",
		defaultChord: {
			code: "ArrowDown",
			alt: !0
		},
		allowInEditableTarget: !0,
		labelKey: "shortcuts.workbench.nextField",
		categoryKey: "shortcuts.categories.textareaWorkbench"
	},
	{
		id: "textareaWorkbench.fontSizeIncrease",
		scope: "global",
		defaultChord: {
			code: "Equal",
			ctrl: !0
		},
		allowInEditableTarget: !0,
		allowKeyRepeat: !0,
		labelKey: "shortcuts.textareaWorkbench.fontSizeIncrease",
		categoryKey: "shortcuts.categories.textareaWorkbench"
	},
	{
		id: "textareaWorkbench.fontSizeDecrease",
		scope: "global",
		defaultChord: {
			code: "Minus",
			ctrl: !0
		},
		allowInEditableTarget: !0,
		allowKeyRepeat: !0,
		labelKey: "shortcuts.textareaWorkbench.fontSizeDecrease",
		categoryKey: "shortcuts.categories.textareaWorkbench"
	},
	{
		id: "textareaWorkbench.lineHeightIncrease",
		scope: "global",
		defaultChord: {
			code: "BracketRight",
			ctrl: !0
		},
		allowInEditableTarget: !0,
		allowKeyRepeat: !0,
		labelKey: "shortcuts.textareaWorkbench.lineHeightIncrease",
		categoryKey: "shortcuts.categories.textareaWorkbench"
	},
	{
		id: "textareaWorkbench.lineHeightDecrease",
		scope: "global",
		defaultChord: {
			code: "BracketLeft",
			ctrl: !0
		},
		allowInEditableTarget: !0,
		allowKeyRepeat: !0,
		labelKey: "shortcuts.textareaWorkbench.lineHeightDecrease",
		categoryKey: "shortcuts.categories.textareaWorkbench"
	},
	...Ln.actions.map((e) => ({
		id: e.id,
		scope: "any2text",
		defaultChord: e.defaultChord,
		labelKey: e.id,
		categoryKey: "any2text"
	})),
	...In.actions.map((e) => ({
		id: `director.${e.id}`,
		scope: "director",
		defaultChord: e.defaultChord,
		aliases: e.aliases,
		labelKey: `director.${e.id}`,
		categoryKey: "director",
		settingsHidden: !e.settings
	}))
];
new Map(zn.map((e) => [e.id, e])), new Map(In.actions.map((e) => [`director.${e.id}`, {
	"zh-CN": e.zh,
	en: e.en
}]));
//#endregion
//#region src/shortcuts/matchShortcut.ts
function Bn(e, t) {
	return e.code === t.code && !!e.ctrl == !!t.ctrl && !!e.alt == !!t.alt && !!e.shift == !!t.shift && !!e.meta == !!t.meta;
}
function Vn(e) {
	return !e.alt && !e.meta;
}
function Hn(e) {
	return e.code === "Equal" && !!e.ctrl && Vn(e);
}
function Un(e) {
	return e.code === "Minus" && !!e.ctrl && Vn(e);
}
function Wn(e) {
	return e.code === "Equal" && !!e.alt && !e.ctrl && !e.meta;
}
function Gn(e) {
	return e.code === "Minus" && !!e.alt && !e.ctrl && !e.meta;
}
function Kn(e, t, n) {
	return Bn(e, t) ? !0 : n === "refineWorkbench.brushOpacityIncrease" ? !(t.code !== "Equal" || e.code !== "Equal" || t.ctrl || t.meta || t.alt || e.ctrl || e.meta || e.alt) : n === "textareaWorkbench.fontSizeIncrease" && Hn(t) ? !e.ctrl || !Vn(e) ? !1 : e.code === "Equal" || e.code === "NumpadAdd" : n === "textareaWorkbench.fontSizeDecrease" && Un(t) ? !e.ctrl || !Vn(e) ? !1 : e.code === "NumpadSubtract" : n === "canvas.zoomIn" && Wn(t) ? !e.alt || e.ctrl || e.meta ? !1 : e.code === "Equal" || e.code === "NumpadAdd" : n === "canvas.zoomOut" && Gn(t) ? !e.alt || e.ctrl || e.meta ? !1 : e.code === "Minus" || e.code === "NumpadSubtract" : !1;
}
function qn(e, t, n = zn) {
	let r = n.find((t) => t.id === e);
	return r ? t && Object.prototype.hasOwnProperty.call(t, e) ? t[e] : r.defaultChord : null;
}
//#endregion
//#region src/shortcuts/normalizeKeyEvent.ts
function Jn() {
	if (typeof navigator > "u") return !1;
	let e = navigator.platform ?? "", t = navigator.userAgent ?? "";
	return e.includes("Mac") || t.includes("Mac");
}
function Yn(e, t = Jn()) {
	return t && e.metaKey || e.ctrlKey;
}
function Xn(e, t = Jn()) {
	let n = (e.code ?? "").trim();
	if (!n) return null;
	let r = { code: n };
	return Yn(e, t) && (r.ctrl = !0), e.altKey && (r.alt = !0), e.shiftKey && (r.shift = !0), e.metaKey && !t && (r.meta = !0), r;
}
function Zn(e) {
	return e.isComposing || e.keyCode === 229;
}
//#endregion
//#region src/components/textarea-workbench/styles.ts
var Qn = {
	position: "absolute",
	left: 3,
	bottom: 3,
	width: 16,
	height: 16,
	display: "flex",
	alignItems: "center",
	justifyContent: "center",
	cursor: "pointer",
	zIndex: 10,
	borderRadius: 2,
	background: "var(--surface3)",
	border: "1px solid var(--border-light)",
	opacity: .6,
	transition: "opacity 0.15s, border-color 0.15s, box-shadow 0.15s",
	color: "var(--text2)"
}, $n = {
	position: "absolute",
	right: 6,
	bottom: 3,
	minHeight: 16,
	display: "flex",
	alignItems: "center",
	justifyContent: "center",
	padding: "0 4px",
	pointerEvents: "none",
	zIndex: 10,
	borderRadius: 2,
	background: "var(--surface3)",
	border: "1px solid var(--border-light)",
	opacity: .6,
	color: "var(--text2)",
	fontSize: R.textSm,
	fontVariantNumeric: "tabular-nums",
	lineHeight: 1,
	userSelect: "none"
};
({ ...Qn }), R.textSm, R.textSm;
//#endregion
//#region src/components/ui-chrome-textarea/UiChromeTextarea.tsx
var er = [{
	id: "textareaWorkbench.fontSizeIncrease",
	label: "fontSizeIncrease",
	symbol: "+",
	step: 1
}, {
	id: "textareaWorkbench.fontSizeDecrease",
	label: "fontSizeDecrease",
	symbol: "−",
	step: -1
}], tr = {
	...Qn,
	position: "static",
	padding: 0,
	boxShadow: "none",
	lineHeight: 1
}, nr = {
	minW: 200,
	maxW: 2400,
	minH: 60,
	maxH: 1200
}, rr = e(function({ edgeConstraints: e = nr, defaultWidthPx: t = 0, defaultHeightPx: n = 120, fillAvailableHeight: r = !1, contentHeight: i = !1, shellClassName: a = "", withVersionHistory: o = !1, shellStyle: s, textareaExtraClassName: c = "", textareaProps: l, onValueChange: p, onSourceChange: m, richOwner: h, hydrateSource: g, historyCorner: _, relativeWrapStyle: v, onSizeCommit: y, shellRef: b, canvasResizeHandles: ee = !1, syntaxProfileId: te, pauseSyntaxRefresh: ne, citeImagePreviewByOrdinal: re, mediaReferenceInventory: ie, richHost: oe }, se) {
	let ce = [
		"ui-edge-resize-shell--with-font-size",
		a,
		o ? "ui-edge-resize-shell--with-history" : ""
	].filter(Boolean).join(" "), le = r ? 0 : n, { className: ue, style: de, value: x, onChange: fe, placeholder: pe, disabled: S, readOnly: C, spellCheck: me, onFocus: he, onBlur: ge, onKeyDown: w, onClick: _e, onCompositionStart: ve, onCompositionEnd: T, maxLength: E, id: D } = l, ye = l["aria-label"], be = l["aria-describedby"], xe = l["aria-invalid"], Se = [
		"ui-edit-textarea",
		c,
		ue
	].filter(Boolean).join(" "), Ce = cn(oe), we = Ce.useI18n().shortcuts?.textareaWorkbench, Te = (e) => {
		if (Ce === Y && !S && !e.defaultPrevented && !Zn(e.nativeEvent)) {
			let t = Xn(e.nativeEvent), n = t && er.find(({ id: e }) => {
				let n = qn(e, void 0);
				return n && Kn(t, n, e);
			});
			if (n) {
				e.preventDefault(), e.stopPropagation(), En(n.step, "chrome");
				return;
			}
		}
		w?.(e);
	}, Ee = (e) => {
		let t = typeof E == "number" && e.length > E ? e.slice(0, E) : e;
		p?.(t), fe?.(t);
	}, De = /* @__PURE__ */ f(u, { children: [
		_ && /* @__PURE__ */ d("div", {
			className: "ui-chrome-textarea__history",
			children: _
		}),
		/* @__PURE__ */ d("div", {
			className: "ui-chrome-textarea__font-size",
			"data-canvas-ui": !0,
			children: er.map(({ id: e, label: t, symbol: n, step: r }) => /* @__PURE__ */ d(V, {
				variant: "secondary",
				style: tr,
				disabled: S,
				"aria-label": we?.[t] ?? (r > 0 ? "增大字号" : "缩小字号"),
				shortcutActionId: e,
				onPointerDown: (e) => {
					e.preventDefault();
				},
				onClick: (e) => {
					e.stopPropagation(), En(r, "chrome");
				},
				children: n
			}, e))
		}),
		/* @__PURE__ */ d("span", {
			style: $n,
			"aria-hidden": !0,
			children: typeof E == "number" ? `${x.length}/${E}` : String(x.length)
		})
	] });
	return /* @__PURE__ */ d("div", {
		"data-ui-chrome-textarea": "1",
		"data-rich-owner": h ? `${h.ownerKind}:${h.ownerId}:${h.fieldKey}` : void 0,
		style: {
			position: "relative",
			width: "100%",
			minWidth: 0,
			...r ? {
				flex: "1 1 0%",
				minHeight: 0,
				display: "flex",
				flexDirection: "column",
				alignSelf: "stretch"
			} : null,
			...v
		},
		children: /* @__PURE__ */ d(ae, {
			shellRef: b,
			edgeConstraints: e,
			defaultWidthPx: t,
			defaultHeightPx: le,
			contentHeight: i,
			shellClassName: ce,
			shellStyle: s,
			onSizeCommit: y,
			disableHorizontalResize: !0,
			canvasResizeHandles: ee,
			bottomOverlay: De,
			children: /* @__PURE__ */ d(Fn, {
				ref: se,
				className: Se,
				style: de,
				value: x,
				onValueChange: Ee,
				onSourceChange: m,
				richOwner: h,
				hydrateSource: g,
				placeholder: pe,
				disabled: S || C,
				spellCheck: me,
				id: D,
				"aria-label": ye,
				"aria-describedby": be,
				"aria-invalid": xe || void 0,
				onFocus: he,
				onBlur: ge,
				onKeyDown: Te,
				onClick: _e,
				onCompositionStart: ve,
				onCompositionEnd: T,
				syntaxProfileId: te,
				pauseSyntaxRefresh: ne,
				citeImagePreviewByOrdinal: re,
				mediaReferenceInventory: ie,
				host: Ce
			})
		})
	});
}), ir = {
	boxSizing: "border-box",
	width: "100%",
	minWidth: 0,
	height: 38,
	padding: 9,
	fontSize: R.textMd,
	lineHeight: "18px"
}, ar = {
	display: "grid",
	gap: 4,
	minWidth: 0
};
R.textSm;
var or = {
	width: "100%",
	padding: "4px 8px",
	borderRadius: 4,
	border: "1px solid var(--border)",
	fontSize: R.textSm,
	lineHeight: "18px",
	boxSizing: "border-box",
	minHeight: 28
}, sr = { ...Rt }, cr = {
	display: "flex",
	flexDirection: "column",
	gap: 3,
	flex: "1 1 120px",
	minWidth: 110,
	maxWidth: "100%",
	boxSizing: "border-box"
}, lr = {
	display: "flex",
	flexDirection: "row",
	alignItems: "center",
	gap: 8,
	flex: "1 1 160px",
	minWidth: 140,
	maxWidth: "100%",
	boxSizing: "border-box"
}, ur = {
	...sr,
	whiteSpace: "nowrap",
	flexShrink: 0
};
function dr(e) {
	return {
		...or,
		height: 28,
		background: e ? "var(--surface2)" : "var(--surface)",
		color: "var(--text1)",
		opacity: e ? .6 : 1
	};
}
({ ...or });
//#endregion
//#region src/components/ui-chrome-select/UiChromeSelect.tsx
function fr({ label: e, hideLabel: t = !1, labelLayout: n = "stacked", controlSize: r = "compact", fieldColStyle: a, fieldTitle: o, disabled: s, id: c, style: l, children: u, ...p }) {
	let m = i(), h = c ?? m, g = n === "inline", _ = r === "form", v = {
		..._ ? {
			...ir,
			paddingRight: 28,
			opacity: s ? .6 : 1
		} : dr(s),
		...g ? {
			flex: "1 1 auto",
			minWidth: 0,
			width: "auto"
		} : null,
		...l
	}, y = /* @__PURE__ */ d("select", {
		...p,
		id: h,
		disabled: s,
		"data-ui-form-select": _ ? "true" : void 0,
		"aria-label": t ? e : p["aria-label"],
		style: v,
		children: u
	});
	return t ? /* @__PURE__ */ d("div", {
		style: a ?? {
			minWidth: 0,
			width: "100%"
		},
		title: o,
		children: y
	}) : /* @__PURE__ */ f("div", {
		style: a ?? (g ? lr : _ ? ar : cr),
		title: o,
		children: [/* @__PURE__ */ d("label", {
			htmlFor: h,
			style: g ? ur : sr,
			children: e
		}), y]
	});
}
//#endregion
//#region src/theme/themeEarlyHydrate.ts
var pr = "app_theme";
function mr() {
	try {
		let e = localStorage.getItem(pr);
		(e === "light" || e === "sakura" || e === "ocean" || e === "fresh") && (document.documentElement.dataset.theme = e);
	} catch {}
}
//#endregion
//#region src/components/common/inline-edit/claimInlineEditCommit.ts
function hr(e) {
	return e.committed ? !1 : (e.committed = !0, !0);
}
//#endregion
//#region src/theme/themeRegistry.ts
var gr = {
	dark: {
		id: "dark",
		label: "深色",
		colorScheme: "dark"
	},
	light: {
		id: "light",
		label: "浅色",
		colorScheme: "light"
	},
	sakura: {
		id: "sakura",
		label: "樱花粉",
		colorScheme: "light"
	},
	ocean: {
		id: "ocean",
		label: "海天蓝",
		colorScheme: "dark"
	},
	fresh: {
		id: "fresh",
		label: "清新绿",
		colorScheme: "light"
	}
}, _r = "app_theme";
function vr(e) {
	return e === "light" || e === "sakura" || e === "ocean" || e === "fresh" ? e : "dark";
}
//#endregion
//#region src/theme/applyThemeToDocument.ts
function yr(e) {
	let t = document.documentElement;
	e === "dark" ? delete t.dataset.theme : t.dataset.theme = e, t.style.colorScheme = gr[e].colorScheme;
}
//#endregion
//#region src/components/ui-chrome-textarea/standaloneTheme.ts
function br(e) {
	let t = vr(e);
	yr(t);
	try {
		localStorage.setItem(_r, t);
	} catch {}
}
//#endregion
//#region src/components/common/WindowControls.tsx
var xr = {
	width: 46,
	height: 32,
	display: "flex",
	alignItems: "center",
	justifyContent: "center",
	border: "none",
	background: "transparent",
	color: "var(--text2)",
	cursor: "pointer",
	fontSize: R.textLg,
	borderRadius: 4
}, Sr = { background: "var(--surface3)" };
function Cr({ max: e, onMinimize: t, onMaximize: n, onClose: r }) {
	return /* @__PURE__ */ f(u, { children: [
		/* @__PURE__ */ d("button", {
			type: "button",
			title: "最小化",
			style: xr,
			onMouseEnter: (e) => Object.assign(e.currentTarget.style, Sr),
			onMouseLeave: (e) => {
				e.currentTarget.style.background = "transparent";
			},
			onClick: () => t(),
			children: "─"
		}),
		/* @__PURE__ */ d("button", {
			type: "button",
			title: e ? "还原" : "最大化",
			style: xr,
			onMouseEnter: (e) => Object.assign(e.currentTarget.style, Sr),
			onMouseLeave: (e) => {
				e.currentTarget.style.background = "transparent";
			},
			onClick: () => {
				n();
			},
			children: e ? "❐" : "□"
		}),
		/* @__PURE__ */ d("button", {
			type: "button",
			title: "关闭",
			style: {
				...xr,
				color: "var(--text2)"
			},
			onMouseEnter: (e) => {
				e.currentTarget.style.background = "rgba(220,38,38,0.25)", e.currentTarget.style.color = "var(--danger)";
			},
			onMouseLeave: (e) => {
				e.currentTarget.style.background = "transparent", e.currentTarget.style.color = "var(--text2)";
			},
			onClick: () => r(),
			children: "×"
		})
	] });
}
//#endregion
//#region src/components/common/NativeDialog.tsx
function wr({ title: e, onClose: t, children: n, className: i }) {
	let a = c(null);
	return r(() => {
		let e = a.current;
		if (!e) return;
		let t = document.activeElement;
		return e.showModal(), () => {
			e.close(), t instanceof HTMLElement && t.isConnected && t.focus();
		};
	}, []), /* @__PURE__ */ f("dialog", {
		ref: a,
		className: i,
		"aria-label": e,
		onCancel: (e) => {
			e.preventDefault(), t();
		},
		children: [/* @__PURE__ */ d("h3", { children: e }), n]
	});
}
//#endregion
//#region src/components/common/form/SingleLineTextField.tsx
var Tr = { flex: "0 0 auto" };
function Er({ label: e, type: t, value: n, onValue: r, disabled: i, hideLabel: a, placeholder: o, maxLength: s, onBlur: c, inputMode: l, fieldStyle: u, layout: p = "inline" }) {
	let m = /* @__PURE__ */ d("input", {
		type: t,
		"aria-label": e,
		value: n,
		disabled: i,
		placeholder: o,
		inputMode: l,
		maxLength: s,
		onBlur: c,
		onChange: (e) => r(e.target.value),
		style: dr(i)
	});
	return a ? /* @__PURE__ */ d("span", {
		style: {
			display: "inline-flex",
			minWidth: 140,
			...u
		},
		children: m
	}) : /* @__PURE__ */ f("label", {
		style: {
			...cr,
			...p === "stack" ? Tr : null,
			...u
		},
		children: [/* @__PURE__ */ d("span", {
			style: sr,
			children: e
		}), m]
	});
}
//#endregion
//#region src/components/common/form/rangeSliderGeometry.ts
function Dr(e, t, n) {
	return !Number.isFinite(t) || !Number.isFinite(n) || n <= t || !Number.isFinite(e) ? 0 : Math.min(100, Math.max(0, (e - t) / (n - t) * 100));
}
function Or(e, t, n, r) {
	let i = Math.min(t, n), a = Math.max(t, n);
	if (!Number.isFinite(e)) return i;
	let o = Number.isFinite(r) && r > 0 ? r : 1, s = Math.round((Math.min(a, Math.max(i, e)) - i) / o), c = Number((i + s * o).toFixed(10));
	return Math.min(a, Math.max(i, c));
}
function kr(e, t, n, r, i, a) {
	return Or(n <= 0 ? r : r + Math.min(1, Math.max(0, (e - t) / n)) * (i - r), r, i, a);
}
//#endregion
//#region src/components/common/form/UiRangeSlider.tsx
var Ar = 4, jr = 12, Mr = 18, Nr = {
	position: "absolute",
	width: 1,
	height: 1,
	padding: 0,
	margin: -1,
	overflow: "hidden",
	clip: "rect(0, 0, 0, 0)",
	whiteSpace: "nowrap",
	border: 0,
	pointerEvents: "none",
	opacity: 0,
	appearance: "none",
	WebkitAppearance: "none"
};
function Pr({ min: e, max: t, step: r = 1, value: i, onChange: a, disabled: o = !1, "aria-label": s, style: l }) {
	let u = c(null), p = c(!1), m = Dr(i, e, t), h = n((n) => {
		let i = u.current;
		if (!i || o) return;
		let s = i.getBoundingClientRect();
		a(kr(n, s.left, s.width, e, t, r));
	}, [
		o,
		t,
		e,
		a,
		r
	]), g = n((e) => {
		o || (p.current = !0, h(e.clientX), e.currentTarget.setPointerCapture(e.pointerId));
	}, [o, h]), _ = n((e) => {
		!p.current || o || h(e.clientX);
	}, [o, h]), v = n((e) => {
		p.current = !1, e.currentTarget.hasPointerCapture(e.pointerId) && e.currentTarget.releasePointerCapture(e.pointerId);
	}, []), y = n((e) => {
		if (o) return;
		let t = Number(e.target.value);
		Number.isFinite(t) && a(t);
	}, [o, a]);
	return /* @__PURE__ */ d("div", {
		style: {
			position: "relative",
			flex: "1 1 0",
			minWidth: 0,
			width: "100%",
			height: Mr,
			display: "flex",
			alignItems: "center",
			opacity: o ? .5 : 1,
			...l
		},
		children: /* @__PURE__ */ f("div", {
			ref: u,
			onPointerDown: g,
			onPointerMove: _,
			onPointerUp: v,
			onPointerCancel: v,
			style: {
				position: "relative",
				width: "100%",
				height: Mr,
				display: "flex",
				alignItems: "center",
				cursor: o ? "default" : "pointer",
				overflow: "visible"
			},
			children: [/* @__PURE__ */ f("div", {
				"aria-hidden": !0,
				style: {
					position: "relative",
					width: "100%",
					height: Ar,
					borderRadius: Ar / 2,
					background: "color-mix(in srgb, var(--text) 16%, var(--surface2))",
					pointerEvents: "none"
				},
				children: [/* @__PURE__ */ d("div", { style: {
					position: "absolute",
					left: 0,
					top: 0,
					bottom: 0,
					width: `${m}%`,
					borderRadius: Ar / 2,
					background: "var(--primary)"
				} }), /* @__PURE__ */ d("div", { style: {
					position: "absolute",
					top: "50%",
					left: `${m}%`,
					width: jr,
					height: jr,
					marginTop: -jr / 2,
					transform: "translateX(-50%)",
					borderRadius: "50%",
					background: "var(--primary)",
					boxShadow: "0 0 0 1px var(--border)"
				} })]
			}), /* @__PURE__ */ d("input", {
				type: "range",
				"data-range-edge": "flush",
				min: e,
				max: t,
				step: r,
				value: i,
				disabled: o,
				"aria-label": s,
				onChange: y,
				tabIndex: o ? -1 : 0,
				style: Nr
			})]
		})
	});
}
//#endregion
//#region src/shortcuts/formatChord.ts
var Fr = {
	Backslash: "\\",
	Space: "空格",
	Enter: "回车",
	ArrowUp: "↑",
	ArrowDown: "↓",
	ArrowLeft: "←",
	ArrowRight: "→",
	Equal: "=",
	Minus: "-",
	BracketLeft: "[",
	BracketRight: "]",
	NumpadAdd: "+",
	NumpadSubtract: "-"
}, Ir = {
	Backslash: "\\",
	Space: "Space",
	Enter: "Enter",
	ArrowUp: "↑",
	ArrowDown: "↓",
	ArrowLeft: "←",
	ArrowRight: "→",
	Equal: "=",
	Minus: "-",
	BracketLeft: "[",
	BracketRight: "]",
	NumpadAdd: "+",
	NumpadSubtract: "-"
};
function Lr(e) {
	return e.startsWith("Key") ? e.slice(3).toUpperCase() : e.startsWith("Digit") ? e.slice(5) : e;
}
function Rr(e, t) {
	return (t === "zh-CN" ? Fr : Ir)[e] ?? Lr(e);
}
function zr(e, t, n) {
	if (!e) return t === "zh-CN" ? "无" : "None";
	let r = [];
	return e.ctrl && r.push(n ? "⌘" : "Ctrl"), e.alt && r.push(n ? "⌥" : "Alt"), e.shift && r.push(n ? "⇧" : "Shift"), e.meta && r.push(n ? "⌘" : "Win"), r.push(Rr(e.code, t)), r.join("+");
}
//#endregion
//#region src/fullscreen/createOsFullscreenController.ts
function Br(e, t) {
	let n = !1, r = Promise.resolve();
	return (i) => {
		let a = r.then(async () => {
			let r = e();
			if (await r.isFullscreen()) {
				if (i === "enter") return;
				await r.setFullscreen(!1), n && await r.maximize(), n = !1;
			} else if (i !== "exit") {
				let e = await r.isMaximized(), i = e && t();
				i && await r.toggleMaximize();
				try {
					await r.setFullscreen(!0), n = e;
				} catch (e) {
					throw i && await r.maximize(), e;
				}
			}
		});
		return r = a.catch(() => {}), a;
	};
}
//#endregion
export { V as Btn, wr as NativeDialog, Er as SingleLineTextField, fr as UiChromeSelect, rr as UiChromeTextarea, Pr as UiRangeSlider, Cr as WindowControls, Bn as chordEquals, Xn as chordFromKeyboardEvent, hr as claimInlineEditCommit, Br as createOsFullscreenController, mr as earlyHydrateTheme, zr as formatChordForDisplay, Rn as isAllowedAny2TextChord, Zn as isComposingEvent, Y as standaloneRichPlainHost, br as themeForDocument };
