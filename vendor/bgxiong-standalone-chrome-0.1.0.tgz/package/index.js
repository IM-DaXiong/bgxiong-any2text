import { forwardRef as e, memo as t, useCallback as n, useEffect as r, useId as i, useImperativeHandle as a, useLayoutEffect as o, useMemo as s, useRef as c, useState as l } from "react";
import { Fragment as u, jsx as d, jsxs as f } from "react/jsx-runtime";
import { createPortal as p } from "react-dom";
//#region src/components/ui-edge-resize-shell/edgeResizeGeometry.ts
var m = ["s"], h = [
	"n",
	"s",
	"e",
	"w",
	"ne",
	"nw",
	"se",
	"sw"
];
function g(e, t, n) {
	switch (e) {
		case "n": return {
			left: t,
			top: -t,
			right: t,
			height: n
		};
		case "s": return {
			left: t,
			bottom: -t,
			right: t,
			height: n
		};
		case "e": return {
			top: t,
			right: -t,
			bottom: t,
			width: n
		};
		case "w": return {
			top: t,
			left: -t,
			bottom: t,
			width: n
		};
		case "ne": return {
			top: -t,
			right: -t,
			width: n,
			height: n
		};
		case "nw": return {
			top: -t,
			left: -t,
			width: n,
			height: n
		};
		case "se": return {
			bottom: -t,
			right: -t,
			width: n,
			height: n
		};
		case "sw": return {
			bottom: -t,
			left: -t,
			width: n,
			height: n
		};
	}
}
function _(e, t, n, r, i, a) {
	let { minW: o, maxW: s, minH: c, maxH: l } = a, u = e, d = t;
	return n.includes("e") ? u = e + r : n.includes("w") && (u = e - r), n.includes("s") ? d = t + i : n.includes("n") && (d = t - i), u = Math.max(o, Math.min(s, u)), d = Math.max(c, Math.min(l, d)), {
		nextW: u,
		nextH: d
	};
}
//#endregion
//#region src/components/ui-edge-resize-shell/useEdgeResizeBox.ts
function v({ defaultWidthPx: e, defaultHeightPx: t, constraints: r, onSizeCommit: i }) {
	let [a, s] = l(e), [u, d] = l(t), f = c({
		w: e,
		h: t
	}), p = c(i);
	p.current = i;
	let m = c(!1);
	o(() => {
		m.current || (t !== 0 && (d((e) => e === t ? e : t), f.current.h = t), e !== 0 && (s((t) => t === e ? t : e), f.current.w = e));
	}, [e, t]);
	let h = n((e, t) => {
		s(e), d(t);
	}, []), g = n((e, t, n) => {
		let i = f.current, { nextW: a, nextH: o } = _(i.w, i.h, e, t, n, r);
		s(a), d(o);
	}, [r]), v = c({
		w: a,
		h: u
	});
	v.current = {
		w: a,
		h: u
	};
	let y = n(() => {
		m.current = !1;
		let e = p.current;
		if (e) {
			let { w: t, h: n } = v.current;
			e(t, n);
		}
	}, []);
	return {
		widthPx: a,
		heightPx: u,
		setSize: h,
		startResize: n((e, t) => (m.current = !0, f.current = {
			w: t?.w ?? a,
			h: t?.h ?? u
		}, t?.w != null && s(t.w), t?.h != null && d(t.h), e), [a, u]),
		handleMove: g,
		handleEnd: y
	};
}
//#endregion
//#region src/components/common/layout/pointerDragBodyLock.ts
var y = "", b = "";
function ee(e) {
	y = document.body.style.userSelect, b = document.body.style.cursor, document.body.style.userSelect = "none", document.body.style.cursor = e;
}
function te() {
	document.body.style.userSelect = y, document.body.style.cursor = b, y = "", b = "";
}
//#endregion
//#region src/components/ui-edge-resize-shell/usePointerEdgeSession.ts
function ne({ onMove: e, onEnd: t, cursor: i }) {
	let a = c(null), o = c(e), s = c(t);
	o.current = e, s.current = t;
	let l = n((e) => {
		let t = a.current;
		if (!t || e.pointerId !== t.pointerId) return;
		let n = e.clientX - t.startX, r = e.clientY - t.startY;
		o.current(t.edge, n, r);
	}, []), u = n(function e(t) {
		let n = a.current;
		if (!n || t && t.pointerId !== n.pointerId) return;
		a.current = null;
		let r = n.target;
		r?.removeEventListener("pointermove", l), r?.removeEventListener("pointerup", e), r?.removeEventListener("pointercancel", e), r?.removeEventListener("lostpointercapture", e), r?.hasPointerCapture?.(n.pointerId) && r.releasePointerCapture(n.pointerId), te(), t && s.current();
	}, [l]);
	return r(() => () => u(), [u]), {
		onPointerDown: n((e) => (t) => {
			if (t.button !== 0 || a.current) return;
			t.preventDefault();
			let n = t.currentTarget;
			n.setPointerCapture(t.pointerId), ee(i), a.current = {
				edge: e,
				pointerId: t.pointerId,
				startX: t.clientX,
				startY: t.clientY,
				target: n
			}, n.addEventListener("pointermove", l), n.addEventListener("pointerup", u), n.addEventListener("pointercancel", u), n.addEventListener("lostpointercapture", u);
		}, [
			i,
			l,
			u
		]),
		finishSession: u
	};
}
//#endregion
//#region src/components/ui-edge-resize-shell/UiEdgeResizeShell.tsx
var re = {
	n: "ns-resize",
	s: "ns-resize",
	e: "ew-resize",
	w: "ew-resize",
	ne: "nesw-resize",
	nw: "nwse-resize",
	se: "nwse-resize",
	sw: "nesw-resize"
};
function ie(e) {
	if (!e) return {};
	let { width: t, height: n, ...r } = e;
	return r;
}
var ae = e(function({ edgeConstraints: e, defaultWidthPx: t, defaultHeightPx: r, contentHeight: i, onSizeCommit: a, shellClassName: l = "", shellStyle: u, children: p, shellRef: _, disableHorizontalResize: y = !1, canvasResizeHandles: b = !1, showBottomGrip: ee = !1, bottomOverlay: te }, ae) {
	let { widthPx: oe, heightPx: se, startResize: ce, handleMove: le, handleEnd: ue } = v({
		defaultWidthPx: t,
		defaultHeightPx: r,
		constraints: e,
		onSizeCommit: s(() => {
			if (a) return y ? (e, t) => {
				a(0, t);
			} : a;
		}, [a, y])
	}), de = c(null), x = c(!1), fe = c(!1);
	o(() => {
		if (t !== 0) return;
		let e = de.current;
		if (!e) return;
		let n = e.parentElement ?? e, r = (e) => {
			e <= 0 || x.current;
		}, i = new ResizeObserver((e) => {
			let t = e[0]?.contentRect;
			t && r(Math.round(t.width));
		});
		return i.observe(n), r(Math.round(n.getBoundingClientRect().width)), () => {
			i.disconnect();
		};
	}, [t]);
	let pe = n((e) => {
		de.current = e, typeof ae == "function" ? ae(e) : ae && (ae.current = e), typeof _ == "function" ? _(e) : _ && (_.current = e);
	}, [ae, _]), { onPointerDown: S } = ne({
		onMove: le,
		onEnd: ue,
		cursor: "default"
	}), C = y ? m : h, me = t === 0 && !x.current, he = r === 0 && !fe.current, ge = s(() => {
		let e = {};
		for (let n of C) e[n] = (e) => {
			b && e.stopPropagation();
			let i = !y || n !== "s" && n !== "n", a = n === "n" || n === "s" || n === "ne" || n === "nw" || n === "se" || n === "sw";
			i && (x.current = !0), a && (fe.current = !0);
			let o = de.current?.getBoundingClientRect(), s = {};
			t === 0 && o && o.width > 0 && (s.w = Math.round(o.width)), r === 0 && o && o.height > 0 && (s.h = Math.round(o.height)), ce(n, Object.keys(s).length > 0 ? s : void 0), S(n)(e);
		};
		return e;
	}, [
		ce,
		S,
		C,
		y,
		b,
		t,
		r
	]), w = 5 / 2, _e = b ? {
		"data-canvas-ui": !0,
		"data-canvas-resize-handle": "true"
	} : {}, T = ["ui-edge-resize-shell", l].filter(Boolean).join(" "), ve = ie(u), ye = y || ee ? /* @__PURE__ */ d("div", { className: "ui-edge-resize-shell__bottom-grip" }) : null;
	return /* @__PURE__ */ f("div", {
		ref: pe,
		className: T,
		style: {
			...me ? {
				width: "100%",
				maxWidth: "100%",
				minWidth: 0
			} : { width: oe },
			...he ? {
				flex: "1 1 0%",
				minHeight: 0,
				height: "auto",
				alignSelf: "stretch"
			} : i ? {
				height: "auto",
				minHeight: se
			} : { height: se },
			...ve
		},
		"data-ui-input": "true",
		children: [
			/* @__PURE__ */ d("div", {
				className: "ui-edge-resize-shell__hits",
				children: C.map((e) => /* @__PURE__ */ d("div", {
					className: "ui-edge-resize-shell__hit",
					"data-edge": e,
					..._e,
					style: {
						...g(e, w, 5),
						...e === "s" && te ? {
							height: `calc(var(--ui-edge-resize-bottom-overlay-height) + ${w}px)`,
							...y ? {
								left: 0,
								right: 0
							} : null
						} : null,
						cursor: re[e]
					},
					onPointerDown: ge[e]
				}, e))
			}),
			/* @__PURE__ */ d("div", {
				className: "ui-edge-resize-shell__body",
				children: p
			}),
			te ? /* @__PURE__ */ f("div", {
				className: "ui-edge-resize-shell__bottom-overlay",
				children: [ye, te]
			}) : ye
		]
	});
});
//#endregion
//#region src/domain/rich-plain-text/applyMarks.ts
function oe(e, t, n) {
	return {
		start: Math.max(0, Math.min(t, n, e.length)),
		end: Math.max(0, Math.min(Math.max(t, n), e.length))
	};
}
function se(e, t, n) {
	let r = oe(e.plain, t, n);
	if (r.start === r.end) return !1;
	let i = Array(e.plain.length).fill(!1);
	for (let t of e.intervals) {
		if (t.bold === void 0) continue;
		let n = Math.max(0, t.start), r = Math.min(e.plain.length, t.end);
		for (let e = n; e < r; e++) i[e] = t.bold;
	}
	for (let e = r.start; e < r.end; e++) if (!i[e]) return !1;
	return !0;
}
function ce(e, t, n) {
	let r = oe(e.plain, t, n);
	if (r.start === r.end) return e;
	let i = !se(e, r.start, r.end);
	return {
		plain: e.plain,
		intervals: [...e.intervals, {
			start: r.start,
			end: r.end,
			bold: i
		}]
	};
}
function le(e, t, n, r) {
	let i = oe(e.plain, t, n);
	return i.start === i.end ? e : {
		plain: e.plain,
		intervals: [...e.intervals, {
			start: i.start,
			end: i.end,
			color: r
		}]
	};
}
function ue(e, t, n) {
	let r = oe(e.plain, t, n);
	return r.start === r.end ? e : {
		plain: e.plain,
		intervals: [...e.intervals, {
			start: r.start,
			end: r.end,
			bold: !1,
			color: null
		}]
	};
}
function de(e, t, n, r) {
	let i = oe(e.plain, t, n), a = i.end - i.start, o = r.length - a;
	return {
		plain: e.plain.slice(0, i.start) + r + e.plain.slice(i.end),
		intervals: e.intervals.map((e) => {
			let t = e.start, n = e.end;
			return n <= i.start ? e : t >= i.end ? {
				...e,
				start: t + o,
				end: n + o
			} : t >= i.start && n <= i.end ? null : t < i.start && n > i.end ? {
				...e,
				end: n + o
			} : t < i.start ? {
				...e,
				end: i.start
			} : {
				...e,
				start: i.start + r.length,
				end: n + o
			};
		}).filter((e) => e != null && e.end > e.start)
	};
}
//#endregion
//#region src/domain/rich-plain-text/escape.ts
function x(e) {
	return e.replace(/&/g, "&amp;").replace(/</g, "&lt;");
}
function fe(e, t) {
	return e.startsWith("&amp;", t) ? {
		char: "&",
		consumed: 5
	} : e.startsWith("&lt;", t) ? {
		char: "<",
		consumed: 4
	} : null;
}
//#endregion
//#region src/domain/rich-plain-text/flatten.ts
function pe(e) {
	let t = e.plain.length;
	if (t === 0) return [];
	if (e.intervals.length === 0) return [{
		text: e.plain,
		bold: !1,
		color: null
	}];
	let n = Array(t).fill(!1), r = Array(t).fill(null);
	for (let i of e.intervals) {
		let e = Math.max(0, Math.min(i.start, t)), a = Math.max(e, Math.min(i.end, t));
		for (let t = e; t < a; t++) i.bold !== void 0 && (n[t] = i.bold), i.color !== void 0 && (r[t] = i.color);
	}
	let i = [], a = 0;
	for (; a < t;) {
		let o = n[a] ?? !1, s = r[a] ?? null, c = a + 1;
		for (; c < t && (n[c] ?? !1) === o && (r[c] ?? null) === s;) c += 1;
		i.push({
			text: e.plain.slice(a, c),
			bold: o,
			color: s
		}), a = c;
	}
	return i;
}
function S(e) {
	return e.some((e) => e.bold || e.color != null);
}
function C(e) {
	let t = "", n = [];
	for (let r of e) {
		let e = t.length;
		t += r.text;
		let i = t.length;
		e !== i && (r.bold && n.push({
			start: e,
			end: i,
			bold: !0
		}), r.color && n.push({
			start: e,
			end: i,
			color: r.color
		}));
	}
	return {
		plain: t,
		intervals: n
	};
}
//#endregion
//#region src/domain/media-reference-editor/constants.ts
var me = /@\{ref:([A-Za-z0-9_-]+)\}/g;
//#endregion
//#region src/domain/media-reference-editor/token.ts
function he(e) {
	let t = [], n = new RegExp(me.source, "g"), r;
	for (; (r = n.exec(e)) !== null;) {
		let e = r[1] ?? "";
		t.push({
			referenceId: e,
			start: r.index,
			end: r.index + r[0].length
		});
	}
	return t;
}
//#endregion
//#region src/domain/media-reference-editor/mediaRefDisplay.ts
function ge(e, t) {
	return `@${(Object.hasOwn(t, e) ? t[e] : "") || "已移除图片"}`;
}
//#endregion
//#region src/domain/video-prompt-mention/projectMediaCite.ts
var w = /(?<!@)@(图|音|视频)([1-9]\d*)(?![A-Za-z0-9_])/g;
function _e(e) {
	let t = [], n = new RegExp(w.source, "g"), r;
	for (; (r = n.exec(e)) !== null;) {
		let e = Number(r[2]);
		Number.isSafeInteger(e) && (t.push({
			start: r.index,
			end: r.index + r[0].length,
			kind: r[1] === "图" ? "image" : r[1] === "音" ? "audio" : "video",
			ordinal: e
		}), r[0].length === 0 && (n.lastIndex += 1));
	}
	return t;
}
//#endregion
//#region src/domain/rich-plain-text/displayHtml.ts
function T(e) {
	return x(e).replace(/"/g, "&quot;");
}
function ve(e = []) {
	let t = [...e].sort((e, t) => e.start - t.start), n = 0;
	return (e) => {
		for (; t[n]?.end <= e;) n += 1;
		let r = t[n];
		return r && r.start <= e ? {
			span: r,
			boundary: r.end
		} : {
			span: void 0,
			boundary: r?.start ?? Infinity
		};
	};
}
function ye(e, t, n) {
	let r = ve(t.decoSpans), i = ve(t.mediaRefSpans), a = ve(n), o = [], s = 0;
	for (let t of pe(e)) {
		let e = s + t.text.length, n = s;
		for (; n < e;) {
			let c = r(n), l = i(n), u = a(n), d = l.span || c.span?.kind === "dialogue" ? void 0 : u.span, f = Math.min(e, c.boundary, l.boundary, u.boundary);
			o.push({
				text: t.text.slice(n - s, f - s),
				bold: t.bold,
				color: t.color,
				deco: d ? "refTag" : c.span?.kind ?? null,
				cite: d ? {
					media: d.kind,
					ord: d.ordinal
				} : c.span?.cite ?? null,
				mediaRefId: l.span?.referenceId ?? null,
				projectCite: d ?? null
			}), n = f;
		}
		s = e;
	}
	return o;
}
function be(e, t, n) {
	let r = x(e.text), i = e.bold ? `<strong>${r}</strong>` : r;
	if (e.mediaRefId) {
		let r = (t?.[e.mediaRefId] ?? "").trim(), a = r ? `<img data-media-ref-thumb="1" data-rich-display-only="1" draggable="false" alt="" src="${T(r)}" style="width:1.25em;height:1.25em;object-fit:cover;border-radius:2px;vertical-align:middle;margin-right:2px" />` : "";
		return n && e.text === `@{ref:${e.mediaRefId}}` ? `<span contenteditable="false" data-rich-source="${T(e.text)}" data-rich-deco="mediaRef" data-media-ref-id="${T(e.mediaRefId)}" style="display:inline-block;border-radius:4px;padding:0 3px;background:color-mix(in srgb, var(--accent) 14%, transparent)">${a}${x(ge(e.mediaRefId, n))}</span>` : (i = `<span data-rich-deco="mediaRef" data-media-ref-id="${T(e.mediaRefId)}" data-media-ref-kind="image" style="display:inline;border-radius:4px;padding:0 2px;background:color-mix(in srgb, var(--accent) 14%, transparent)">${a}${i}</span>`, i);
	}
	e.color && (i = "<span data-rich-color=\"" + e.color + "\">" + i + "</span>");
	let a = e.cite ? " data-cite-kind=\"" + e.cite.media + "\" data-cite-ord=\"" + e.cite.ord + "\"" : "", o = e.projectCite && !e.color ? " data-project-media-cite=\"" + e.projectCite.kind + "\" data-project-media-ord=\"" + e.projectCite.ordinal + "\" style=\"display:inline;border-radius:4px;padding:0 2px;background:color-mix(in srgb, var(--accent) 14%, transparent)\"" : "";
	return e.deco && !e.color ? i = "<span data-rich-deco=\"" + e.deco + "\"" + a + o + ">" + i + "</span>" : a && (i = "<span" + a + ">" + i + "</span>"), i;
}
function xe(e) {
	let t = 2048, n = [];
	for (let r = 0; r < e.length;) {
		let i = Math.min(r + t, e.length);
		if (i < e.length) {
			let n = Math.max(e.lastIndexOf(" ", i), e.lastIndexOf("\n", i));
			n > r + t / 2 ? i = n + 1 : e.charCodeAt(i) >= 56320 && e.charCodeAt(i) <= 57343 && (i += 1);
		}
		n.push("<span>" + x(e.slice(r, i)) + "</span>"), r = i;
	}
	return n.join("");
}
function Se(e, t) {
	let n = Array.isArray(t) ? { decoSpans: t } : t ?? {}, r = ve(n.decoSpans?.filter((e) => e.kind === "dialogue"));
	return ye(e, n, _e(e.plain).filter((e) => !r(e.start).span)).map((e) => n.chunkLongPlainRuns && e.text.length > 8192 && !e.bold && !e.color && !e.deco && !e.cite && !e.mediaRefId ? xe(e.text) : be(e, n.mediaRefPreviewById, n.mediaRefLabelById)).join("");
}
//#endregion
//#region src/domain/media-reference-editor/buildMediaRefDisplaySpans.ts
function Ce(e) {
	return he(e).map((e) => ({
		start: e.start,
		end: e.end,
		referenceId: e.referenceId
	}));
}
function we(e) {
	return e ? Object.keys(e).sort().map((t) => `${t}=${e[t] ?? ""}`).join("\n") : "";
}
//#endregion
//#region src/domain/rich-plain-text/types.ts
var Te = [
	"c1",
	"c2",
	"c3",
	"c4",
	"c5",
	"c6"
], Ee = "正文已保存，样式未写入";
function E(e) {
	return Te.includes(e);
}
function De(e = "") {
	return {
		plain: e,
		intervals: []
	};
}
//#endregion
//#region src/components/rich-plain-editor/walkDom.ts
function D(e) {
	return e === "div" || e === "p" || e === "li" || e === "h1" || e === "h2";
}
function Oe(e, t = !0) {
	let n = "", r = [], i = 0, a = !1, o = null, s = () => {
		let e = n.length;
		i !== e && (a && r.push({
			start: i,
			end: e,
			bold: !0
		}), o && r.push({
			start: i,
			end: e,
			color: o
		}));
	}, c = (e, t, r) => {
		e && ((t !== a || r !== o) && (s(), i = n.length, a = t, o = r), n += e);
	}, l = (t, r, i, a) => {
		if (t.nodeType === Node.TEXT_NODE) {
			c(t.textContent ?? "", r, i);
			return;
		}
		if (t.nodeType !== Node.ELEMENT_NODE) return;
		let o = t, s = o.tagName.toLowerCase(), u = o.getAttribute("data-rich-source");
		if (u !== null) {
			c(u, r, i);
			return;
		}
		if (s === "br") {
			c("\n", r, i);
			return;
		}
		let d = r, f = i;
		if ((s === "strong" || s === "b") && (d = !0), o.getAttribute("data-rich-display-only") === "1" || o.getAttribute("data-media-ref-thumb") === "1" || s === "img") return;
		if (s === "span") {
			let e = o.getAttribute("data-rich-color");
			e && E(e) && (f = e);
		}
		let p = D(s) && o !== e;
		p && n.length > 0 && !n.endsWith("\n") && c("\n", d, f);
		let m = Array.from(o.childNodes);
		for (let e of m) l(e, d, f, p ? o : a);
	};
	if (l(e, !1, null, null), t && n === "\n" && e.childNodes.length === 1) {
		let t = e.firstChild;
		if (t && t.nodeType === Node.ELEMENT_NODE && t.tagName.toLowerCase() === "br") return De("");
	}
	return s(), {
		plain: n,
		intervals: r
	};
}
function ke(e, t, n) {
	let r = document.createRange();
	try {
		r.selectNodeContents(e), r.setEnd(t, n);
	} catch {
		return null;
	}
	let i = document.createElement("div");
	return i.appendChild(r.cloneContents()), Oe(i, e.childNodes.length === 1 && e.firstChild?.nodeName === "BR").plain.length;
}
function Ae(e, t) {
	let n = e.querySelector("div,p,li,h1,h2,br,[data-rich-source],[data-rich-display-only],[data-media-ref-thumb]") !== null, r = (t, r) => {
		if (n) return ke(e, t, r);
		let i = e.ownerDocument.createRange();
		i.selectNodeContents(e);
		try {
			i.setEnd(t, r);
		} catch {
			return null;
		}
		return i.toString().length;
	}, i = r(t.startContainer, t.startOffset);
	if (t.collapsed) return i === null ? null : {
		start: i,
		end: i
	};
	let a = r(t.endContainer, t.endOffset);
	return i == null || a == null ? null : {
		start: Math.min(i, a),
		end: Math.max(i, a)
	};
}
function je(e, t, n) {
	let r = document.activeElement;
	if (!(r instanceof Node) || !e.contains(r)) return;
	let i = window.getSelection();
	if (!i) return;
	let a = Ne(e, t), o = Ne(e, n);
	if (!a || !o) return;
	let s = document.createRange();
	s.setStart(a.node, a.offset), s.setEnd(o.node, o.offset), i.removeAllRanges(), i.addRange(s);
}
function Me(e, t, n) {
	let r = Ne(e, t), i = Ne(e, n);
	if (!r || !i) return null;
	let a = document.createRange();
	return a.setStart(r.node, r.offset), a.setEnd(i.node, i.offset), a;
}
function Ne(e, t) {
	if (t <= 0) return {
		node: e,
		offset: 0
	};
	let n = document.createTreeWalker(e, NodeFilter.SHOW_TEXT | NodeFilter.SHOW_ELEMENT, { acceptNode(e) {
		return e.parentElement?.closest("[data-rich-source], [data-rich-display-only=\"1\"]") || e instanceof HTMLElement && e.getAttribute("data-rich-display-only") === "1" ? NodeFilter.FILTER_REJECT : NodeFilter.FILTER_ACCEPT;
	} }), r = t, i = n.nextNode(), a = null;
	for (; i;) {
		let e = i instanceof HTMLElement ? i.getAttribute("data-rich-source") : null;
		if (e !== null) {
			let t = i.parentNode;
			if (!t) return a;
			let n = Array.from(t.childNodes).indexOf(i);
			if (r <= e.length) return {
				node: t,
				offset: n + (r > e.length / 2 ? 1 : 0)
			};
			r -= e.length, a = {
				node: t,
				offset: n + 1
			};
		} else if (i.nodeType === Node.ELEMENT_NODE && i.tagName.toLowerCase() === "br") {
			if (r <= 1) {
				let e = i.parentNode;
				return e ? {
					node: e,
					offset: Array.from(e.childNodes).indexOf(i) + 1
				} : a;
			}
			--r;
		} else if (i.nodeType === Node.TEXT_NODE) {
			let e = i.textContent ?? "";
			if (r <= e.length) return {
				node: i,
				offset: r
			};
			r -= e.length, a = {
				node: i,
				offset: e.length
			};
		}
		i = n.nextNode();
	}
	return a ?? {
		node: e,
		offset: e.childNodes.length
	};
}
//#endregion
//#region src/domain/media-reference-editor/offsetFromPoint.ts
function Pe(e, t, n, r) {
	let i = Fe(e, t, n, r);
	return i.kind === "outside" ? null : i.kind === "hit" ? i.offset : r;
}
function Fe(e, t, n, r) {
	let i = e.getBoundingClientRect();
	if (t < i.left || t > i.right || n < i.top || n > i.bottom) return { kind: "outside" };
	let a = e.ownerDocument, o = null;
	if (typeof a.caretRangeFromPoint == "function") o = a.caretRangeFromPoint(t, n);
	else if (typeof a.caretPositionFromPoint == "function") {
		let e = a.caretPositionFromPoint(t, n);
		if (e) {
			o = a.createRange();
			try {
				o.setStart(e.offsetNode, e.offset), o.collapse(!0);
			} catch {
				o = null;
			}
		}
	}
	if (!o || !e.contains(o.startContainer)) return { kind: "miss" };
	let s = Ae(e, o);
	return s ? {
		kind: "hit",
		offset: Math.max(0, Math.min(s.start, r)),
		range: o
	} : { kind: "miss" };
}
var Ie = "PROMPT_SYNTAX_PROFILE_MISSING", Le = "PROMPT_SYNTAX_HIGHLIGHT_FAILED", Re = "PROMPT_SYNTAX", O = /* @__PURE__ */ new Map();
function ze(e) {
	return O.get(e);
}
//#endregion
//#region src/domain/prompt-syntax-highlight/bracketKeywords.ts
function k(e) {
	if (e.length > 65536) return [];
	let t = [];
	for (let n of e.matchAll(/<[^<>\r\n]+>|〈[^〈〉\r\n]+〉/gu)) {
		let r = n[0], i = n.index, a = i + r.length;
		r.slice(1, -1).trim() && (r[0] === "<" && (e[i - 1] === "<" || e[a] === ">") || t.push({
			start: i,
			end: a,
			kind: "refTag"
		}));
	}
	return t;
}
//#endregion
//#region src/domain/prompt-syntax-highlight/profiles/citePush.ts
function Be(e, t, n, r) {
	t.lastIndex = 0;
	let i;
	for (; (i = t.exec(e)) !== null;) r.push({
		start: i.index,
		end: i.index + i[0].length,
		kind: n
	}), i[0].length === 0 && (t.lastIndex += 1);
}
//#endregion
//#region src/domain/prompt-syntax-highlight/dialogue.ts
function Ve(e) {
	let t = [], n = -1;
	for (let r of e.matchAll(/<d>|<\/d>/g)) r[0] === "<d>" ? n = r.index : n >= 0 && (t.push({
		start: n,
		end: r.index + r[0].length,
		kind: "dialogue"
	}), n = -1);
	return t;
}
function He(e) {
	let t = [];
	return Be(e, /\{[^{}]+\}/g, "dialogue", t), t;
}
var Ue = {
	schemaVersion: 1,
	baseKeys: [
		"integrated_multimodal_description",
		"overall_soundscape",
		"non_diegetic_music"
	],
	refKeys: [
		"subject_definitions",
		"summary",
		"retention_analysis",
		"detailed_description",
		"overall_soundscape",
		"non_diegetic_music"
	]
}, A = {
	schemaVersion: 1,
	purpose: "Reference-marker templates of the video prompt target adapters, one entry per projection profile (profileId@version). Single source for the Rust projectors (build.rs emits CITE_TPL_<rustConst>_<SLOT>). Each entry lists only the media slots its projector writes; which entry a target uses is decided by its projector, never by provider kind, model id or name.",
	profiles: {
		"h3@1": {
			rustConst: "H3",
			templates: {
				image: "<Picture {n}>",
				video: "<Video {n}>",
				audio: "<Audio {n}>"
			}
		},
		"seedance@1": {
			rustConst: "SEEDANCE",
			templates: {
				image: "图片{n}",
				video: "视频{n}",
				audio: "音频{n}"
			}
		},
		"kling.classic@1": {
			rustConst: "KLING_CLASSIC",
			templates: { image: "@image_{n}" }
		},
		"kling.omni@1": {
			rustConst: "KLING_OMNI",
			templates: {
				image: "<<<image_{n}>>>",
				video: "<<<video_{n}>>>"
			}
		},
		"kling.omni@2": {
			rustConst: "KLING_OMNI_V2",
			templates: {
				image: "@image_{n}",
				video: "@video_{n}"
			}
		},
		"wan@1": {
			rustConst: "WAN",
			templates: {
				image: "图{n}",
				video: "视频{n}",
				audio: "音频{n}"
			}
		}
	}
}, j = (e) => e.replace(/[.*+?^${}()|[\]\\]/g, "\\$&"), We = /* @__PURE__ */ new Map(), M = {
	"wan@1": [
		["image", "图片{n}"],
		["image", "Image {n}"],
		["video", "Video {n}"]
	],
	"kling.omni@1": [["subject", "<<<element_{n}>>>"]],
	"h3@1": [["subject", "<Subject {n}>"]]
};
function Ge(e) {
	let [t, n] = e.split("{n}"), r = /^\p{Script=Han}/u.test(t), i = t.startsWith("<") ? "(?<!<)" : r ? "@?" : "(?<![A-Za-z0-9_@])", a = n.endsWith(">") ? "(?!>)" : "(?![A-Za-z0-9_])", o = t.endsWith("_") || e === "<image{n}>" ? "" : t.endsWith(" ") ? "[ \\t]+" : "[ \\t]*";
	return RegExp(i + j(t.trimEnd()) + o + "([1-9][0-9]*)" + j(n) + a, "gu");
}
function Ke(e, t, n, r) {
	for (let i of e.matchAll(t)) {
		let e = Number(i[1]);
		Number.isSafeInteger(e) && r.push({
			start: i.index,
			end: i.index + i[0].length,
			kind: "refTag",
			cite: {
				media: n,
				ord: e
			}
		});
	}
}
for (let e of Object.keys(A.profiles)) {
	let t = Object.entries(A.profiles[e].templates);
	We.set(e, [...t, ...M[e] ?? []].map(([e, t]) => ({
		media: e,
		pattern: Ge(t)
	})));
}
Array.from(new Set([...Ue.baseKeys, ...Ue.refKeys])).sort((e, t) => t.length - e.length);
//#endregion
//#region src/domain/prompt-syntax-highlight/resolveDecoSpans.ts
function qe(e, t) {
	let n = Array(e).fill(!1);
	for (let r of t) {
		if (!r.color) continue;
		let t = Math.max(0, Math.min(r.start, e)), i = Math.max(t, Math.min(r.end, e));
		for (let e = t; e < i; e++) n[e] = !0;
	}
	return n;
}
function N(e, t, n) {
	let r = e.length;
	if (r === 0 || r > 65536) return [];
	let i = Array(r).fill(!1), a = qe(r, n), o = [];
	for (let e of t) {
		let t = Math.max(0, Math.min(e.start, r)), n = Math.max(t, Math.min(e.end, r)), s = t;
		for (; s < n;) {
			if (i[s] || a[s]) {
				s += 1;
				continue;
			}
			let t = s + 1;
			for (; t < n && !i[t] && !a[t];) t += 1;
			for (let e = s; e < t; e++) i[e] = !0;
			o.push({
				start: s,
				end: t,
				kind: e.kind,
				cite: e.cite
			}), s = t;
		}
	}
	return o;
}
//#endregion
//#region src/domain/prompt-syntax-highlight/tokenizePrompt.ts
var Je = Ge("<image{n}>");
function Ye() {
	let e = "", t = /* @__PURE__ */ new Map();
	return function* (n, r) {
		if (!n || n.length > 65536) return t = /* @__PURE__ */ new Map(), [];
		let i = JSON.stringify([r.id, r.version]), a = i === e ? t : /* @__PURE__ */ new Map(), o = /* @__PURE__ */ new Map(), s = Ve(n);
		r.braceDialogue && s.push(...He(n));
		let c = [], l = [], u = 0;
		for (r.highlightLine || c.push(...r.highlight(n)); u <= n.length;) {
			let e = n.indexOf("\n", u), t = e === -1 ? n.length : e, i = n.slice(u, t), d = o.get(i) ?? a.get(i);
			if (!d) {
				d = r.highlightLine?.(i) ?? [], r.id === "image_prompt" && Ke(i, Je, "image", d);
				let e = k(i).filter((e) => {
					let t = i.slice(e.start, e.end);
					return t !== "<d>" && t !== "</d>";
				});
				d = [...d, ...e];
			}
			o.set(i, d);
			for (let e of d) {
				let t = {
					...e,
					start: e.start + u,
					end: e.end + u
				};
				e.kind === "dialogue" ? s.push(t) : e.kind === "refTag" && !e.cite ? l.push(t) : c.push(t);
			}
			u = t + 1, yield;
		}
		return e = i, t = o, N(n, [
			...s,
			...c,
			...l
		], []);
	};
}
//#endregion
//#region src/domain/prompt-syntax-highlight/highlightEnabled.ts
var Xe = "bgx.promptSyntaxHighlight.enabled.v1", Ze = /* @__PURE__ */ new Set();
function Qe() {
	try {
		let e = localStorage.getItem(Xe);
		return e === null ? !0 : e === "1";
	} catch {
		return !0;
	}
}
function $e(e) {
	Ze.add(e);
	let t = (t) => {
		t.key === "bgx.promptSyntaxHighlight.enabled.v1" && e();
	};
	return window.addEventListener("storage", t), () => {
		Ze.delete(e), window.removeEventListener("storage", t);
	};
}
//#endregion
//#region src/components/rich-plain-editor/usePromptImageHover.ts
function et(e, t, i, a, o) {
	let s = c(null), [u, d] = l(null), f = n(() => {
		s.current && (s.current = null, d(null));
	}, []);
	return r(() => (f(), window.addEventListener("scroll", f, !0), window.addEventListener("resize", f), () => {
		window.removeEventListener("scroll", f, !0), window.removeEventListener("resize", f);
	}), [
		e,
		t,
		i,
		a,
		o,
		f
	]), {
		hover: u,
		target: s,
		show: (e, t, n, r, i) => {
			if (s.current?.element === e && s.current.url === t && s.current.range === n) return;
			let a = e.getBoundingClientRect();
			if (n) {
				let e = Array.from(n.getClientRects()).find((e) => r !== void 0 && i !== void 0 && r >= e.left && r <= e.right && i >= e.top && i <= e.bottom);
				if (!e) {
					f();
					return;
				}
				a = e;
			}
			s.current = {
				element: e,
				url: t,
				range: n
			}, d({
				url: t,
				centerX: a.left + a.width / 2,
				top: a.top,
				bottom: a.bottom
			});
		},
		close: f
	};
}
//#endregion
//#region src/components/rich-plain-editor/longPromptHighlights.ts
function tt(e, t, n) {
	return e.length >= 32768 && !e.includes("\n") && !/@(?:图|音|视频)\d/.test(e) && !t && !n && typeof Highlight < "u" && typeof CSS < "u" && !!CSS.highlights;
}
function nt(e, t) {
	let n = /* @__PURE__ */ new Map(), r = [], i = e.ownerDocument.createTreeWalker(e, NodeFilter.SHOW_TEXT), a = i.nextNode(), o = 0, s = (e) => {
		for (; a && e > o + a.length;) o += a.length, a = i.nextNode();
		return a ? {
			node: a,
			offset: e - o
		} : null;
	};
	for (let i of [...t].sort((e, t) => e.start - t.start)) {
		let t = s(i.start), a = s(i.end);
		if (!t || !a) break;
		let o = e.ownerDocument.createRange();
		o.setStart(t.node, t.offset), o.setEnd(a.node, a.offset);
		let c = n.get(i.kind);
		c ? c.push(o) : n.set(i.kind, [o]), i.cite?.media === "image" && r.push({
			range: o,
			ord: i.cite.ord,
			start: i.start,
			end: i.end
		});
	}
	let c = [];
	for (let [e, t] of n) {
		let n = "bgx-prompt-" + e, r = CSS.highlights.get(n) ?? new Highlight();
		for (let e of t) r.add(e);
		CSS.highlights.set(n, r), c.push({
			highlight: r,
			ranges: t
		});
	}
	return {
		imageAt(e) {
			let t = 0, n = r.length;
			for (; t < n;) {
				let i = t + n >>> 1, a = r[i];
				if (e < a.start) n = i;
				else if (e >= a.end) t = i + 1;
				else return a;
			}
		},
		clear() {
			for (let { highlight: e, ranges: t } of c) for (let n of t) e.delete(n);
		}
	};
}
//#endregion
//#region src/components/rich-plain-editor/replaceChangedDisplay.ts
function rt(e, t) {
	let n = e.ownerDocument.createElement("template");
	n.innerHTML = t;
	let r = Array.from(e.childNodes), i = Array.from(n.content.childNodes), a = 0, o = r.length, s = i.length;
	for (; a < o && a < s && r[a].isEqualNode(i[a]);) a += 1;
	for (; a < o && a < s && r[o - 1].isEqualNode(i[s - 1]);) --o, --s;
	for (let t = a; t < o; t += 1) e.removeChild(r[t]);
	if (a < s) {
		let t = e.ownerDocument.createDocumentFragment();
		for (let e = a; e < s; e += 1) t.append(i[e]);
		e.insertBefore(t, r[o] ?? null);
	}
}
//#endregion
//#region src/domain/rich-plain-text/liveRegistry.ts
var it = /* @__PURE__ */ new Map(), at = /* @__PURE__ */ new Map();
function ot(e) {
	if (e) for (let t of at.get(st(e)) ?? []) t();
}
function st(e) {
	return `${e.ownerKind}\0${e.ownerId}\0${e.fieldKey}`;
}
function ct(e) {
	return !e?.ownerId?.trim() || !e.fieldKey?.trim() ? "" : `${e.ownerKind}\0${e.ownerId}\0${e.fieldKey}\0${e.storyId ?? ""}`;
}
function lt(e, t) {
	let n = it.get(e);
	it.set(e, t), n && st(n.owner) !== st(t.owner) && ot(n.owner), ot(t.owner);
}
function ut(e) {
	let t = it.get(e);
	it.delete(e), ot(t?.owner);
}
//#endregion
//#region src/domain/rich-plain-text/editorDomRegistry.ts
var dt = /* @__PURE__ */ new WeakMap();
function ft(e, t) {
	dt.set(e, t);
}
function pt(e) {
	dt.delete(e);
}
//#endregion
//#region src/domain/rich-plain-text/parse.ts
var mt = "<bgx-b>", ht = "</bgx-b>", gt = "</bgx-c>";
function _t(e, t) {
	if (!e.startsWith("<bgx-c v=\"", t)) return null;
	let n = t + 10, r = e.slice(n, n + 2);
	return !E(r) || e.slice(n + 2, n + 4) !== "\">" ? null : {
		color: r,
		consumed: 14
	};
}
function vt(e) {
	if (e.length === 0) return {
		ok: !0,
		doc: {
			plain: "",
			intervals: []
		}
	};
	let t = 0, n = "", r = [], i = [], a = (e) => ({
		ok: !1,
		reason: e
	});
	for (; t < e.length;) {
		let o = e[t];
		if (o === "&") {
			let r = fe(e, t);
			if (!r) return a("bare_ampersand");
			n += r.char, t += r.consumed;
			continue;
		}
		if (o === "<") {
			if (e.startsWith(mt, t)) {
				i.push({
					kind: "b",
					start: n.length
				}), t += 7;
				continue;
			}
			if (e.startsWith(ht, t)) {
				let e = i.pop();
				if (!e || e.kind !== "b") return a("tag_mismatch_b");
				r.push({
					start: e.start,
					end: n.length,
					bold: !0
				}), t += 8;
				continue;
			}
			let o = _t(e, t);
			if (o) {
				i.push({
					kind: "c",
					start: n.length,
					color: o.color
				}), t += o.consumed;
				continue;
			}
			if (e.startsWith(gt, t)) {
				let e = i.pop();
				if (!e || e.kind !== "c") return a("tag_mismatch_c");
				r.push({
					start: e.start,
					end: n.length,
					color: e.color
				}), t += 8;
				continue;
			}
			return a("unknown_tag");
		}
		n += o, t += 1;
	}
	return i.length > 0 ? a("unclosed_tag") : {
		ok: !0,
		doc: {
			plain: n,
			intervals: r
		}
	};
}
//#endregion
//#region src/domain/rich-plain-text/serialize.ts
function yt(e) {
	let t = x(e.text);
	return e.color && e.bold ? `<bgx-c v="${e.color}"><bgx-b>${t}</bgx-b></bgx-c>` : e.color ? `<bgx-c v="${e.color}">${t}</bgx-c>` : e.bold ? `<bgx-b>${t}</bgx-b>` : t;
}
function bt(e) {
	return pe(e).map(yt).join("");
}
function xt(e) {
	return S(pe(e));
}
function St(e) {
	return {
		plain: e.plain,
		intervals: e.intervals.map((e) => ({ ...e }))
	};
}
function P(e) {
	return {
		doc: St(e.doc),
		selection: {
			start: e.selection.start,
			end: e.selection.end
		}
	};
}
function Ct(e) {
	return {
		past: [],
		present: P(e),
		future: [],
		lastInputAt: null
	};
}
function wt(e, t) {
	if (e.plain !== t.plain || e.intervals.length !== t.intervals.length) return !1;
	for (let n = 0; n < e.intervals.length; n++) {
		let r = e.intervals[n], i = t.intervals[n];
		if (!r || !i || r.start !== i.start || r.end !== i.end || r.bold !== i.bold || r.color !== i.color) return !1;
	}
	return !0;
}
function F(e) {
	return e.length <= 100 ? e : e.slice(e.length - 100);
}
function Tt(e, t, n, r) {
	return wt(e.present.doc, t.doc) ? {
		...e,
		present: P(t)
	} : n === "input" && e.lastInputAt != null && r - e.lastInputAt <= 400 ? {
		past: e.past,
		present: P(t),
		future: [],
		lastInputAt: r
	} : {
		past: F([...e.past, P(e.present)]),
		present: P(t),
		future: [],
		lastInputAt: n === "input" ? r : null
	};
}
function Et(e) {
	if (e.past.length === 0) return {
		state: e,
		applied: null
	};
	let t = e.past[e.past.length - 1];
	return t ? {
		state: {
			past: e.past.slice(0, -1),
			present: P(t),
			future: [P(e.present), ...e.future],
			lastInputAt: null
		},
		applied: P(t)
	} : {
		state: e,
		applied: null
	};
}
function Dt(e) {
	if (e.future.length === 0) return {
		state: e,
		applied: null
	};
	let t = e.future[0];
	return t ? {
		state: {
			past: F([...e.past, P(e.present)]),
			present: P(t),
			future: e.future.slice(1),
			lastInputAt: null
		},
		applied: P(t)
	} : {
		state: e,
		applied: null
	};
}
function Ot(e) {
	return !(e.ctrlKey || e.metaKey) || e.altKey ? null : e.code === "KeyZ" && e.shiftKey ? "redo" : e.code === "KeyZ" ? "undo" : e.code === "KeyY" && !e.shiftKey ? "redo" : e.code === "KeyA" && !e.shiftKey ? "selectAll" : null;
}
//#endregion
//#region src/domain/overlay-placement/placeAnchoredFixedPanel.ts
function kt() {
	return typeof window > "u" ? {
		left: 0,
		top: 0,
		right: 800,
		bottom: 600
	} : {
		left: 0,
		top: 0,
		right: window.innerWidth,
		bottom: window.innerHeight
	};
}
function At(e) {
	return {
		left: e.left,
		top: e.top,
		right: e.right,
		bottom: e.bottom,
		width: e.width,
		height: e.height
	};
}
function jt(e, t, n) {
	return n < t ? t : Math.min(n, Math.max(t, e));
}
function Mt(e) {
	let t = e.margin ?? 8, n = e.gap ?? 4, r = e.maxHeightCap ?? 400, i = e.minHeightFloor ?? 120, { trigger: a, bounds: o } = e, s = Math.max(0, o.right - o.left - t * 2), c = Math.min(s, e.maxWidth, Math.max(a.width, e.minWidth)), l;
	e.horizontalAlign === "center" ? l = a.left + a.width / 2 - c / 2 : (l = a.left, l + c > o.right - t && (l = a.right - c)), l = jt(l, o.left + t, o.right - t - c);
	let u = o.bottom - a.bottom - t, d = a.top - o.top - t, f = e.preferBelowIfPx, p = (e, t) => e < f && t > e, m = e.preferOpenUp ? !p(d, u) : p(u, d), h = Math.max(i, o.bottom - o.top - t * 2), g = Math.min(r, h), _ = (m ? d : u) - n, v = Math.min(g, Math.max(i, _));
	v = Math.min(v, h);
	let y = m ? a.top - v - n : a.bottom + n;
	return y = jt(y, o.top + t, o.bottom - t - v), {
		top: y,
		left: l,
		width: c,
		maxHeight: v,
		openUp: m
	};
}
//#endregion
//#region src/components/modal/modalZIndex.ts
var I = {
	BASE: 10100,
	TEXTAREA_VERSION_HISTORY: 10100,
	TEXTAREA_WORKBENCH_OPEN_LOADING: 10101,
	WORKBENCH: 10002,
	VIDEO_GENERATION_WORKBENCH: 10030,
	DIALOGUE_AUDIO_WORKBENCH: 10032,
	FC_AUDIO_WORKBENCH: 10033,
	FC_IMAGE_WORKBENCH: 10033,
	FC_VIDEO_WORKBENCH: 10033,
	VIDEO_EDIT_CONTEXT_MENU: 10034,
	VIDEO_UPSCALE_WORKBENCH: 10033,
	VIDEO_FACE_REFINE_WORKBENCH: 10033,
	IMAGE_UPSCALE_WORKBENCH: 10033,
	FC_TEXT_SEGMENT: 10033,
	FC_TEXT_STORYBOARD: 10033,
	DIALOGUE_SEGMENT_MODE: 10034,
	FC_TEMPLATE_PROGRESS: 10040,
	TTS_REF_LIBRARY: 10050,
	TTS_REF_LIBRARY_PROGRESS: 10051,
	AUDIO_EDIT_WORKBENCH: 10052,
	SINGING_RELYRICS_WORKBENCH: 10052,
	MEDIA_CONCAT_WORKBENCH: 10052,
	TTS_REF_LIBRARY_ENROLL: 10053,
	VIDEO_WORKBENCH_SESSION_HISTORY: 10035,
	VIDEO_PLAYER: 10025,
	PAD_PICKER: 10050,
	LIGHTBOX: 10100,
	IMAGE_METADATA: 10200,
	MODEL_PICKER_DROPDOWN: 10250,
	CONTENT_SKILL_LISTBOX: 10260,
	SHORTCUT_HOVER_TIP: 10300,
	COPY_MENU: 10150,
	RICH_PLAIN_FORMAT_BUBBLE: 10140,
	PROMO_NOTICE: 10080,
	SIDEBAR_FLOATING: 10900,
	APP_UPDATE_MANDATORY_GATE: 100001
};
I.VIDEO_PLAYER, I.VIDEO_GENERATION_WORKBENCH, I.VIDEO_WORKBENCH_SESSION_HISTORY, I.VIDEO_GENERATION_WORKBENCH, I.AUDIO_EDIT_WORKBENCH, I.FC_AUDIO_WORKBENCH, I.AUDIO_EDIT_WORKBENCH, I.DIALOGUE_AUDIO_WORKBENCH, I.TTS_REF_LIBRARY, I.FC_AUDIO_WORKBENCH, I.TTS_REF_LIBRARY_PROGRESS, I.TTS_REF_LIBRARY, I.AUDIO_EDIT_WORKBENCH, I.TTS_REF_LIBRARY_PROGRESS, I.TTS_REF_LIBRARY_ENROLL, I.TTS_REF_LIBRARY, I.TEXTAREA_VERSION_HISTORY, I.TEXTAREA_VERSION_HISTORY, I.VIDEO_GENERATION_WORKBENCH, I.SHORTCUT_HOVER_TIP, I.TEXTAREA_VERSION_HISTORY, I.PROMO_NOTICE, I.BASE, I.PROMO_NOTICE, I.APP_UPDATE_MANDATORY_GATE, I.RICH_PLAIN_FORMAT_BUBBLE, I.TEXTAREA_VERSION_HISTORY, I.RICH_PLAIN_FORMAT_BUBBLE, I.LIGHTBOX, I.RICH_PLAIN_FORMAT_BUBBLE, I.FC_TEMPLATE_PROGRESS, I.RICH_PLAIN_FORMAT_BUBBLE, I.RICH_PLAIN_FORMAT_BUBBLE, I.COPY_MENU, I.RICH_PLAIN_FORMAT_BUBBLE, I.SHORTCUT_HOVER_TIP, I.SIDEBAR_FLOATING, I.SIDEBAR_FLOATING, I.MODEL_PICKER_DROPDOWN, I.BASE, I.MODEL_PICKER_DROPDOWN, I.LIGHTBOX, I.MODEL_PICKER_DROPDOWN, I.IMAGE_METADATA, I.MODEL_PICKER_DROPDOWN, I.MODEL_PICKER_DROPDOWN, I.CONTENT_SKILL_LISTBOX, I.IMAGE_METADATA, I.CONTENT_SKILL_LISTBOX, I.SHORTCUT_HOVER_TIP;
//#endregion
//#region src/theme/typographyScale.ts
var L = {
	text2xs: "var(--text-2xs)",
	textXs: "var(--text-xs)",
	textSm: "var(--text-sm)",
	textMd: "var(--text-md)",
	textLg: "var(--text-lg)",
	textXl: "var(--text-xl)",
	text2xl: "var(--text-2xl)",
	text3xl: "var(--text-3xl)",
	caption: { fontSize: "var(--text-xs)" }
};
//#endregion
//#region src/components/common/button/btnShortcutPort.ts
function Nt(e) {
	return null;
}
var R = null;
function Pt(e) {
	return (R ?? Nt)(e);
}
function Ft(e) {
	let { hostRef: t, label: n, open: i, onDismiss: a } = e, [s, c] = l(i), [u, f] = l(!1), [m, h] = l(null);
	return o(() => {
		if (!i) return;
		let e = t.current;
		if (!e) return;
		let n = e.getBoundingClientRect();
		h({
			left: n.left + n.width / 2,
			top: n.top
		});
	}, [
		i,
		t,
		n
	]), r(() => {
		if (i) {
			c(!0);
			let e = window.requestAnimationFrame(() => f(!0));
			return () => window.cancelAnimationFrame(e);
		}
		f(!1);
		let e = window.setTimeout(() => c(!1), 140);
		return () => window.clearTimeout(e);
	}, [i]), r(() => {
		if (!i) return;
		let e = () => a();
		return window.addEventListener("scroll", e, !0), window.addEventListener("resize", e), () => {
			window.removeEventListener("scroll", e, !0), window.removeEventListener("resize", e);
		};
	}, [i, a]), !s || !m || typeof document > "u" ? null : p(/* @__PURE__ */ d("span", {
		role: "tooltip",
		"aria-hidden": !0,
		style: {
			position: "fixed",
			left: m.left,
			top: m.top,
			transform: "translate(-50%, calc(-100% - 6px))",
			opacity: u ? 1 : 0,
			transition: "opacity 140ms ease-out",
			pointerEvents: "none",
			zIndex: I.SHORTCUT_HOVER_TIP,
			padding: "4px 8px",
			borderRadius: "var(--radius)",
			border: "1px solid var(--border)",
			background: "var(--surface)",
			color: "var(--text1)",
			fontSize: L.textSm,
			fontWeight: 500,
			whiteSpace: "nowrap",
			boxShadow: "var(--shadow-md)"
		},
		children: n
	}), t.current?.closest("dialog[open]") ?? document.body);
}
//#endregion
//#region src/components/common/button/Btn.tsx
var z = {
	primary: {
		background: "var(--primary)",
		color: "var(--primary-fg)",
		fontWeight: 600,
		boxShadow: "0 1px 4px var(--primary-glow)"
	},
	secondary: {
		background: "var(--surface3)",
		color: "var(--text2)",
		border: "1px solid var(--border)",
		boxShadow: "0 1px 3px rgba(0,0,0,0.25)"
	},
	danger: {
		background: "var(--danger-bg)",
		color: "var(--danger)",
		border: "1px solid rgba(239,68,68,0.25)"
	},
	ghost: {
		background: "transparent",
		color: "var(--text3)"
	},
	accent: {
		background: "var(--accent-soft)",
		color: "var(--accent)",
		border: "1px solid rgba(245,158,11,0.3)"
	},
	ai: {
		background: "var(--ai)",
		color: "var(--ai-fg)",
		fontWeight: 600,
		boxShadow: "0 1px 4px var(--ai-glow)"
	}
}, It = e(function({ onClick: e, children: t, variant: n = "primary", size: r, disabled: i, style: a, nativeTitle: o, ariaBusy: s, onPointerDown: c, type: l = "button", "aria-label": u, "aria-pressed": f, "aria-expanded": p, "aria-haspopup": m, "aria-selected": h, "data-testid": g, role: _, tabIndex: v, "aria-keyshortcuts": y }, b) {
	return /* @__PURE__ */ d("button", {
		ref: b,
		type: l,
		"data-ui-btn-variant": n,
		onClick: e,
		onPointerDown: c,
		disabled: i,
		title: o,
		"aria-label": u,
		"aria-pressed": f,
		"aria-expanded": p,
		"aria-haspopup": m,
		"aria-selected": h,
		"data-testid": g,
		role: _,
		tabIndex: v,
		"aria-keyshortcuts": y,
		"aria-busy": s === !0 ? !0 : void 0,
		style: {
			padding: r === "compact" ? "2px 6px" : "5px 12px",
			flexShrink: r === "compact" ? 0 : void 0,
			borderRadius: "var(--radius)",
			fontSize: L.textSm,
			fontWeight: 500,
			whiteSpace: "nowrap",
			opacity: i ? .5 : 1,
			cursor: i ? "not-allowed" : "pointer",
			...z[n],
			...a
		},
		children: t
	});
});
function Lt(e) {
	let { shortcutActionId: t, shortcutLabel: r, forwardedRef: i, title: a, ...o } = e, s = Pt(t), u = r ?? s, p = c(null), [m, h] = l(!1), [g, _] = l(!1), v = n(() => {
		h(!1), _(!1);
	}, []);
	return /* @__PURE__ */ f("span", {
		ref: p,
		style: {
			display: "inline-flex",
			verticalAlign: "middle"
		},
		onMouseEnter: () => h(!0),
		onMouseLeave: () => h(!1),
		onFocus: () => _(!0),
		onBlur: () => _(!1),
		children: [/* @__PURE__ */ d(It, {
			ref: i,
			...o,
			nativeTitle: u ? void 0 : a
		}), u ? /* @__PURE__ */ d(Ft, {
			hostRef: p,
			label: u,
			open: m || g,
			onDismiss: v
		}) : null]
	});
}
var B = e(function(e, t) {
	let { shortcutActionId: n, title: r, ...i } = e;
	return !n && !i.shortcutLabel ? /* @__PURE__ */ d(It, {
		ref: t,
		...i,
		nativeTitle: r
	}) : /* @__PURE__ */ d(Lt, {
		...i,
		title: r,
		shortcutActionId: n,
		forwardedRef: t
	});
}), Rt = {
	fontSize: L.textSm,
	fontWeight: 600,
	color: "var(--text1)",
	lineHeight: "16px"
};
//#endregion
//#region src/components/common/form/choiceStyles.ts
function zt(e, t) {
	return t != null && t !== !1 && t !== "" ? !0 : e == null || e === !1 ? !1 : typeof e == "string" ? e.length > 0 : !0;
}
var Bt = {
	flexShrink: 0,
	width: 16,
	height: 16,
	marginTop: 3,
	boxSizing: "border-box",
	borderRadius: 3,
	border: "1px solid var(--border)",
	background: "var(--surface2)",
	display: "flex",
	alignItems: "center",
	justifyContent: "center",
	pointerEvents: "none"
}, Vt = {
	fontSize: L.textXs,
	lineHeight: 1,
	color: "#fff",
	fontWeight: 700
}, Ht = {
	display: "flex",
	alignItems: "flex-start",
	gap: 8,
	fontSize: L.textSm,
	color: "var(--text1)",
	lineHeight: 1.5,
	userSelect: "none"
};
({ ...Rt });
var Ut = {
	fontSize: L.textSm,
	color: "var(--text2)",
	lineHeight: 1.45
}, Wt = "ui-choice-capsule", Gt = "ui-choice-capsule__mark", Kt = "ui-choice-capsule__text", V = "ui-choice-capsule__hint";
//#endregion
//#region src/components/common/form/ChoiceCapsuleBody.tsx
function qt(e) {
	let t = zt(e.label, e.hint);
	return /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("span", {
		"aria-hidden": !0,
		className: `${Gt} ${Gt}--${e.kind}`,
		children: e.kind === "checkbox" && e.checked ? "✓" : null
	}), t ? /* @__PURE__ */ f("span", {
		className: Kt,
		children: [/* @__PURE__ */ d("span", { children: e.label }), e.hint ? /* @__PURE__ */ d("span", {
			className: V,
			children: e.hint
		}) : null]
	}) : null] });
}
//#endregion
//#region src/components/common/form/UiCheckbox.tsx
var H = t(function(e) {
	let { checked: t, onChange: r, disabled: i = !1, dimmed: a = !1, label: o, ariaLabel: s, hint: c, title: l, id: u, appearance: f = "plain", testId: p } = e, m = zt(o, c), h = n(() => {
		i || r(!t);
	}, [
		t,
		i,
		r
	]), g = n((e) => {
		i || (e.key === " " || e.key === "Enter") && (e.preventDefault(), r(!t));
	}, [
		t,
		i,
		r
	]), _ = f === "capsule";
	return /* @__PURE__ */ d("div", {
		id: u,
		role: "checkbox",
		"aria-label": s,
		"aria-checked": t,
		"aria-disabled": i,
		title: l,
		tabIndex: i ? -1 : 0,
		"data-testid": p,
		"data-choice-appearance": f,
		className: _ ? Wt : void 0,
		onClick: h,
		onKeyDown: g,
		style: _ ? a ? { opacity: .55 } : void 0 : {
			...Ht,
			alignItems: m ? Ht.alignItems : "center",
			opacity: a ? .55 : 1,
			cursor: i ? "not-allowed" : "pointer"
		},
		children: _ ? /* @__PURE__ */ d(qt, {
			kind: "checkbox",
			checked: t,
			label: o,
			hint: c
		}) : /* @__PURE__ */ d(Jt, {
			checked: t,
			label: o,
			hint: c,
			showTextColumn: m
		})
	});
});
function Jt(e) {
	let { checked: t, label: n, hint: r, showTextColumn: i } = e;
	return /* @__PURE__ */ f(u, { children: [/* @__PURE__ */ d("span", {
		"aria-hidden": !0,
		style: {
			...Bt,
			marginTop: i ? Bt.marginTop : 0,
			borderColor: t ? "var(--primary)" : "var(--border)",
			background: t ? "var(--primary)" : "var(--surface2)"
		},
		children: t ? /* @__PURE__ */ d("span", {
			style: Vt,
			children: "✓"
		}) : null
	}), i ? /* @__PURE__ */ f("span", {
		style: {
			flex: 1,
			minWidth: 0
		},
		children: [/* @__PURE__ */ d("span", { children: n }), r ? /* @__PURE__ */ d("div", {
			style: {
				marginTop: 2,
				...Ut
			},
			children: r
		}) : null]
	}) : null] });
}
//#endregion
//#region src/components/common/form/CheckboxField.tsx
var Yt = t(function(e) {
	return /* @__PURE__ */ d(H, { ...e });
});
//#endregion
//#region src/domain/rich-plain-text/findReplace.ts
function Xt(e, t) {
	let n = [];
	if (!t) return n;
	let r = 0;
	for (; r <= e.length - t.length;) {
		let i = e.indexOf(t, r);
		if (i < 0) break;
		n.push({
			start: i,
			end: i + t.length
		}), r = i + t.length;
	}
	return n;
}
function Zt(e, t, n, r) {
	let i = Xt(e.plain, t);
	if (!i.length) return {
		doc: e,
		count: 0,
		selection: {
			start: 0,
			end: 0
		}
	};
	let a = pe(e), o = [], s = 0, c = 0, l = 0, u = (t, n) => {
		for (; l < t && s < a.length;) {
			let r = a[s];
			if (!r) break;
			let i = Math.min(t, c + r.text.length);
			n && o.push({
				...r,
				text: e.plain.slice(l, i)
			}), l = i, l === c + r.text.length && (c = l, s++);
		}
	};
	for (let e of i) {
		u(e.start, !0);
		let t = a[s];
		n && o.push({
			text: n,
			bold: t?.bold ?? !1,
			color: r ?? t?.color ?? null
		}), u(e.end, !1);
	}
	return u(e.plain.length, !0), {
		doc: C(o),
		count: i.length,
		selection: {
			start: i[0]?.start ?? 0,
			end: (i[0]?.start ?? 0) + (i.length ? n.length : 0)
		}
	};
}
//#endregion
//#region src/components/rich-plain-editor/FindReplacePanel.tsx
function Qt(e) {
	let { onPreview: t } = e, [n, i] = l(e.initialQuery), [a, o] = l(""), [s, u] = l("c2"), [p, m] = l(e.initialQuery ? {
		query: e.initialQuery,
		plain: e.plain
	} : null), [h, g] = l(0), _ = c(null), v = c(null), y = p?.query === n && p?.plain === e.plain, b = y ? Xt(e.plain, n) : [], ee = b.map((e) => `${e.start}:${e.end}`).join(",");
	r(() => {
		(e.initialQuery ? v : _).current?.focus();
	}, [e.initialQuery]), r(() => {
		t(y ? Xt(e.plain, n) : [], h);
	}, [
		ee,
		h,
		y,
		e.plain,
		n,
		t
	]);
	let te = () => {
		m({
			query: n,
			plain: e.plain
		}), g(0);
	}, ne = {
		minWidth: 0,
		width: "100%",
		background: "var(--surface)",
		color: "var(--text)",
		border: "1px solid var(--border)",
		borderRadius: 4,
		padding: "6px 8px"
	};
	return /* @__PURE__ */ f("div", {
		style: {
			borderTop: "1px solid var(--border)",
			marginTop: 6,
			paddingTop: 10,
			display: "grid",
			gap: 10
		},
		onMouseDown: (e) => {
			e.target instanceof HTMLElement && e.target.closest("button") && e.preventDefault();
		},
		onKeyDown: (t) => {
			t.stopPropagation(), !(t.nativeEvent.isComposing || t.keyCode === 229) && (t.key === "Escape" && (t.preventDefault(), e.onCancel()), t.key === "Enter" && t.target === _.current && (t.preventDefault(), te()));
		},
		children: [
			/* @__PURE__ */ f("div", {
				style: {
					display: "flex",
					alignItems: "center",
					gap: 8
				},
				children: [
					/* @__PURE__ */ f("label", {
						style: {
							display: "flex",
							alignItems: "center",
							gap: 8,
							flex: 1
						},
						children: [/* @__PURE__ */ d("span", {
							style: {
								whiteSpace: "nowrap",
								minWidth: "3em"
							},
							children: "查找"
						}), /* @__PURE__ */ d("input", {
							ref: _,
							"aria-label": "查找内容",
							value: n,
							placeholder: "输入查找内容",
							style: ne,
							onChange: (e) => {
								i(e.target.value), m(null);
							}
						})]
					}),
					/* @__PURE__ */ d(B, {
						variant: "ghost",
						title: "清空查找",
						"aria-label": "清空查找",
						onClick: () => {
							i(""), m(null), _.current?.focus();
						},
						children: "×"
					}),
					/* @__PURE__ */ d(B, {
						variant: "ghost",
						disabled: !n,
						onClick: te,
						children: "查找"
					})
				]
			}),
			/* @__PURE__ */ f("label", {
				style: {
					display: "flex",
					alignItems: "center",
					gap: 8
				},
				children: [/* @__PURE__ */ d("span", {
					style: {
						whiteSpace: "nowrap",
						minWidth: "3em"
					},
					children: "替换为"
				}), /* @__PURE__ */ d("input", {
					ref: v,
					"aria-label": "替换为",
					placeholder: "输入替换内容（留空则删除）",
					value: a,
					style: ne,
					onChange: (e) => o(e.target.value)
				})]
			}),
			/* @__PURE__ */ f("div", {
				style: {
					display: "flex",
					alignItems: "center",
					gap: 8
				},
				children: [
					/* @__PURE__ */ d("span", {
						role: "status",
						"aria-live": "polite",
						style: { flex: 1 },
						children: y ? `找到 ${b.length} 处${b.length ? ` · 当前 ${h + 1}/${b.length}` : ""}` : p ? "正文已变化，请重新查找" : "输入关键词后点击查找"
					}),
					/* @__PURE__ */ d(B, {
						variant: "ghost",
						"aria-label": "上一个匹配",
						disabled: !b.length,
						onClick: () => g((h + b.length - 1) % b.length),
						children: "‹"
					}),
					/* @__PURE__ */ d(B, {
						variant: "ghost",
						"aria-label": "下一个匹配",
						disabled: !b.length,
						onClick: () => g((h + 1) % b.length),
						children: "›"
					})
				]
			}),
			/* @__PURE__ */ f("div", {
				style: {
					display: "flex",
					alignItems: "center",
					gap: 6,
					flexWrap: "wrap"
				},
				children: [
					/* @__PURE__ */ d("span", { children: "替换后文字颜色" }),
					Te.map((e) => /* @__PURE__ */ d("button", {
						type: "button",
						"aria-label": `替换颜色 ${e}`,
						"aria-pressed": s === e,
						onClick: () => u(e),
						style: {
							width: 22,
							height: 22,
							borderRadius: "50%",
							background: `var(--rich-mark-${e})`,
							border: s === e ? "2px solid var(--text)" : "2px solid transparent"
						}
					}, e)),
					/* @__PURE__ */ d(Yt, {
						label: "保留原色",
						checked: s === null,
						onChange: (e) => u(e ? null : "c2")
					})
				]
			}),
			/* @__PURE__ */ f("div", {
				style: {
					display: "flex",
					alignItems: "center",
					gap: 8,
					flexWrap: "wrap"
				},
				children: [
					/* @__PURE__ */ d("small", {
						style: { flex: 1 },
						children: "范围：当前文本框全文"
					}),
					/* @__PURE__ */ d(B, {
						variant: "ghost",
						onClick: e.onCancel,
						children: "取消"
					}),
					/* @__PURE__ */ d(B, {
						disabled: !y || !b.length,
						onClick: () => e.onReplace(n, a, s, p?.plain ?? e.plain),
						children: a ? `确定替换全部（${b.length}处）` : `确定删除匹配文本（${b.length}处）`
					})
				]
			})
		]
	});
}
//#endregion
//#region src/components/rich-plain-editor/FindReplacePreview.tsx
function $t({ root: e, matches: t, active: n }) {
	let [r, i] = l([]);
	return o(() => {
		if (!e) return;
		let r = () => {
			let r = e.getBoundingClientRect();
			i(t.flatMap((t, i) => Array.from(Me(e, t.start, t.end)?.getClientRects() ?? []).flatMap((e) => {
				let t = Math.max(e.left, r.left, 0), a = Math.max(e.top, r.top, 0), o = Math.min(e.right, r.right, window.innerWidth), s = Math.min(e.bottom, r.bottom, window.innerHeight);
				return o > t && s > a ? [{
					x: t,
					y: a,
					w: o - t,
					h: s - a,
					active: i === n
				}] : [];
			})));
		}, a = t[n];
		if (a) {
			let t = Me(e, a.start, a.end)?.getBoundingClientRect(), n = e.getBoundingClientRect();
			t && (t.top < n.top || t.bottom > n.bottom) && e.scrollBy({ top: t.top - n.top - n.height / 2 });
		}
		r();
		let o = new MutationObserver(r);
		return o.observe(e, {
			subtree: !0,
			childList: !0,
			characterData: !0
		}), window.addEventListener("scroll", r, !0), window.addEventListener("resize", r), () => {
			o.disconnect(), window.removeEventListener("scroll", r, !0), window.removeEventListener("resize", r);
		};
	}, [
		e,
		t,
		n
	]), p(/* @__PURE__ */ d("div", {
		"aria-hidden": "true",
		style: {
			pointerEvents: "none",
			position: "fixed",
			inset: 0,
			zIndex: I.RICH_PLAIN_FORMAT_BUBBLE - 1
		},
		children: r.map((e, t) => /* @__PURE__ */ d("div", { style: {
			position: "absolute",
			left: e.x,
			top: e.y,
			width: e.w,
			height: e.h,
			background: "var(--rich-mark-c2)",
			opacity: e.active ? .38 : .18,
			outline: e.active ? "1px solid var(--rich-mark-c2)" : void 0
		} }, t))
	}), document.body);
}
function en(e) {
	return {
		viewBox: "0 0 24 24",
		width: e,
		height: e,
		fill: "none",
		stroke: "currentColor",
		strokeWidth: 2,
		strokeLinecap: "round",
		strokeLinejoin: "round",
		"aria-hidden": !0
	};
}
function U({ size: e = 14 }) {
	return /* @__PURE__ */ f("svg", {
		...en(e),
		children: [/* @__PURE__ */ d("rect", {
			x: "9",
			y: "9",
			width: "13",
			height: "13",
			rx: "2"
		}), /* @__PURE__ */ d("path", { d: "M5 15H4a2 2 0 01-2-2V4a2 2 0 012-2h9a2 2 0 012 2v1" })]
	});
}
function tn({ size: e = 14 }) {
	return /* @__PURE__ */ f("svg", {
		...en(e),
		children: [
			/* @__PURE__ */ d("circle", {
				cx: "6",
				cy: "6",
				r: "3"
			}),
			/* @__PURE__ */ d("circle", {
				cx: "6",
				cy: "18",
				r: "3"
			}),
			/* @__PURE__ */ d("path", { d: "M20 4L8.12 15.88M14.47 14.48L20 20M8.12 8.12L12 12" })
		]
	});
}
//#endregion
//#region src/components/rich-plain-editor/FormatMarksBar.tsx
function nn(e) {
	let { disabled: t, layout: n = "bubble", onBold: r, onColor: i, onClear: a, onCut: o, onCopy: s, onFindReplace: c } = e, l = n === "toolbar";
	return /* @__PURE__ */ f("div", {
		style: {
			display: "flex",
			gap: l ? 4 : 8,
			justifyContent: l ? "flex-start" : "center",
			flexWrap: "nowrap",
			alignItems: "center",
			flexShrink: 0
		},
		onMouseDown: (e) => e.preventDefault(),
		children: [
			o ? /* @__PURE__ */ d(B, {
				variant: "ghost",
				disabled: t,
				onClick: o,
				title: "剪切",
				"aria-label": "剪切",
				children: /* @__PURE__ */ d(tn, {})
			}) : null,
			s ? /* @__PURE__ */ d(B, {
				variant: "ghost",
				disabled: t,
				onClick: s,
				title: "复制",
				"aria-label": "复制",
				children: /* @__PURE__ */ d(U, {})
			}) : null,
			/* @__PURE__ */ d(B, {
				variant: "ghost",
				disabled: t,
				onClick: r,
				title: "加粗",
				"aria-label": "加粗",
				children: /* @__PURE__ */ d("span", {
					style: {
						fontWeight: 700,
						fontSize: L.textSm
					},
					children: "B"
				})
			}),
			Te.map((e) => /* @__PURE__ */ d(B, {
				variant: "ghost",
				disabled: t,
				onClick: () => i(e),
				title: `颜色 ${e}`,
				"aria-label": `颜色 ${e}`,
				style: { padding: l ? "2px 4px" : "4px 6px" },
				children: /* @__PURE__ */ d("span", { style: {
					display: "inline-block",
					width: 12,
					height: 12,
					borderRadius: "50%",
					background: `var(--rich-mark-${e})`,
					boxShadow: "0 0 0 1px var(--border)"
				} })
			}, e)),
			c ? /* @__PURE__ */ d(B, {
				variant: "ghost",
				disabled: t,
				onClick: c,
				title: "查找替换",
				"aria-label": "查找替换",
				children: "查找替换"
			}) : null,
			/* @__PURE__ */ d(B, {
				variant: "ghost",
				disabled: t,
				onClick: a,
				title: "清除样式",
				"aria-label": "清除样式",
				children: /* @__PURE__ */ d("span", {
					style: { fontSize: L.textSm },
					children: "清除"
				})
			})
		]
	});
}
//#endregion
//#region src/components/rich-plain-editor/restoreOffsets.ts
function rn(e, t) {
	return t === "keepRange" ? {
		start: e.start,
		end: e.end
	} : {
		start: e.end,
		end: e.end
	};
}
//#endregion
//#region src/components/rich-plain-editor/hostPorts.ts
var an = {
	shortcuts: { textareaWorkbench: {
		fontSizeIncrease: "增大字号",
		fontSizeDecrease: "缩小字号"
	} },
	common: {
		clipboardCopied: "已复制",
		clipboardCut: "已剪切",
		clipboardPasted: "已粘贴",
		clipboardCopyFailed: "复制失败",
		clipboardCutFailed: "剪切失败",
		clipboardPasteFailed: "粘贴失败",
		clipboardSelectFirst: "请先选择文本"
	}
};
function W() {
	return an;
}
function G() {
	return {
		registerHandler: () => void 0,
		unregisterHandler: () => void 0
	};
}
function K(e) {
	return {
		copied: e.common.clipboardCopied,
		cutDone: e.common.clipboardCut,
		pasted: e.common.clipboardPasted,
		copyFailed: e.common.clipboardCopyFailed,
		cutFailed: e.common.clipboardCutFailed,
		pasteFailed: e.common.clipboardPasteFailed,
		selectFirst: e.common.clipboardSelectFirst
	};
}
async function q(e) {
	if (typeof navigator < "u" && navigator.clipboard?.writeText) {
		await navigator.clipboard.writeText(e);
		return;
	}
	throw Error("clipboard unavailable");
}
function J(e) {
	let t = e;
	if (typeof t.value == "string" && typeof t.selectionStart == "number" && typeof t.selectionEnd == "number") {
		let e = t.selectionStart, n = t.selectionEnd;
		if (e !== n) {
			typeof t.setRangeText == "function" ? t.setRangeText("", e, n, "end") : (t.value = t.value.slice(0, e) + t.value.slice(n), typeof t.setSelectionRange == "function" && t.setSelectionRange(e, e)), t.dispatchEvent(new Event("input", { bubbles: !0 }));
			return;
		}
	}
	let n = typeof window < "u" ? window.getSelection() : null;
	n && n.rangeCount > 0 && !n.isCollapsed && n.getRangeAt(0).deleteContents();
}
function Y(e, t) {
	if (t.rangeOverride) {
		let n = Math.min(t.rangeOverride.start, t.rangeOverride.end), r = Math.max(t.rangeOverride.start, t.rangeOverride.end);
		return t.requireNonCollapsed && n === r ? "" : (e.innerText ?? e.textContent ?? "").slice(n, r);
	}
	return (typeof window < "u" ? window.getSelection()?.toString() ?? "" : "") || (e.innerText ?? e.textContent ?? "");
}
var X = {
	loadRichDocForPlain: async (e, t) => De(t),
	writeRichSource: async () => void 0,
	reportRichStyleSaveFailed: () => void 0,
	notifyToast: () => void 0,
	copyFormControl: async (e, t, n) => {
		let r = Y(e, n);
		if (!r) return t(n.speech.selectFirst, { variant: "info" }), !1;
		try {
			return await q(r), t(n.speech.copied, { variant: "success" }), !0;
		} catch {
			return t(n.speech.copyFailed, { variant: "error" }), !1;
		}
	},
	cutFormControl: async (e, t, n) => {
		let r = Y(e, n);
		if (!r) return t(n.speech.selectFirst, { variant: "info" }), !1;
		try {
			return await q(r), J(e), t(n.speech.cutDone, { variant: "success" }), !0;
		} catch {
			return t(n.speech.cutFailed, { variant: "error" }), !1;
		}
	},
	formClipboardSpeechFromLocale: K,
	useI18n: W,
	useShortcutHandlers: G,
	log: () => void 0,
	logError: () => void 0
}, on = null;
function sn(e) {
	return e ?? on ?? X;
}
//#endregion
//#region src/domain/rich-plain-text/editorTypographyPrefs.ts
var cn = "bgx.versionHistoryWorkbench.typography.v1", ln = "bgx.richPlainEditor.typography.v1", un = 1.4, dn = 2.4, fn = 1.8, pn = 1.5;
function mn(e, t, n) {
	return Math.min(n, Math.max(t, e));
}
function hn(e) {
	return {
		fontSizePx: mn(typeof e.fontSizePx == "number" ? e.fontSizePx : 14, 12, 88),
		lineHeight: mn(typeof e.lineHeight == "number" ? e.lineHeight : fn, un, dn)
	};
}
function gn(e) {
	return e === "chrome" ? ln : cn;
}
function _n(e) {
	return {
		fontSizePx: 14,
		lineHeight: e === "chrome" ? pn : fn
	};
}
function vn(e) {
	try {
		let t = localStorage.getItem(gn(e));
		return t ? hn(JSON.parse(t)) : null;
	} catch {
		return null;
	}
}
function yn(e, t) {
	try {
		localStorage.setItem(gn(e), JSON.stringify(hn(t)));
	} catch {}
}
var Z = {
	chrome: {
		hydrated: !1,
		value: null,
		listeners: /* @__PURE__ */ new Set()
	},
	workbench: {
		hydrated: !1,
		value: null,
		listeners: /* @__PURE__ */ new Set()
	}
};
function bn(e) {
	let t = Z[e];
	if (t.hydrated) return;
	t.hydrated = !0;
	let n = vn(e);
	t.value = e === "workbench" ? n ?? _n("workbench") : n;
}
function xn(e) {
	let t = Z[e];
	for (let e of t.listeners) e(t.value);
}
function Sn(e, t) {
	let n = Z[e];
	n.hydrated = !0, n.value = hn(t), yn(e, n.value), xn(e);
}
function Q(e = "workbench") {
	return bn(e), Z[e].value;
}
function Cn(e, t) {
	return bn(e), Z[e].listeners.add(t), () => {
		Z[e].listeners.delete(t);
	};
}
function wn(e, t = "workbench") {
	bn(t);
	let n = Z[t].value ?? _n(t);
	Sn(t, {
		...n,
		fontSizePx: n.fontSizePx + e
	});
}
function Tn(e, t = "workbench") {
	bn(t);
	let n = Z[t].value ?? _n(t), r = Math.round((n.lineHeight + e) * 10) / 10;
	Sn(t, {
		...n,
		lineHeight: r
	});
}
typeof window < "u" && window.addEventListener("storage", (e) => {
	e.key === "bgx.richPlainEditor.typography.v1" && (Z.chrome.hydrated = !0, Z.chrome.value = vn("chrome"), xn("chrome")), e.key === "bgx.versionHistoryWorkbench.typography.v1" && (Z.workbench.hydrated = !0, Z.workbench.value = vn("workbench") ?? _n("workbench"), xn("workbench"));
});
function En(e = "workbench") {
	let [t, n] = l(() => Q(e));
	return r(() => Cn(e, n), [e]), t;
}
//#endregion
//#region src/components/rich-plain-editor/RichPlainEditorCore.tsx
var Dn = 8, On = 8;
function kn(e) {
	let t = e.getBoundingClientRect();
	return t.width !== 0 || t.height !== 0 || t.left !== 0 || t.top !== 0 ? t : e.getClientRects()[0] ?? null;
}
function An(e) {
	let t = e.getBoundingClientRect(), n = window.getComputedStyle(e), r = t.left + (Number.parseFloat(n.paddingLeft) || 0), i = t.top + (Number.parseFloat(n.paddingTop) || 0), a = Number.parseFloat(n.lineHeight), o = Number.isFinite(a) && a > 0 ? a : 20;
	return {
		left: r,
		top: i,
		right: r,
		bottom: i + o,
		width: 0,
		height: o
	};
}
function jn(e, t) {
	if (!e) return null;
	let n = window.getSelection();
	if (n && n.rangeCount > 0) {
		let t = n.getRangeAt(0);
		if (e.contains(t.commonAncestorContainer) || t.commonAncestorContainer === e) {
			let e = kn(t);
			if (e) return At(e);
		}
	}
	let r = Me(e, t.start, t.end), i = r ? kn(r) : null;
	return i ? At(i) : An(e);
}
function Mn(e, t, n, r) {
	if (!e) return !0;
	if (!r) return !1;
	let i = r.getBoundingClientRect(), a = i.bottom - t.bottom - On, o = t.top - i.top - On;
	return a < n + Dn && o > a;
}
var $ = "RICH_PLAIN", Nn = 400, Pn = e(function(e, t) {
	let { value: m, onValueChange: h, onSourceChange: g, richOwner: _, hydrateSource: v, placeholder: y, disabled: b = !1, className: ee = "", style: te, spellCheck: ne = !1, showBubble: re = !0, id: ie, onFocus: ae, onBlur: oe, onKeyDown: se, onClick: x, onCompositionStart: fe, onCompositionEnd: pe, syntaxProfileId: S, pauseSyntaxRefresh: C = !1, citeImagePreviewByOrdinal: me, mediaRefPreviewById: he, mediaRefLabelById: ge, typographySurface: w = "chrome", host: _e } = e, T = sn(_e), { writeRichSource: ve, loadRichDocForPlain: ye, reportRichStyleSaveFailed: be, copyFormControl: xe, cutFormControl: Te } = T, E = T.log, D = T.logError, ke = T.notifyToast, Me = e["aria-label"], Ne = e["aria-describedby"], Fe = e["aria-invalid"], O = c(null), k = c(De(m)), Be = c(null), Ve = c(null), He = c(""), Ue = c(null), A = c(null), j = c(_);
	j.current = _;
	let We = c(g);
	We.current = g;
	let M = c(!1), Ge = c(!1), Ke = c(0), qe = c(""), N = c(null), Je = s(Ye, [ct(_)]), Xe = c(() => {}), Ze = c(S);
	Ze.current = S;
	let it = c(C);
	it.current = C;
	let { registerHandler: at, unregisterHandler: st } = T.useShortcutHandlers(), dt = T.useI18n(), mt = s(() => T.formClipboardSpeechFromLocale(dt), [dt, T]), ht = En(w), [gt, _t] = l(!1), [yt, St] = l(() => Qe()), P = c(yt);
	P.current = yt;
	let wt = i(), [F, jt] = l(null), [L, Nt] = l(null), { hover: R, target: Pt, show: Ft, close: z } = et(me, he, S, ct(_), C), It = c(!0), Lt = c(null), B = c(!1), [Rt, zt] = l(null), Bt = (() => {
		let e = Rt && R && Rt.url === R.url ? Rt : null, t = e && e.height > 0 ? e.width / e.height : 1;
		return {
			boxWidth: t >= 1 ? 240 : Math.max(80, Math.round(240 * t)),
			boxHeight: t >= 1 ? Math.max(80, Math.round(240 / t)) : 240
		};
	})(), Vt = c(me);
	Vt.current = me;
	let Ht = c(ge);
	Ht.current = ge;
	let Ut = c(he);
	Ut.current = he;
	let Wt = c(null), Gt = c(!1), Kt = c(null), V = c(null), qt = c(!1), [H, Jt] = l(null), [Yt, Xt] = l({
		matches: [],
		active: 0
	}), en = n((e, t) => Xt({
		matches: e,
		active: t
	}), []), U = n(() => {
		Jt(null), Xt({
			matches: [],
			active: 0
		}), V.current = null, jt(null), Nt(null);
	}, []), tn = c(Ct({
		doc: De(m),
		selection: {
			start: 0,
			end: 0
		}
	})), an = c(!1), W = ct(_), G = n((e) => {
		Ue.current !== null && (Ke.current += 1, Ue.current = null, He.current = ct(j.current)), k.current = e;
		let t = bt(e);
		Be.current = e.plain, Ve.current = t, h(e.plain), g?.(t, "edit"), ot(j.current);
	}, [g, h]), K = n((e, t, n) => {
		tn.current = Tt(tn.current, {
			doc: e,
			selection: n
		}, t, Date.now());
	}, []), q = n((e, t, n) => {
		let r = O.current;
		if (!r) return;
		let i = Ze.current, a = !!i && P.current;
		a && !n && Xe.current();
		let o = i ? ze(i) : void 0, s = Ce(e.plain), c = we(Ut.current), l = Ht.current ? `labels:${we(Ht.current)}` : "", u = `${bt(e)}\0${i ?? ""}\0${a ? "1" : "0"}\0${o?.version ?? 0}\0${c}\0${l}\0${s.map((e) => `${e.start}:${e.end}:${e.referenceId}`).join(",")}` + (n ? ":decorated" : ":plain");
		if (qe.current === u) {
			E($, "writeHtml_skip_unchanged", { ownerKey: ct(j.current) || null }), It.current = !0, t && je(r, t.start, t.end);
			return;
		}
		qe.current = u;
		let d = a && n && tt(e.plain, e.intervals.length > 0, s.length > 0);
		Lt.current?.clear(), Lt.current = null;
		let f = Se(e, {
			chunkLongPlainRuns: !!i,
			decoSpans: a && !d ? n : void 0,
			mediaRefSpans: s,
			mediaRefPreviewById: Ut.current,
			mediaRefLabelById: Ht.current
		}), { scrollLeft: p, scrollTop: m } = r;
		n ? rt(r, f) : r.innerHTML = f, d && (Lt.current = nt(r, n)), It.current = !0, Pt.current && !r.contains(Pt.current.element) && z(), t && je(r, t.start, t.end), r.scrollLeft = p, r.scrollTop = m;
	}, [z, Pt]), J = n(() => {
		let e = O.current;
		if (!e) return k.current;
		let t = Oe(e);
		return k.current = t, t;
	}, []), Y = n(() => {
		let e = O.current, t = window.getSelection();
		if (!e || !t || t.rangeCount === 0) {
			let e = k.current.plain.length;
			return {
				start: e,
				end: e
			};
		}
		let n = t.getRangeAt(0);
		if (!e.contains(n.commonAncestorContainer) && n.commonAncestorContainer !== e) {
			let e = k.current.plain.length;
			return {
				start: e,
				end: e
			};
		}
		return Ae(e, n) ?? {
			start: 0,
			end: 0
		};
	}, []), X = n(() => {
		N.current !== null && window.clearTimeout(N.current), N.current = null;
		let e = Ze.current;
		if (!e || !P.current) return;
		let t = ze(e);
		if (!t) {
			sn().logError(Re, Ie, { profileId: e });
			return;
		}
		let n, r, i = () => {
			if (N.current = null, !(!O.current || M.current || it.current || e !== Ze.current || !P.current) && !(r && r !== k.current)) {
				r = k.current, n ??= Je(r.plain, t);
				try {
					let e = performance.now() + 4, t = n.next();
					for (; !t.done && performance.now() < e;) t = n.next();
					if (t.done) {
						let e = Ge.current ? Y() : void 0;
						B.current = !!(e && e.start !== e.end), B.current || q(r, e, t.value);
					} else N.current = window.setTimeout(i, 0);
				} catch (t) {
					sn().logError(Re, Le, {
						profileId: e,
						error: t instanceof Error ? t.message : String(t)
					});
				}
			}
		};
		N.current = window.setTimeout(i, Nn);
	}, [
		Y,
		Je,
		q
	]);
	Xe.current = X, r(() => {
		let e = () => {
			!B.current || !Ge.current || !window.getSelection()?.isCollapsed || (B.current = !1, X());
		};
		return document.addEventListener("selectionchange", e), () => document.removeEventListener("selectionchange", e);
	}, [X]);
	let on = n((e, t) => {
		Ke.current += 1, Ue.current = null;
		let n = vt(e), r;
		n.ok && n.doc.plain === t ? r = n.doc : (E("RICH_PLAIN", "hydrate_mismatch", {
			ownerKey: ct(j.current) || null,
			incomingLen: e.length,
			valueLen: t.length,
			parseOk: n.ok,
			incomingPlainLen: n.ok ? n.doc.plain.length : 0,
			hadMarks: n.ok ? xt(n.doc) : !1,
			via: "hydrateFromSource"
		}), r = De(t)), k.current = r, Be.current = r.plain, Ve.current = bt(r), He.current = ct(j.current);
		let i = Y(), a = i.start !== i.end || i.start > 0 && i.start < r.plain.length ? i : void 0;
		q(r, a), We.current?.(Ve.current, "hydrate"), ot(j.current);
	}, [Y, q]), cn = n((e, t) => {
		if (b) return;
		let n = V.current, r;
		if (F != null) {
			if (!n || n.start === n.end) {
				ke(mt.selectFirst, { variant: "info" });
				return;
			}
			r = {
				start: Math.min(n.start, n.end),
				end: Math.max(n.start, n.end)
			};
		} else if (r = Y(), r.start === r.end) return;
		let i = e(J(), r.start, r.end), a = rn(r, t);
		q(i, a), t === "collapseToEnd" ? U() : V.current = a, K(i, "atomic", a), G(i);
		let o = j.current;
		o?.ownerId && o.fieldKey && ve(o, i.plain, bt(i)).catch((e) => {
			D($, Ee, {
				ownerKind: o.ownerKind,
				ownerId: o.ownerId,
				fieldKey: o.fieldKey,
				error: e instanceof Error ? e.message : String(e)
			}), be();
		});
	}, [
		F,
		U,
		Y,
		b,
		G,
		J,
		K,
		mt,
		q
	]), ln = n(() => cn(ce, "keepRange"), [cn]), un = n(() => {
		let e = O.current;
		if (!e) return;
		let t = V.current;
		if (!t || t.start === t.end) {
			ke(mt.selectFirst, { variant: "info" }), D($, "bubble_clip_cut", {
				textLen: 0,
				ok: !1
			});
			return;
		}
		let n = {
			start: Math.min(t.start, t.end),
			end: Math.max(t.start, t.end)
		}, r = n.end - n.start;
		J(), Promise.resolve(Te(e, ke, {
			speech: mt,
			rangeOverride: n,
			requireNonCollapsed: !0
		})).then((e) => {
			if (e) {
				E($, "bubble_clip_cut", { textLen: r }), U();
				return;
			}
			D($, "bubble_clip_cut", {
				textLen: r,
				ok: !1
			});
		});
	}, [
		U,
		J,
		mt
	]), dn = n(() => {
		let e = O.current;
		if (!e) return;
		let t = V.current;
		if (!t || t.start === t.end) {
			ke(mt.selectFirst, { variant: "info" }), D($, "bubble_clip_copy", {
				textLen: 0,
				ok: !1
			});
			return;
		}
		let n = {
			start: Math.min(t.start, t.end),
			end: Math.max(t.start, t.end)
		}, r = n.end - n.start;
		J(), Promise.resolve(xe(e, ke, {
			speech: mt,
			rangeOverride: n,
			requireNonCollapsed: !0
		})).then((e) => {
			if (e) {
				E($, "bubble_clip_copy", { textLen: r });
				return;
			}
			D($, "bubble_clip_copy", {
				textLen: r,
				ok: !1
			});
		});
	}, [J, mt]), fn = n((e) => cn((t, n, r) => le(t, n, r, e), "collapseToEnd"), [cn]), pn = n(() => cn(ue, "collapseToEnd"), [cn]), mn = n(() => {
		if (b || M.current) return;
		let e = J(), t = V.current ?? Y();
		Jt({
			query: e.plain.slice(t.start, t.end),
			selection: t
		}), jt(jn(O.current, t));
	}, [
		b,
		J,
		Y
	]), hn = n(() => {
		let e = H?.selection;
		U(), O.current?.focus(), e && O.current && je(O.current, e.start, e.end);
	}, [H, U]), gn = n((e, t, n, r) => {
		if (b || M.current) return;
		let i = J();
		if (i.plain !== r) {
			ke("正文已变化，请重新查找", { variant: "info" });
			return;
		}
		let a = Zt(i, e, t, n);
		if (!a.count) return;
		U(), O.current?.focus(), q(a.doc, a.selection), K(a.doc, "atomic", a.selection), G(a.doc);
		let o = j.current;
		o?.ownerId && o.fieldKey && ve(o, a.doc.plain, bt(a.doc)).catch((e) => {
			D($, Ee, { error: String(e) }), be();
		}), ke(`已替换 ${a.count} 处 · 可撤销`, { variant: "success" });
	}, [
		b,
		J,
		U,
		q,
		K,
		G
	]), _n = n((e, t, n) => {
		if (b && !n?.programmatic) return;
		let r = t ?? Y(), i = {
			start: Math.min(r.start, r.end),
			end: Math.max(r.start, r.end)
		}, a = de(J(), i.start, i.end, e), o = i.start + e.length;
		q(a, {
			start: o,
			end: o
		}), K(a, "atomic", {
			start: o,
			end: o
		}), G(a);
	}, [
		Y,
		b,
		G,
		J,
		K,
		q
	]), vn = n((e) => {
		an.current = !0;
		try {
			k.current = e.doc, q(e.doc, e.selection), G(e.doc);
		} finally {
			an.current = !1;
		}
	}, [G, q]), yn = n(() => {
		if (b) return;
		let { state: e, applied: t } = Et(tn.current);
		t && (tn.current = e, vn(t));
	}, [vn, b]), Z = n(() => {
		if (b) return;
		let { state: e, applied: t } = Dt(tn.current);
		t && (tn.current = e, vn(t));
	}, [vn, b]), bn = n(() => {
		let e = O.current;
		if (!e) return;
		let t = k.current.plain.length;
		je(e, 0, t);
	}, []), xn = n(() => {
		let e = {
			focus: () => O.current?.focus(),
			getSelection: Y,
			setSelection: (e, t) => {
				let n = O.current;
				n && je(n, e, t);
			},
			getPlain: () => k.current.plain,
			getSource: () => bt(k.current),
			hydrateFromSource: on,
			getRootElement: () => O.current,
			applyBold: ln,
			applyColor: fn,
			clearMarks: pn,
			replaceSelection: _n,
			offsetFromPoint: (e, t) => {
				let n = O.current;
				return n ? Pe(n, e, t, k.current.plain.length) : null;
			},
			undo: yn,
			redo: Z,
			selectAll: bn
		};
		return A.current = e, e;
	}, [
		_n,
		Y,
		ln,
		fn,
		pn,
		Z,
		bn,
		yn,
		on
	]);
	o(() => {
		xn();
	}, [xn]), a(t, xn, [xn]), r(() => {
		let e = O.current;
		if (e) return ft(e, {
			focus: () => A.current?.focus(),
			getSelection: () => A.current?.getSelection() ?? {
				start: 0,
				end: 0
			},
			setSelection: (e, t) => A.current?.setSelection(e, t),
			getPlain: () => k.current.plain,
			getSource: () => bt(k.current),
			hydrateFromSource: (e, t) => {
				let n = A.current;
				if (!n) {
					D($, "handle_api_missing", { op: "hydrateFromSource" });
					return;
				}
				n.hydrateFromSource(e, t);
			},
			getRootElement: () => O.current,
			applyBold: () => A.current?.applyBold(),
			applyColor: (e) => A.current?.applyColor(e),
			clearMarks: () => A.current?.clearMarks(),
			replaceSelection: (e, t, n) => {
				let r = A.current;
				if (!r) {
					D($, "handle_api_missing", { op: "replaceSelection" });
					return;
				}
				r.replaceSelection(e, t, n);
			},
			offsetFromPoint: (e, t) => A.current?.offsetFromPoint(e, t) ?? null,
			undo: () => {
				let e = A.current;
				if (!e) {
					D($, "handle_api_missing", { op: "undo" });
					return;
				}
				e.undo();
			},
			redo: () => {
				let e = A.current;
				if (!e) {
					D($, "handle_api_missing", { op: "redo" });
					return;
				}
				e.redo();
			},
			selectAll: () => {
				let e = A.current;
				if (!e) {
					D($, "handle_api_missing", { op: "selectAll" });
					return;
				}
				e.selectAll();
			}
		}), () => pt(e);
	}, []), r(() => {
		if (!W) {
			ut(wt);
			return;
		}
		let e = j.current;
		if (!e) {
			ut(wt);
			return;
		}
		return lt(wt, {
			owner: e,
			getPlain: () => k.current.plain,
			getSource: () => bt(k.current),
			hydrateFromSource: (e, t) => {
				A.current?.hydrateFromSource(e, t);
			}
		}), () => ut(wt);
	}, [wt, W]), o(() => {
		if (M.current) return;
		let e = v === void 0 ? void 0 : v ?? "", t = m === Be.current, n = e === void 0 || e === Ve.current, r = W === He.current;
		if (t && n && r && Be.current !== null) return;
		let i = `${W}\0${m}\0${e ?? ""}`;
		if (Ue.current === i) {
			E($, "hydrate_skip_inflight", {
				ownerKey: W || null,
				plainLen: m.length
			});
			return;
		}
		let a = ++Ke.current;
		Ue.current = i, E($, "hydrate_begin", {
			ownerKey: W || null,
			plainLen: m.length,
			via: e === void 0 ? W ? "ipc" : "empty" : "hydrateSource"
		});
		let o = (e) => {
			if (Ke.current !== a || M.current) return;
			Ue.current === i && (Ue.current = null), k.current = e, Be.current = e.plain, Ve.current = bt(e), He.current = W;
			let t = Y(), n = t.start !== t.end || t.start > 0 && t.start < e.plain.length ? t : void 0;
			E($, "hydrate_apply", {
				ownerKey: W || null,
				plainLen: e.plain.length,
				restore: !!n
			}), q(e, n), tn.current = Ct({
				doc: e,
				selection: n ?? {
					start: 0,
					end: 0
				}
			});
		};
		if (e !== void 0) {
			let t = vt(e);
			t.ok && t.doc.plain === m ? o(t.doc) : (E("RICH_PLAIN", "hydrate_mismatch", {
				ownerKey: W || null,
				incomingLen: e.length,
				valueLen: m.length,
				parseOk: t.ok,
				incomingPlainLen: t.ok ? t.doc.plain.length : 0,
				hadMarks: t.ok ? xt(t.doc) : !1
			}), o(De(m)));
			return;
		}
		let s = j.current;
		s && s.ownerId && W ? ye(s, m).then(o) : o(De(m));
	}, [
		m,
		W,
		v,
		q,
		Y
	]), r(() => {
		if (S) return St(Qe()), $e(() => {
			St(Qe());
		});
	}, [S]), o(() => {
		It.current = !1, !M.current && !C && (!yt || !S ? q(k.current, Ge.current ? Y() : void 0) : X());
	}, [
		S,
		yt,
		C,
		q,
		Y,
		X
	]);
	let Sn = n(() => {
		Gt.current = M.current;
		let e = O.current;
		if (!e || Gt.current) return;
		let { scrollLeft: t, scrollTop: n } = e, r = document.activeElement === e ? Y() : void 0, i = qe.current;
		q(k.current, r), e.scrollLeft = t, e.scrollTop = n, Wt.current && qe.current !== i && (Wt.current = null, z());
	}, [
		q,
		Y,
		z
	]);
	r(() => {
		Sn();
	}, [
		he,
		ge,
		Sn
	]), r(() => () => {
		Lt.current?.clear(), N.current != null && window.clearTimeout(N.current);
	}, []);
	let Q = c(!1), Cn = n(() => {
		if (!re || b || Q.current) {
			U();
			return;
		}
		if (H) return;
		let e = qt.current || !!(Kt.current && document.activeElement && Kt.current.contains(document.activeElement)), t = O.current, n = window.getSelection();
		if (!t || !n || n.rangeCount === 0 || n.isCollapsed) {
			if (e) return;
			U();
			return;
		}
		let r = n.getRangeAt(0);
		if (!t.contains(r.commonAncestorContainer) && r.commonAncestorContainer !== t) {
			if (e) return;
			U();
			return;
		}
		let i = r.getBoundingClientRect();
		if (!n.isCollapsed && i.width === 0 && i.height === 0) {
			if (e) return;
			U();
			return;
		}
		let a = Ae(t, r);
		if (!a) {
			if (e) return;
			U();
			return;
		}
		V.current = {
			start: Math.min(a.start, a.end),
			end: Math.max(a.start, a.end)
		}, Nt(null), jt(At(i.width || i.height ? i : t.getBoundingClientRect()));
	}, [
		U,
		b,
		re,
		H
	]), kn = n(() => {
		if (!F) {
			Nt(null);
			return;
		}
		let e = Kt.current;
		if (!e) return;
		let t = e.offsetWidth, n = e.offsetHeight;
		if (t <= 0 || n <= 0) {
			Nt(null);
			return;
		}
		let r = Mt({
			trigger: F,
			bounds: kt(),
			minWidth: t,
			maxWidth: t,
			preferBelowIfPx: n + Dn,
			preferOpenUp: Mn(H, F, n, O.current),
			horizontalAlign: "center",
			margin: On,
			gap: Dn,
			minHeightFloor: n,
			maxHeightCap: n
		});
		Nt({
			top: r.top,
			left: r.left
		});
	}, [F, H]);
	o(() => {
		if (!F) {
			Nt(null);
			return;
		}
		kn();
		let e = new ResizeObserver(kn);
		return Kt.current && e.observe(Kt.current), () => e.disconnect();
	}, [F, kn]), r(() => {
		let e = () => {
			requestAnimationFrame(() => {
				requestAnimationFrame(() => {
					qt.current = !1;
				});
			});
		};
		return window.addEventListener("pointerup", e), window.addEventListener("pointercancel", e), () => {
			window.removeEventListener("pointerup", e), window.removeEventListener("pointercancel", e);
		};
	}, []), r(() => {
		if (!F) return;
		let e = () => {
			H ? kn() : Cn();
		};
		return window.addEventListener("resize", e), window.addEventListener("scroll", e, !0), () => {
			window.removeEventListener("resize", e), window.removeEventListener("scroll", e, !0);
		};
	}, [
		F,
		Cn,
		H,
		kn
	]), r(() => {
		if (!re || b) {
			U();
			return;
		}
		let e = () => {
			if (Q.current) {
				U();
				return;
			}
			Cn();
		};
		return document.addEventListener("selectionchange", e), () => document.removeEventListener("selectionchange", e);
	}, [
		U,
		b,
		re,
		Cn
	]);
	let An = n((e) => {
		e.button === 0 && (Q.current = !1);
	}, []), Pn = n((e) => {
		if (e.button !== 0) {
			Q.current = !0, U();
			return;
		}
		Q.current = !1, requestAnimationFrame(() => {
			Q.current || Cn();
		});
	}, [U, Cn]), Fn = n(() => {
		Q.current = !0, U();
	}, [U]), In = n(() => {
		if (an.current || M.current || b) return;
		It.current = !1, qe.current = "", z();
		let e = J();
		K(e, "input", Y()), G(e), Q.current || Cn(), X();
	}, [
		Y,
		b,
		G,
		J,
		K,
		Cn,
		X,
		z
	]), Ln = n((e) => {
		if (b) {
			e.preventDefault();
			return;
		}
		let t = e.nativeEvent;
		if (t.inputType === "insertParagraph" || t.inputType === "insertLineBreak") {
			e.preventDefault();
			let t = Y(), n = de(J(), t.start, t.end, "\n"), r = t.start + 1;
			q(n, {
				start: r,
				end: r
			}), K(n, "atomic", {
				start: r,
				end: r
			}), G(n);
		}
	}, [
		Y,
		b,
		G,
		J,
		K,
		q
	]), Rn = n((e) => {
		if (e.preventDefault(), b) return;
		let t = e.clipboardData.getData("text/plain"), n = Y(), r = de(J(), n.start, n.end, t), i = n.start + t.length;
		q(r, {
			start: i,
			end: i
		}), K(r, "atomic", {
			start: i,
			end: i
		}), G(r);
	}, [
		Y,
		b,
		G,
		J,
		K,
		q
	]), zn = n((e, t) => {
		e.preventDefault();
		let n = Y(), r = k.current.plain.slice(n.start, n.end);
		if (e.clipboardData.setData("text/plain", r), t && !b) {
			let e = de(J(), n.start, n.end, "");
			q(e, {
				start: n.start,
				end: n.start
			}), K(e, "atomic", {
				start: n.start,
				end: n.start
			}), G(e);
		}
	}, [
		Y,
		b,
		G,
		J,
		K,
		q
	]), Bn = n((e) => {
		if (e.nativeEvent.isComposing || e.keyCode === 229 || M.current) {
			se?.(e);
			return;
		}
		if ((e.ctrlKey || e.metaKey) && e.key.toLowerCase() === "h") {
			e.preventDefault(), e.stopPropagation(), mn();
			return;
		}
		let t = Ot(e);
		if (t) {
			e.preventDefault(), e.stopPropagation(), t === "undo" ? yn() : t === "redo" ? Z() : bn();
			return;
		}
		if ((e.ctrlKey || e.metaKey) && (e.key === "b" || e.key === "B")) {
			e.preventDefault(), e.stopPropagation(), ln();
			return;
		}
		se?.(e);
	}, [
		ln,
		Z,
		bn,
		yn,
		se,
		mn
	]);
	r(() => {
		if (!gt || b) return;
		let e = [
			at("textareaWorkbench.fontSizeIncrease", () => wn(1, w)),
			at("textareaWorkbench.fontSizeDecrease", () => wn(-1, w)),
			at("textareaWorkbench.lineHeightIncrease", () => Tn(.1, w)),
			at("textareaWorkbench.lineHeightDecrease", () => Tn(-.1, w))
		];
		return () => {
			st("textareaWorkbench.fontSizeIncrease", e[0]), st("textareaWorkbench.fontSizeDecrease", e[1]), st("textareaWorkbench.lineHeightIncrease", e[2]), st("textareaWorkbench.lineHeightDecrease", e[3]);
		};
	}, [
		gt,
		b,
		at,
		st,
		w
	]), r(() => {
		U();
	}, [W, U]), r(() => {
		if (!H) return;
		let e = (e) => {
			e.target instanceof Node && !Kt.current?.contains(e.target) && U();
		};
		return document.addEventListener("pointerdown", e), () => document.removeEventListener("pointerdown", e);
	}, [H, U]);
	let Vn = ["ui-edit-textarea", ee].filter(Boolean).join(" "), Hn = k.current.plain.length === 0 && m.length === 0, Un = ht ? {
		fontSize: ht.fontSizePx,
		lineHeight: ht.lineHeight
	} : void 0;
	return /* @__PURE__ */ f(u, { children: [
		/* @__PURE__ */ d("div", {
			ref: O,
			id: ie,
			className: Vn,
			style: {
				whiteSpace: "pre-wrap",
				...te,
				...Un
			},
			contentEditable: !b,
			suppressContentEditableWarning: !0,
			"data-canvas-ui": !0,
			"data-canvas-ui-scroll": "true",
			"data-rich-plain": "1",
			"data-placeholder": Hn ? y ?? "" : "",
			spellCheck: ne,
			onInput: In,
			onBeforeInput: Ln,
			onPaste: Rn,
			onCopy: (e) => zn(e, !1),
			onCut: (e) => zn(e, !0),
			onCompositionStart: () => {
				M.current = !0, z(), N.current !== null && window.clearTimeout(N.current), N.current = null, fe?.();
			},
			onCompositionEnd: () => {
				M.current = !1, pe?.(), In(), Gt.current && Sn(), P.current || q(k.current, Y());
			},
			onKeyDown: Bn,
			onKeyUp: () => {
				Q.current = !1, Cn();
			},
			onMouseDown: An,
			onMouseUp: Pn,
			onMouseMove: (e) => {
				if (it.current || M.current) {
					Wt.current &&= (O.current?.querySelectorAll("[data-media-ref-hover='1']").forEach((e) => {
						e.style.outline = "", e.style.outlineOffset = "", e.removeAttribute("data-media-ref-hover");
					}), null), z();
					return;
				}
				let t = e.target?.closest?.("[data-media-ref-id]");
				if (t instanceof HTMLElement && O.current?.contains(t)) {
					let e = (t.getAttribute("data-media-ref-id") ?? "").trim(), n = (Ut.current?.[e] ?? "").trim();
					if (e && Wt.current !== e && (O.current.querySelectorAll("[data-media-ref-hover='1']").forEach((e) => {
						e.style.outline = "", e.style.outlineOffset = "", e.removeAttribute("data-media-ref-hover");
					}), t.setAttribute("data-media-ref-hover", "1"), t.style.outline = "2px solid var(--accent)", t.style.outlineOffset = "1px", Wt.current = e), n) {
						Ft(t, n);
						return;
					}
				} else Wt.current &&= (O.current?.querySelectorAll("[data-media-ref-hover='1']").forEach((e) => {
					e.style.outline = "", e.style.outlineOffset = "", e.removeAttribute("data-media-ref-hover");
				}), null);
				let n = Vt.current;
				if (!n || !It.current) {
					z();
					return;
				}
				let r = e.target?.closest?.("[data-cite-kind='image']"), i = O.current;
				if (!(r instanceof HTMLElement) || !i?.contains(r)) {
					if (i && Lt.current) {
						let t = document.caretRangeFromPoint(e.clientX, e.clientY), r = t && i.contains(t.startContainer) ? Ae(i, t)?.start : void 0, a = r === void 0 ? void 0 : Lt.current.imageAt(r), o = a ? n[a.ord]?.trim() : void 0;
						if (a && o) {
							Ft(i, o, a.range, e.clientX, e.clientY);
							return;
						}
					}
					z();
					return;
				}
				let a = (n[Number(r.getAttribute("data-cite-ord"))] ?? "").trim();
				if (!a) {
					z();
					return;
				}
				Ft(r, a);
			},
			onMouseLeave: () => {
				Wt.current &&= (O.current?.querySelectorAll("[data-media-ref-hover='1']").forEach((e) => {
					e.style.outline = "", e.style.outlineOffset = "", e.removeAttribute("data-media-ref-hover");
				}), null), z();
			},
			onContextMenu: Fn,
			onFocus: () => {
				Ge.current = !0, b || _t(!0), ae?.();
			},
			onBlur: (e) => {
				Ge.current = !1, _t(!1);
				let t = e.relatedTarget;
				if (qt.current || t instanceof Node && Kt.current?.contains(t)) {
					oe?.();
					return;
				}
				U(), oe?.();
			},
			onClick: x,
			role: "textbox",
			"aria-multiline": "true",
			"aria-label": Me,
			"aria-describedby": Ne,
			"aria-invalid": Fe || void 0,
			"aria-disabled": b || void 0
		}),
		F && !b ? p(/* @__PURE__ */ f("div", {
			ref: Kt,
			"data-rich-plain-bubble": "1",
			style: {
				position: "fixed",
				top: L?.top ?? 0,
				left: L?.left ?? 0,
				visibility: L ? "visible" : "hidden",
				width: H ? 500 : "max-content",
				maxWidth: "calc(100vw - 16px)",
				maxHeight: "calc(100vh - 16px)",
				overflow: "auto",
				zIndex: I.RICH_PLAIN_FORMAT_BUBBLE,
				background: "var(--surface2)",
				border: "1px solid var(--border)",
				borderRadius: "var(--radius)",
				padding: "6px 8px",
				boxShadow: "var(--shadow-md)"
			},
			onMouseDown: (e) => {
				(!(e.target instanceof HTMLElement) || !e.target.closest("input, button, label")) && e.preventDefault();
			},
			onPointerDown: () => {
				qt.current = !0;
			},
			children: [V.current && V.current.start !== V.current.end ? /* @__PURE__ */ d(nn, {
				onFindReplace: mn,
				onCut: un,
				onCopy: dn,
				onBold: ln,
				onColor: fn,
				onClear: pn
			}) : null, H ? /* @__PURE__ */ d(Qt, {
				initialQuery: H.query,
				plain: m,
				onPreview: en,
				onCancel: hn,
				onReplace: gn
			}) : null]
		}), document.body) : null,
		H ? /* @__PURE__ */ d($t, {
			root: O.current,
			matches: Yt.matches,
			active: Yt.active
		}) : null,
		R ? p(/* @__PURE__ */ d("div", {
			"data-rich-cite-preview": "1",
			style: {
				position: "fixed",
				left: Math.max(8, Math.min(window.innerWidth - Bt.boxWidth - 8, R.centerX - Bt.boxWidth / 2)),
				top: R.top > Bt.boxHeight + 16 ? R.top - Bt.boxHeight - 8 : Math.max(8, Math.min(window.innerHeight - Bt.boxHeight - 8, R.bottom + 8)),
				pointerEvents: "none",
				zIndex: I.RICH_PLAIN_FORMAT_BUBBLE,
				width: Bt.boxWidth,
				height: Bt.boxHeight,
				borderRadius: 8,
				overflow: "hidden",
				border: "1px solid var(--border)",
				boxShadow: "var(--shadow-md)",
				background: "var(--surface)"
			},
			children: /* @__PURE__ */ d("img", {
				src: R.url,
				onError: () => {
					Pt.current?.url === R.url && z();
				},
				alt: "",
				onLoad: (e) => {
					let t = e.currentTarget;
					Pt.current?.url === R.url && t.naturalWidth > 0 && t.naturalHeight > 0 && zt({
						url: R.url,
						width: t.naturalWidth,
						height: t.naturalHeight
					});
				},
				style: {
					width: "100%",
					height: "100%",
					objectFit: "contain",
					display: "block"
				}
			}, R.url)
		}), document.body) : null
	] });
}), Fn = {
	version: 1,
	specialKeys: {
		Delete: "Delete",
		Home: "Home",
		End: "End",
		Space: "Space",
		PageUp: "PageUp",
		PageDown: "PageDown",
		ArrowUp: "Up",
		ArrowDown: "Down",
		ArrowLeft: "Left",
		ArrowRight: "Right",
		NumpadDecimal: "Kp Period",
		NumpadAdd: "Kp Add",
		NumpadSubtract: "Kp Subtract",
		NumpadMultiply: "Kp Multiply",
		NumpadDivide: "Kp Divide",
		BracketLeft: "[",
		BracketRight: "]",
		Minus: "-",
		Equal: "=",
		Comma: ",",
		Period: ".",
		Slash: "/",
		Backslash: "\\",
		Semicolon: ";",
		Quote: "'",
		Backquote: "`"
	},
	actions: [
		{
			id: "box_select",
			zh: "框选人物",
			en: "Box select",
			group: "编辑",
			defaultChord: { code: "KeyB" },
			aliases: [],
			settings: !1
		},
		{
			id: "move",
			zh: "移动工具 / 拖动位置",
			en: "Move tool / Joint translation",
			group: "编辑",
			defaultChord: { code: "KeyG" },
			aliases: [],
			settings: !0
		},
		{
			id: "rotate",
			zh: "旋转工具 / 旋转关节",
			en: "Rotate tool / Joint rotation",
			group: "编辑",
			defaultChord: { code: "KeyR" },
			aliases: [],
			settings: !0
		},
		{
			id: "pose",
			zh: "摆姿 / 整人编辑",
			en: "Pose / Object editing",
			group: "编辑",
			defaultChord: { code: "KeyP" },
			aliases: [],
			settings: !1
		},
		{
			id: "frame",
			zh: "聚焦所选人物 / 关节",
			en: "Frame selection",
			group: "视图",
			defaultChord: { code: "KeyF" },
			aliases: [{ code: "NumpadDecimal" }],
			settings: !1
		},
		{
			id: "all",
			zh: "框住全部 / 适配取景框",
			en: "Frame all",
			group: "视图",
			defaultChord: { code: "Home" },
			aliases: [],
			settings: !1
		},
		{
			id: "camera_view",
			zh: "场景 / 相机",
			en: "Scene / Camera",
			group: "视图",
			defaultChord: { code: "Digit0" },
			aliases: [{ code: "Numpad0" }],
			settings: !1
		},
		{
			id: "front",
			zh: "前视图",
			en: "Front",
			group: "视图",
			defaultChord: { code: "Numpad1" },
			aliases: [],
			settings: !1
		},
		{
			id: "back",
			zh: "后视图",
			en: "Back",
			group: "视图",
			defaultChord: {
				code: "Numpad1",
				ctrl: !0
			},
			aliases: [],
			settings: !1
		},
		{
			id: "right",
			zh: "右视图",
			en: "Right",
			group: "视图",
			defaultChord: { code: "Numpad3" },
			aliases: [],
			settings: !1
		},
		{
			id: "left",
			zh: "左视图",
			en: "Left",
			group: "视图",
			defaultChord: {
				code: "Numpad3",
				ctrl: !0
			},
			aliases: [],
			settings: !1
		},
		{
			id: "top",
			zh: "顶视图",
			en: "Top",
			group: "视图",
			defaultChord: { code: "Numpad7" },
			aliases: [],
			settings: !1
		},
		{
			id: "bottom",
			zh: "底视图",
			en: "Bottom",
			group: "视图",
			defaultChord: {
				code: "Numpad7",
				ctrl: !0
			},
			aliases: [],
			settings: !1
		},
		{
			id: "projection",
			zh: "透视 / 正交",
			en: "Perspective / Orthographic",
			group: "视图",
			defaultChord: { code: "Numpad5" },
			aliases: [],
			settings: !1
		},
		{
			id: "align_camera",
			zh: "用当前视角设机位",
			en: "Align camera to view",
			group: "镜头",
			defaultChord: {
				code: "Numpad0",
				ctrl: !0,
				alt: !0
			},
			aliases: [],
			settings: !1
		},
		{
			id: "focus_view",
			zh: "专注视口",
			en: "Focus viewport",
			group: "界面",
			defaultChord: {
				code: "Space",
				ctrl: !0
			},
			aliases: [],
			settings: !1
		},
		{
			id: "left_panel",
			zh: "场景栏",
			en: "Scene panel",
			group: "界面",
			defaultChord: { code: "KeyT" },
			aliases: [],
			settings: !1
		},
		{
			id: "right_panel",
			zh: "属性栏",
			en: "Inspector",
			group: "界面",
			defaultChord: { code: "KeyN" },
			aliases: [],
			settings: !1
		},
		{
			id: "save",
			zh: "保存到画布",
			en: "Save to canvas",
			group: "文件",
			defaultChord: {
				code: "KeyS",
				ctrl: !0
			},
			aliases: [],
			settings: !1
		},
		{
			id: "undo",
			zh: "撤销",
			en: "Undo",
			group: "编辑",
			defaultChord: {
				code: "KeyZ",
				ctrl: !0
			},
			aliases: [],
			settings: !1
		},
		{
			id: "redo",
			zh: "重做",
			en: "Redo",
			group: "编辑",
			defaultChord: {
				code: "KeyZ",
				ctrl: !0,
				shift: !0
			},
			aliases: [],
			settings: !1
		},
		{
			id: "rename",
			zh: "重命名人物",
			en: "Rename selection",
			group: "编辑",
			defaultChord: { code: "F2" },
			aliases: [],
			settings: !1
		},
		{
			id: "duplicate",
			zh: "复制人物",
			en: "Duplicate selection",
			group: "编辑",
			defaultChord: {
				code: "KeyD",
				shift: !0
			},
			aliases: [],
			settings: !1
		},
		{
			id: "delete",
			zh: "删除人物",
			en: "Delete selection",
			group: "编辑",
			defaultChord: { code: "Delete" },
			aliases: [],
			settings: !1
		},
		{
			id: "help",
			zh: "快捷键与帮助",
			en: "Shortcut help",
			group: "界面",
			defaultChord: { code: "F1" },
			aliases: [],
			settings: !1
		}
	]
}, In = {
	schemaVersion: 1,
	actions: [
		{
			id: "any2text.previousSegment",
			defaultChord: {
				code: "ArrowUp",
				shift: !0,
				alt: !0
			},
			zh: "上一段",
			en: "Previous subtitle"
		},
		{
			id: "any2text.nextSegment",
			defaultChord: {
				code: "ArrowDown",
				shift: !0,
				alt: !0
			},
			zh: "下一段",
			en: "Next subtitle"
		},
		{
			id: "any2text.insertLineBreak",
			defaultChord: {
				code: "Enter",
				shift: !0,
				alt: !0
			},
			zh: "插入换行",
			en: "Insert line break"
		},
		{
			id: "any2text.splitAtCursor",
			defaultChord: {
				code: "Enter",
				shift: !0,
				ctrl: !0
			},
			zh: "在光标处拆段",
			en: "Split at cursor"
		},
		{
			id: "any2text.mergePrevious",
			defaultChord: {
				code: "ArrowLeft",
				shift: !0,
				alt: !0
			},
			zh: "与上一段合并",
			en: "Merge with previous"
		},
		{
			id: "any2text.mergeNext",
			defaultChord: {
				code: "ArrowRight",
				shift: !0,
				alt: !0
			},
			zh: "与下一段合并",
			en: "Merge with next"
		},
		{
			id: "any2text.suggestBreaks",
			defaultChord: {
				code: "KeyA",
				shift: !0,
				alt: !0
			},
			zh: "自动整理",
			en: "Suggest subtitle breaks"
		},
		{
			id: "any2text.undoEdit",
			defaultChord: {
				code: "KeyZ",
				shift: !0,
				alt: !0
			},
			zh: "撤销",
			en: "Undo subtitle edit"
		},
		{
			id: "any2text.reviewCurrent",
			defaultChord: {
				code: "KeyR",
				shift: !0,
				alt: !0
			},
			zh: "复核当前段",
			en: "Review current subtitle"
		},
		{
			id: "any2text.reviewAll",
			defaultChord: {
				code: "KeyB",
				shift: !0,
				alt: !0
			},
			zh: "复核全部",
			en: "Review all subtitles"
		},
		{
			id: "any2text.confirmReview",
			defaultChord: {
				code: "KeyC",
				shift: !0,
				alt: !0
			},
			zh: "确认时间",
			en: "Confirm timing"
		}
	]
};
new Map(In.actions.map((e) => [e.id, {
	"zh-CN": e.zh,
	en: e.en
}]));
function Ln(e) {
	let { code: t, ctrl: n, alt: r, meta: i } = e;
	return i || /^(Escape|Tab|F4|F11)$/.test(t) || n && !r && /^(Key[ACVXYZ]|Backspace|Delete)$/.test(t) ? !1 : !!(n || r || /^F([1-9]|1[0-9]|2[0-4])$/.test(t));
}
var Rn = [
	{
		id: "app.save",
		scope: "global",
		defaultChord: {
			code: "KeyS",
			ctrl: !0
		},
		allowInEditableTarget: !0,
		labelKey: "shortcuts.app.save",
		categoryKey: "shortcuts.categories.global"
	},
	{
		id: "app.toggleSidebar",
		scope: "global",
		defaultChord: {
			code: "KeyB",
			ctrl: !0
		},
		allowInEditableTarget: !0,
		labelKey: "shortcuts.app.toggleSidebar",
		categoryKey: "shortcuts.categories.global"
	},
	{
		id: "canvas.toggleFullscreen",
		scope: "global",
		defaultChord: { code: "F11" },
		allowInEditableTarget: !0,
		labelKey: "shortcuts.canvas.toggleFullscreen",
		categoryKey: "shortcuts.categories.canvas"
	},
	{
		id: "canvas.resetLayout",
		scope: "global",
		defaultChord: null,
		allowInEditableTarget: !1,
		labelKey: "shortcuts.canvas.resetLayout",
		categoryKey: "shortcuts.categories.canvas"
	},
	{
		id: "canvas.zoomTo100",
		scope: "global",
		defaultChord: {
			code: "KeyZ",
			shift: !0
		},
		allowInEditableTarget: !1,
		labelKey: "shortcuts.canvas.zoomTo100",
		categoryKey: "shortcuts.categories.canvas"
	},
	{
		id: "canvas.fitAllNodes",
		scope: { mainTabs: [
			"freeCanvas",
			"clips",
			"chapters",
			"scenes",
			"storyboard",
			"segments"
		] },
		defaultChord: {
			code: "KeyZ",
			alt: !0,
			shift: !0
		},
		allowInEditableTarget: !1,
		labelKey: "shortcuts.canvas.fitAllNodes",
		categoryKey: "shortcuts.categories.canvas"
	},
	{
		id: "canvas.zoomIn",
		scope: { mainTabs: ["clips", "freeCanvas"] },
		defaultChord: {
			code: "Equal",
			alt: !0
		},
		aliases: [{
			code: "Equal",
			alt: !0,
			shift: !0
		}, {
			code: "NumpadAdd",
			alt: !0
		}],
		allowInEditableTarget: !1,
		allowKeyRepeat: !0,
		labelKey: "shortcuts.canvas.zoomIn",
		categoryKey: "shortcuts.categories.canvas"
	},
	{
		id: "canvas.zoomOut",
		scope: { mainTabs: ["clips", "freeCanvas"] },
		defaultChord: {
			code: "Minus",
			alt: !0
		},
		aliases: [{
			code: "NumpadSubtract",
			alt: !0
		}],
		allowInEditableTarget: !1,
		allowKeyRepeat: !0,
		labelKey: "shortcuts.canvas.zoomOut",
		categoryKey: "shortcuts.categories.canvas"
	},
	{
		id: "canvas.toggleSceneListPeek",
		scope: { mainTabs: ["storyboard", "segments"] },
		defaultChord: {
			code: "KeyS",
			alt: !0
		},
		allowInEditableTarget: !1,
		labelKey: "shortcuts.canvas.toggleSceneListPeek",
		categoryKey: "shortcuts.categories.canvas"
	},
	{
		id: "canvas.undo",
		scope: "global",
		defaultChord: {
			code: "KeyZ",
			ctrl: !0
		},
		allowInEditableTarget: !1,
		labelKey: "shortcuts.canvas.undo",
		categoryKey: "shortcuts.categories.canvas"
	},
	{
		id: "canvas.redo",
		scope: "global",
		defaultChord: {
			code: "KeyY",
			ctrl: !0
		},
		allowInEditableTarget: !1,
		labelKey: "shortcuts.canvas.redo",
		categoryKey: "shortcuts.categories.canvas"
	},
	{
		id: "canvas.selectAll",
		scope: { mainTabs: [
			"storyboard",
			"segments",
			"clips",
			"freeCanvas",
			"scenes",
			"roles",
			"characters",
			"storyProps"
		] },
		defaultChord: {
			code: "KeyA",
			ctrl: !0
		},
		allowInEditableTarget: !1,
		labelKey: "shortcuts.canvas.selectAll",
		categoryKey: "shortcuts.categories.canvas"
	},
	{
		id: "canvas.alignNodes",
		scope: { mainTabs: [
			"chapters",
			"storyboard",
			"segments",
			"clips",
			"freeCanvas"
		] },
		defaultChord: {
			code: "KeyA",
			alt: !0
		},
		allowInEditableTarget: !1,
		labelKey: "shortcuts.canvas.alignNodes",
		categoryKey: "shortcuts.categories.canvas"
	},
	{
		id: "globalAssistant.toggle",
		scope: "global",
		defaultChord: { code: "F1" },
		allowInEditableTarget: !0,
		labelKey: "shortcuts.globalAssistant.toggle",
		categoryKey: "shortcuts.categories.global"
	},
	{
		id: "globalAssistant.startMic",
		scope: "global",
		defaultChord: {
			code: "KeyM",
			ctrl: !0,
			shift: !0
		},
		allowInEditableTarget: !0,
		allowWhenModalOpen: !1,
		labelKey: "shortcuts.globalAssistant.startMic",
		categoryKey: "shortcuts.categories.global"
	},
	{
		id: "globalAssistant.cancelMic",
		scope: "global",
		defaultChord: { code: "Escape" },
		allowInEditableTarget: !0,
		allowWhenModalOpen: !1,
		labelKey: "shortcuts.globalAssistant.cancelMic",
		categoryKey: "shortcuts.categories.global"
	},
	{
		id: "segmentCanvas.toggleRightPanel",
		scope: { mainTab: "segments" },
		defaultChord: {
			code: "KeyB",
			shift: !0
		},
		allowInEditableTarget: !1,
		labelKey: "shortcuts.segmentCanvas.toggleRightPanel",
		categoryKey: "shortcuts.categories.segments"
	},
	{
		id: "canvas.group",
		scope: { mainTabs: [
			"clips",
			"freeCanvas",
			"segments",
			"scenes",
			"storyboard"
		] },
		defaultChord: {
			code: "KeyG",
			ctrl: !0
		},
		allowInEditableTarget: !1,
		labelKey: "shortcuts.canvas.group",
		categoryKey: "shortcuts.categories.canvas"
	},
	{
		id: "canvas.ungroup",
		scope: { mainTabs: [
			"clips",
			"freeCanvas",
			"segments",
			"scenes",
			"storyboard"
		] },
		defaultChord: {
			code: "KeyG",
			ctrl: !0,
			alt: !0
		},
		allowInEditableTarget: !1,
		labelKey: "shortcuts.canvas.ungroup",
		categoryKey: "shortcuts.categories.canvas"
	},
	{
		id: "storyboard.toggleShotHistory",
		scope: { mainTab: "storyboard" },
		defaultChord: {
			code: "KeyB",
			shift: !0
		},
		allowInEditableTarget: !1,
		labelKey: "shortcuts.storyboard.toggleShotHistory",
		categoryKey: "shortcuts.categories.storyboard"
	},
	{
		id: "refineWorkbench.toolMouse",
		scope: "global",
		defaultChord: { code: "KeyA" },
		allowInEditableTarget: !1,
		labelKey: "shortcuts.refineWorkbench.toolMouse",
		categoryKey: "shortcuts.categories.canvas"
	},
	{
		id: "refineWorkbench.toolBrush",
		scope: "global",
		defaultChord: { code: "KeyB" },
		allowInEditableTarget: !1,
		labelKey: "shortcuts.refineWorkbench.toolBrush",
		categoryKey: "shortcuts.categories.canvas"
	},
	{
		id: "refineWorkbench.toolCrop",
		scope: "global",
		defaultChord: { code: "KeyC" },
		allowInEditableTarget: !1,
		labelKey: "shortcuts.refineWorkbench.toolCrop",
		categoryKey: "shortcuts.categories.canvas"
	},
	{
		id: "refineWorkbench.toolRotate",
		scope: "global",
		defaultChord: { code: "KeyR" },
		allowInEditableTarget: !1,
		labelKey: "shortcuts.refineWorkbench.toolRotate",
		categoryKey: "shortcuts.categories.canvas"
	},
	{
		id: "refineWorkbench.brushSizeIncrease",
		scope: "global",
		defaultChord: { code: "BracketRight" },
		allowInEditableTarget: !1,
		allowKeyRepeat: !0,
		labelKey: "shortcuts.refineWorkbench.brushSizeIncrease",
		categoryKey: "shortcuts.categories.canvas"
	},
	{
		id: "refineWorkbench.brushSizeDecrease",
		scope: "global",
		defaultChord: { code: "BracketLeft" },
		allowInEditableTarget: !1,
		allowKeyRepeat: !0,
		labelKey: "shortcuts.refineWorkbench.brushSizeDecrease",
		categoryKey: "shortcuts.categories.canvas"
	},
	{
		id: "refineWorkbench.brushOpacityIncrease",
		scope: "global",
		defaultChord: { code: "Equal" },
		allowInEditableTarget: !1,
		allowKeyRepeat: !0,
		labelKey: "shortcuts.refineWorkbench.brushOpacityIncrease",
		categoryKey: "shortcuts.categories.canvas"
	},
	{
		id: "refineWorkbench.brushOpacityDecrease",
		scope: "global",
		defaultChord: { code: "Minus" },
		allowInEditableTarget: !1,
		allowKeyRepeat: !0,
		labelKey: "shortcuts.refineWorkbench.brushOpacityDecrease",
		categoryKey: "shortcuts.categories.canvas"
	},
	{
		id: "sceneTab.prevScene",
		scope: { mainTabs: ["chapters", "scenes"] },
		defaultChord: {
			code: "ArrowLeft",
			alt: !0
		},
		allowInEditableTarget: !0,
		labelKey: "shortcuts.sceneTab.prevScene",
		categoryKey: "shortcuts.categories.chapters"
	},
	{
		id: "sceneTab.nextScene",
		scope: { mainTabs: ["chapters", "scenes"] },
		defaultChord: {
			code: "ArrowRight",
			alt: !0
		},
		allowInEditableTarget: !0,
		labelKey: "shortcuts.sceneTab.nextScene",
		categoryKey: "shortcuts.categories.chapters"
	},
	{
		id: "entityNav.prevEntity",
		scope: "global",
		defaultChord: {
			code: "ArrowLeft",
			alt: !0
		},
		allowInEditableTarget: !0,
		labelKey: "shortcuts.workbench.prevEntity",
		categoryKey: "shortcuts.categories.textareaWorkbench"
	},
	{
		id: "entityNav.nextEntity",
		scope: "global",
		defaultChord: {
			code: "ArrowRight",
			alt: !0
		},
		allowInEditableTarget: !0,
		labelKey: "shortcuts.workbench.nextEntity",
		categoryKey: "shortcuts.categories.textareaWorkbench"
	},
	{
		id: "entityNav.prevField",
		scope: "global",
		defaultChord: {
			code: "ArrowUp",
			alt: !0
		},
		allowInEditableTarget: !0,
		labelKey: "shortcuts.workbench.prevField",
		categoryKey: "shortcuts.categories.textareaWorkbench"
	},
	{
		id: "entityNav.nextField",
		scope: "global",
		defaultChord: {
			code: "ArrowDown",
			alt: !0
		},
		allowInEditableTarget: !0,
		labelKey: "shortcuts.workbench.nextField",
		categoryKey: "shortcuts.categories.textareaWorkbench"
	},
	{
		id: "textareaWorkbench.fontSizeIncrease",
		scope: "global",
		defaultChord: {
			code: "Equal",
			ctrl: !0
		},
		allowInEditableTarget: !0,
		allowKeyRepeat: !0,
		labelKey: "shortcuts.textareaWorkbench.fontSizeIncrease",
		categoryKey: "shortcuts.categories.textareaWorkbench"
	},
	{
		id: "textareaWorkbench.fontSizeDecrease",
		scope: "global",
		defaultChord: {
			code: "Minus",
			ctrl: !0
		},
		allowInEditableTarget: !0,
		allowKeyRepeat: !0,
		labelKey: "shortcuts.textareaWorkbench.fontSizeDecrease",
		categoryKey: "shortcuts.categories.textareaWorkbench"
	},
	{
		id: "textareaWorkbench.lineHeightIncrease",
		scope: "global",
		defaultChord: {
			code: "BracketRight",
			ctrl: !0
		},
		allowInEditableTarget: !0,
		allowKeyRepeat: !0,
		labelKey: "shortcuts.textareaWorkbench.lineHeightIncrease",
		categoryKey: "shortcuts.categories.textareaWorkbench"
	},
	{
		id: "textareaWorkbench.lineHeightDecrease",
		scope: "global",
		defaultChord: {
			code: "BracketLeft",
			ctrl: !0
		},
		allowInEditableTarget: !0,
		allowKeyRepeat: !0,
		labelKey: "shortcuts.textareaWorkbench.lineHeightDecrease",
		categoryKey: "shortcuts.categories.textareaWorkbench"
	},
	...In.actions.map((e) => ({
		id: e.id,
		scope: "any2text",
		defaultChord: e.defaultChord,
		labelKey: e.id,
		categoryKey: "any2text"
	})),
	...Fn.actions.map((e) => ({
		id: `director.${e.id}`,
		scope: "director",
		defaultChord: e.defaultChord,
		aliases: e.aliases,
		labelKey: `director.${e.id}`,
		categoryKey: "director",
		settingsHidden: !e.settings
	}))
];
new Map(Rn.map((e) => [e.id, e])), new Map(Fn.actions.map((e) => [`director.${e.id}`, {
	"zh-CN": e.zh,
	en: e.en
}]));
//#endregion
//#region src/shortcuts/matchShortcut.ts
function zn(e, t) {
	return e.code === t.code && !!e.ctrl == !!t.ctrl && !!e.alt == !!t.alt && !!e.shift == !!t.shift && !!e.meta == !!t.meta;
}
function Bn(e) {
	return !e.alt && !e.meta;
}
function Vn(e) {
	return e.code === "Equal" && !!e.ctrl && Bn(e);
}
function Hn(e) {
	return e.code === "Minus" && !!e.ctrl && Bn(e);
}
function Un(e) {
	return e.code === "Equal" && !!e.alt && !e.ctrl && !e.meta;
}
function Wn(e) {
	return e.code === "Minus" && !!e.alt && !e.ctrl && !e.meta;
}
function Gn(e, t, n) {
	return zn(e, t) ? !0 : n === "refineWorkbench.brushOpacityIncrease" ? !(t.code !== "Equal" || e.code !== "Equal" || t.ctrl || t.meta || t.alt || e.ctrl || e.meta || e.alt) : n === "textareaWorkbench.fontSizeIncrease" && Vn(t) ? !e.ctrl || !Bn(e) ? !1 : e.code === "Equal" || e.code === "NumpadAdd" : n === "textareaWorkbench.fontSizeDecrease" && Hn(t) ? !e.ctrl || !Bn(e) ? !1 : e.code === "NumpadSubtract" : n === "canvas.zoomIn" && Un(t) ? !e.alt || e.ctrl || e.meta ? !1 : e.code === "Equal" || e.code === "NumpadAdd" : n === "canvas.zoomOut" && Wn(t) ? !e.alt || e.ctrl || e.meta ? !1 : e.code === "Minus" || e.code === "NumpadSubtract" : !1;
}
function Kn(e, t, n = Rn) {
	let r = n.find((t) => t.id === e);
	return r ? t && Object.prototype.hasOwnProperty.call(t, e) ? t[e] : r.defaultChord : null;
}
//#endregion
//#region src/shortcuts/normalizeKeyEvent.ts
function qn() {
	if (typeof navigator > "u") return !1;
	let e = navigator.platform ?? "", t = navigator.userAgent ?? "";
	return e.includes("Mac") || t.includes("Mac");
}
function Jn(e, t = qn()) {
	return t && e.metaKey || e.ctrlKey;
}
function Yn(e, t = qn()) {
	let n = (e.code ?? "").trim();
	if (!n) return null;
	let r = { code: n };
	return Jn(e, t) && (r.ctrl = !0), e.altKey && (r.alt = !0), e.shiftKey && (r.shift = !0), e.metaKey && !t && (r.meta = !0), r;
}
function Xn(e) {
	return e.isComposing || e.keyCode === 229;
}
//#endregion
//#region src/components/textarea-workbench/styles.ts
var Zn = {
	position: "absolute",
	left: 3,
	bottom: 3,
	width: 16,
	height: 16,
	display: "flex",
	alignItems: "center",
	justifyContent: "center",
	cursor: "pointer",
	zIndex: 10,
	borderRadius: 2,
	background: "var(--surface3)",
	border: "1px solid var(--border-light)",
	opacity: .6,
	transition: "opacity 0.15s, border-color 0.15s, box-shadow 0.15s",
	color: "var(--text2)"
}, Qn = {
	position: "absolute",
	right: 6,
	bottom: 3,
	minHeight: 16,
	display: "flex",
	alignItems: "center",
	justifyContent: "center",
	padding: "0 4px",
	pointerEvents: "none",
	zIndex: 10,
	borderRadius: 2,
	background: "var(--surface3)",
	border: "1px solid var(--border-light)",
	opacity: .6,
	color: "var(--text2)",
	fontSize: L.textSm,
	fontVariantNumeric: "tabular-nums",
	lineHeight: 1,
	userSelect: "none"
};
({ ...Zn }), L.textSm, L.textSm;
//#endregion
//#region src/components/ui-chrome-textarea/UiChromeTextarea.tsx
var $n = [{
	id: "textareaWorkbench.fontSizeIncrease",
	label: "fontSizeIncrease",
	symbol: "+",
	step: 1
}, {
	id: "textareaWorkbench.fontSizeDecrease",
	label: "fontSizeDecrease",
	symbol: "−",
	step: -1
}], er = {
	...Zn,
	position: "static",
	padding: 0,
	boxShadow: "none",
	lineHeight: 1
}, tr = {
	minW: 200,
	maxW: 2400,
	minH: 60,
	maxH: 1200
}, nr = e(function({ edgeConstraints: e = tr, defaultWidthPx: t = 0, defaultHeightPx: n = 120, fillAvailableHeight: r = !1, contentHeight: i = !1, shellClassName: a = "", withVersionHistory: o = !1, shellStyle: s, textareaExtraClassName: c = "", textareaProps: l, onValueChange: p, onSourceChange: m, richOwner: h, hydrateSource: g, historyCorner: _, relativeWrapStyle: v, onSizeCommit: y, shellRef: b, canvasResizeHandles: ee = !1, syntaxProfileId: te, pauseSyntaxRefresh: ne, citeImagePreviewByOrdinal: re, mediaRefPreviewById: ie, mediaRefLabelById: oe, richHost: se }, ce) {
	let le = [
		"ui-edge-resize-shell--with-font-size",
		a,
		o ? "ui-edge-resize-shell--with-history" : ""
	].filter(Boolean).join(" "), ue = r ? 0 : n, { className: de, style: x, value: fe, onChange: pe, placeholder: S, disabled: C, readOnly: me, spellCheck: he, onFocus: ge, onBlur: w, onKeyDown: _e, onClick: T, onCompositionStart: ve, onCompositionEnd: ye, maxLength: be, id: xe } = l, Se = l["aria-label"], Ce = l["aria-describedby"], we = l["aria-invalid"], Te = [
		"ui-edit-textarea",
		c,
		de
	].filter(Boolean).join(" "), Ee = sn(se), E = Ee.useI18n().shortcuts?.textareaWorkbench, De = (e) => {
		if (Ee === X && !C && !e.defaultPrevented && !Xn(e.nativeEvent)) {
			let t = Yn(e.nativeEvent), n = t && $n.find(({ id: e }) => {
				let n = Kn(e, void 0);
				return n && Gn(t, n, e);
			});
			if (n) {
				e.preventDefault(), e.stopPropagation(), wn(n.step, "chrome");
				return;
			}
		}
		_e?.(e);
	}, D = (e) => {
		let t = typeof be == "number" && e.length > be ? e.slice(0, be) : e;
		p?.(t), pe?.(t);
	}, Oe = /* @__PURE__ */ f(u, { children: [
		_ && /* @__PURE__ */ d("div", {
			className: "ui-chrome-textarea__history",
			children: _
		}),
		/* @__PURE__ */ d("div", {
			className: "ui-chrome-textarea__font-size",
			"data-canvas-ui": !0,
			children: $n.map(({ id: e, label: t, symbol: n, step: r }) => /* @__PURE__ */ d(B, {
				variant: "secondary",
				style: er,
				disabled: C,
				"aria-label": E?.[t] ?? (r > 0 ? "增大字号" : "缩小字号"),
				shortcutActionId: e,
				onPointerDown: (e) => {
					e.preventDefault();
				},
				onClick: (e) => {
					e.stopPropagation(), wn(r, "chrome");
				},
				children: n
			}, e))
		}),
		/* @__PURE__ */ d("span", {
			style: Qn,
			"aria-hidden": !0,
			children: typeof be == "number" ? `${fe.length}/${be}` : String(fe.length)
		})
	] });
	return /* @__PURE__ */ d("div", {
		"data-ui-chrome-textarea": "1",
		"data-rich-owner": h ? `${h.ownerKind}:${h.ownerId}:${h.fieldKey}` : void 0,
		style: {
			position: "relative",
			width: "100%",
			minWidth: 0,
			...r ? {
				flex: "1 1 0%",
				minHeight: 0,
				display: "flex",
				flexDirection: "column",
				alignSelf: "stretch"
			} : null,
			...v
		},
		children: /* @__PURE__ */ d(ae, {
			shellRef: b,
			edgeConstraints: e,
			defaultWidthPx: t,
			defaultHeightPx: ue,
			contentHeight: i,
			shellClassName: le,
			shellStyle: s,
			onSizeCommit: y,
			disableHorizontalResize: !0,
			canvasResizeHandles: ee,
			bottomOverlay: Oe,
			children: /* @__PURE__ */ d(Pn, {
				ref: ce,
				className: Te,
				style: x,
				value: fe,
				onValueChange: D,
				onSourceChange: m,
				richOwner: h,
				hydrateSource: g,
				placeholder: S,
				disabled: C || me,
				spellCheck: he,
				id: xe,
				"aria-label": Se,
				"aria-describedby": Ce,
				"aria-invalid": we || void 0,
				onFocus: ge,
				onBlur: w,
				onKeyDown: De,
				onClick: T,
				onCompositionStart: ve,
				onCompositionEnd: ye,
				syntaxProfileId: te,
				pauseSyntaxRefresh: ne,
				citeImagePreviewByOrdinal: re,
				mediaRefPreviewById: ie,
				mediaRefLabelById: oe,
				host: Ee
			})
		})
	});
}), rr = {
	boxSizing: "border-box",
	width: "100%",
	minWidth: 0,
	height: 38,
	padding: 9,
	fontSize: L.textMd,
	lineHeight: "18px"
}, ir = {
	display: "grid",
	gap: 4,
	minWidth: 0
};
L.textSm;
var ar = {
	width: "100%",
	padding: "4px 8px",
	borderRadius: 4,
	border: "1px solid var(--border)",
	fontSize: L.textSm,
	lineHeight: "18px",
	boxSizing: "border-box",
	minHeight: 28
}, or = { ...Rt }, sr = {
	display: "flex",
	flexDirection: "column",
	gap: 3,
	flex: "1 1 120px",
	minWidth: 110,
	maxWidth: "100%",
	boxSizing: "border-box"
}, cr = {
	display: "flex",
	flexDirection: "row",
	alignItems: "center",
	gap: 8,
	flex: "1 1 160px",
	minWidth: 140,
	maxWidth: "100%",
	boxSizing: "border-box"
}, lr = {
	...or,
	whiteSpace: "nowrap",
	flexShrink: 0
};
function ur(e) {
	return {
		...ar,
		height: 28,
		background: e ? "var(--surface2)" : "var(--surface)",
		color: "var(--text1)",
		opacity: e ? .6 : 1
	};
}
({ ...ar });
//#endregion
//#region src/components/ui-chrome-select/UiChromeSelect.tsx
function dr({ label: e, hideLabel: t = !1, labelLayout: n = "stacked", controlSize: r = "compact", fieldColStyle: a, fieldTitle: o, disabled: s, id: c, style: l, children: u, ...p }) {
	let m = i(), h = c ?? m, g = n === "inline", _ = r === "form", v = {
		..._ ? {
			...rr,
			paddingRight: 28,
			opacity: s ? .6 : 1
		} : ur(s),
		...g ? {
			flex: "1 1 auto",
			minWidth: 0,
			width: "auto"
		} : null,
		...l
	}, y = /* @__PURE__ */ d("select", {
		...p,
		id: h,
		disabled: s,
		"data-ui-form-select": _ ? "true" : void 0,
		"aria-label": t ? e : p["aria-label"],
		style: v,
		children: u
	});
	return t ? /* @__PURE__ */ d("div", {
		style: a ?? {
			minWidth: 0,
			width: "100%"
		},
		title: o,
		children: y
	}) : /* @__PURE__ */ f("div", {
		style: a ?? (g ? cr : _ ? ir : sr),
		title: o,
		children: [/* @__PURE__ */ d("label", {
			htmlFor: h,
			style: g ? lr : or,
			children: e
		}), y]
	});
}
//#endregion
//#region src/theme/themeEarlyHydrate.ts
var fr = "app_theme";
function pr() {
	try {
		let e = localStorage.getItem(fr);
		(e === "light" || e === "sakura" || e === "ocean" || e === "fresh") && (document.documentElement.dataset.theme = e);
	} catch {}
}
//#endregion
//#region src/components/common/inline-edit/claimInlineEditCommit.ts
function mr(e) {
	return e.committed ? !1 : (e.committed = !0, !0);
}
//#endregion
//#region src/theme/themeRegistry.ts
var hr = {
	dark: {
		id: "dark",
		label: "深色",
		colorScheme: "dark"
	},
	light: {
		id: "light",
		label: "浅色",
		colorScheme: "light"
	},
	sakura: {
		id: "sakura",
		label: "樱花粉",
		colorScheme: "light"
	},
	ocean: {
		id: "ocean",
		label: "海天蓝",
		colorScheme: "dark"
	},
	fresh: {
		id: "fresh",
		label: "清新绿",
		colorScheme: "light"
	}
}, gr = "app_theme";
function _r(e) {
	return e === "light" || e === "sakura" || e === "ocean" || e === "fresh" ? e : "dark";
}
//#endregion
//#region src/theme/applyThemeToDocument.ts
function vr(e) {
	let t = document.documentElement;
	e === "dark" ? delete t.dataset.theme : t.dataset.theme = e, t.style.colorScheme = hr[e].colorScheme;
}
//#endregion
//#region src/components/ui-chrome-textarea/standaloneTheme.ts
function yr(e) {
	let t = _r(e);
	vr(t);
	try {
		localStorage.setItem(gr, t);
	} catch {}
}
//#endregion
//#region src/components/common/WindowControls.tsx
var br = {
	width: 46,
	height: 32,
	display: "flex",
	alignItems: "center",
	justifyContent: "center",
	border: "none",
	background: "transparent",
	color: "var(--text2)",
	cursor: "pointer",
	fontSize: L.textLg,
	borderRadius: 4
}, xr = { background: "var(--surface3)" };
function Sr({ max: e, onMinimize: t, onMaximize: n, onClose: r }) {
	return /* @__PURE__ */ f(u, { children: [
		/* @__PURE__ */ d("button", {
			type: "button",
			title: "最小化",
			style: br,
			onMouseEnter: (e) => Object.assign(e.currentTarget.style, xr),
			onMouseLeave: (e) => {
				e.currentTarget.style.background = "transparent";
			},
			onClick: () => t(),
			children: "─"
		}),
		/* @__PURE__ */ d("button", {
			type: "button",
			title: e ? "还原" : "最大化",
			style: br,
			onMouseEnter: (e) => Object.assign(e.currentTarget.style, xr),
			onMouseLeave: (e) => {
				e.currentTarget.style.background = "transparent";
			},
			onClick: () => {
				n();
			},
			children: e ? "❐" : "□"
		}),
		/* @__PURE__ */ d("button", {
			type: "button",
			title: "关闭",
			style: {
				...br,
				color: "var(--text2)"
			},
			onMouseEnter: (e) => {
				e.currentTarget.style.background = "rgba(220,38,38,0.25)", e.currentTarget.style.color = "var(--danger)";
			},
			onMouseLeave: (e) => {
				e.currentTarget.style.background = "transparent", e.currentTarget.style.color = "var(--text2)";
			},
			onClick: () => r(),
			children: "×"
		})
	] });
}
//#endregion
//#region src/components/common/NativeDialog.tsx
function Cr({ title: e, onClose: t, children: n, className: i }) {
	let a = c(null);
	return r(() => {
		let e = a.current;
		if (!e) return;
		let t = document.activeElement;
		return e.showModal(), () => {
			e.close(), t instanceof HTMLElement && t.isConnected && t.focus();
		};
	}, []), /* @__PURE__ */ f("dialog", {
		ref: a,
		className: i,
		"aria-label": e,
		onCancel: (e) => {
			e.preventDefault(), t();
		},
		children: [/* @__PURE__ */ d("h3", { children: e }), n]
	});
}
//#endregion
//#region src/components/common/form/SingleLineTextField.tsx
var wr = { flex: "0 0 auto" };
function Tr({ label: e, type: t, value: n, onValue: r, disabled: i, hideLabel: a, placeholder: o, maxLength: s, onBlur: c, inputMode: l, fieldStyle: u, layout: p = "inline" }) {
	let m = /* @__PURE__ */ d("input", {
		type: t,
		"aria-label": e,
		value: n,
		disabled: i,
		placeholder: o,
		inputMode: l,
		maxLength: s,
		onBlur: c,
		onChange: (e) => r(e.target.value),
		style: ur(i)
	});
	return a ? /* @__PURE__ */ d("span", {
		style: {
			display: "inline-flex",
			minWidth: 140,
			...u
		},
		children: m
	}) : /* @__PURE__ */ f("label", {
		style: {
			...sr,
			...p === "stack" ? wr : null,
			...u
		},
		children: [/* @__PURE__ */ d("span", {
			style: or,
			children: e
		}), m]
	});
}
//#endregion
//#region src/components/common/form/rangeSliderGeometry.ts
function Er(e, t, n) {
	return !Number.isFinite(t) || !Number.isFinite(n) || n <= t || !Number.isFinite(e) ? 0 : Math.min(100, Math.max(0, (e - t) / (n - t) * 100));
}
function Dr(e, t, n, r) {
	let i = Math.min(t, n), a = Math.max(t, n);
	if (!Number.isFinite(e)) return i;
	let o = Number.isFinite(r) && r > 0 ? r : 1, s = Math.round((Math.min(a, Math.max(i, e)) - i) / o), c = Number((i + s * o).toFixed(10));
	return Math.min(a, Math.max(i, c));
}
function Or(e, t, n, r, i, a) {
	return Dr(n <= 0 ? r : r + Math.min(1, Math.max(0, (e - t) / n)) * (i - r), r, i, a);
}
//#endregion
//#region src/components/common/form/UiRangeSlider.tsx
var kr = 4, Ar = 12, jr = 18, Mr = {
	position: "absolute",
	width: 1,
	height: 1,
	padding: 0,
	margin: -1,
	overflow: "hidden",
	clip: "rect(0, 0, 0, 0)",
	whiteSpace: "nowrap",
	border: 0,
	pointerEvents: "none",
	opacity: 0,
	appearance: "none",
	WebkitAppearance: "none"
};
function Nr({ min: e, max: t, step: r = 1, value: i, onChange: a, disabled: o = !1, "aria-label": s, style: l }) {
	let u = c(null), p = c(!1), m = Er(i, e, t), h = n((n) => {
		let i = u.current;
		if (!i || o) return;
		let s = i.getBoundingClientRect();
		a(Or(n, s.left, s.width, e, t, r));
	}, [
		o,
		t,
		e,
		a,
		r
	]), g = n((e) => {
		o || (p.current = !0, h(e.clientX), e.currentTarget.setPointerCapture(e.pointerId));
	}, [o, h]), _ = n((e) => {
		!p.current || o || h(e.clientX);
	}, [o, h]), v = n((e) => {
		p.current = !1, e.currentTarget.hasPointerCapture(e.pointerId) && e.currentTarget.releasePointerCapture(e.pointerId);
	}, []), y = n((e) => {
		if (o) return;
		let t = Number(e.target.value);
		Number.isFinite(t) && a(t);
	}, [o, a]);
	return /* @__PURE__ */ d("div", {
		style: {
			position: "relative",
			flex: "1 1 0",
			minWidth: 0,
			width: "100%",
			height: jr,
			display: "flex",
			alignItems: "center",
			opacity: o ? .5 : 1,
			...l
		},
		children: /* @__PURE__ */ f("div", {
			ref: u,
			onPointerDown: g,
			onPointerMove: _,
			onPointerUp: v,
			onPointerCancel: v,
			style: {
				position: "relative",
				width: "100%",
				height: jr,
				display: "flex",
				alignItems: "center",
				cursor: o ? "default" : "pointer",
				overflow: "visible"
			},
			children: [/* @__PURE__ */ f("div", {
				"aria-hidden": !0,
				style: {
					position: "relative",
					width: "100%",
					height: kr,
					borderRadius: kr / 2,
					background: "color-mix(in srgb, var(--text) 16%, var(--surface2))",
					pointerEvents: "none"
				},
				children: [/* @__PURE__ */ d("div", { style: {
					position: "absolute",
					left: 0,
					top: 0,
					bottom: 0,
					width: `${m}%`,
					borderRadius: kr / 2,
					background: "var(--primary)"
				} }), /* @__PURE__ */ d("div", { style: {
					position: "absolute",
					top: "50%",
					left: `${m}%`,
					width: Ar,
					height: Ar,
					marginTop: -Ar / 2,
					transform: "translateX(-50%)",
					borderRadius: "50%",
					background: "var(--primary)",
					boxShadow: "0 0 0 1px var(--border)"
				} })]
			}), /* @__PURE__ */ d("input", {
				type: "range",
				"data-range-edge": "flush",
				min: e,
				max: t,
				step: r,
				value: i,
				disabled: o,
				"aria-label": s,
				onChange: y,
				tabIndex: o ? -1 : 0,
				style: Mr
			})]
		})
	});
}
//#endregion
//#region src/shortcuts/formatChord.ts
var Pr = {
	Backslash: "\\",
	Space: "空格",
	Enter: "回车",
	ArrowUp: "↑",
	ArrowDown: "↓",
	ArrowLeft: "←",
	ArrowRight: "→",
	Equal: "=",
	Minus: "-",
	BracketLeft: "[",
	BracketRight: "]",
	NumpadAdd: "+",
	NumpadSubtract: "-"
}, Fr = {
	Backslash: "\\",
	Space: "Space",
	Enter: "Enter",
	ArrowUp: "↑",
	ArrowDown: "↓",
	ArrowLeft: "←",
	ArrowRight: "→",
	Equal: "=",
	Minus: "-",
	BracketLeft: "[",
	BracketRight: "]",
	NumpadAdd: "+",
	NumpadSubtract: "-"
};
function Ir(e) {
	return e.startsWith("Key") ? e.slice(3).toUpperCase() : e.startsWith("Digit") ? e.slice(5) : e;
}
function Lr(e, t) {
	return (t === "zh-CN" ? Pr : Fr)[e] ?? Ir(e);
}
function Rr(e, t, n) {
	if (!e) return t === "zh-CN" ? "无" : "None";
	let r = [];
	return e.ctrl && r.push(n ? "⌘" : "Ctrl"), e.alt && r.push(n ? "⌥" : "Alt"), e.shift && r.push(n ? "⇧" : "Shift"), e.meta && r.push(n ? "⌘" : "Win"), r.push(Lr(e.code, t)), r.join("+");
}
//#endregion
//#region src/fullscreen/createOsFullscreenController.ts
function zr(e, t) {
	let n = !1, r = Promise.resolve();
	return (i) => {
		let a = r.then(async () => {
			let r = e();
			if (await r.isFullscreen()) {
				if (i === "enter") return;
				await r.setFullscreen(!1), n && await r.maximize(), n = !1;
			} else if (i !== "exit") {
				let e = await r.isMaximized(), i = e && t();
				i && await r.toggleMaximize();
				try {
					await r.setFullscreen(!0), n = e;
				} catch (e) {
					throw i && await r.maximize(), e;
				}
			}
		});
		return r = a.catch(() => {}), a;
	};
}
//#endregion
export { B as Btn, Cr as NativeDialog, Tr as SingleLineTextField, dr as UiChromeSelect, nr as UiChromeTextarea, Nr as UiRangeSlider, Sr as WindowControls, zn as chordEquals, Yn as chordFromKeyboardEvent, mr as claimInlineEditCommit, zr as createOsFullscreenController, pr as earlyHydrateTheme, Rr as formatChordForDisplay, Ln as isAllowedAny2TextChord, Xn as isComposingEvent, X as standaloneRichPlainHost, yr as themeForDocument };
